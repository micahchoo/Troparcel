"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all2) => {
  for (var name in all2)
    __defProp(target, name, { get: all2[name], enumerable: true });
};
var __copyProps = (to, from2, except, desc) => {
  if (from2 && typeof from2 === "object" || typeof from2 === "function") {
    for (let key of __getOwnPropNames(from2))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from2[key], enumerable: !(desc = __getOwnPropDesc(from2, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/lib0/map.js
var create, copy, setIfUndefined, any;
var init_map = __esm({
  "node_modules/lib0/map.js"() {
    create = () => /* @__PURE__ */ new Map();
    copy = (m) => {
      const r = create();
      m.forEach((v, k) => {
        r.set(k, v);
      });
      return r;
    };
    setIfUndefined = (map2, key, createT) => {
      let set = map2.get(key);
      if (set === void 0) {
        map2.set(key, set = createT());
      }
      return set;
    };
    any = (m, f) => {
      for (const [key, value] of m) {
        if (f(value, key)) {
          return true;
        }
      }
      return false;
    };
  }
});

// node_modules/lib0/set.js
var create2;
var init_set = __esm({
  "node_modules/lib0/set.js"() {
    create2 = () => /* @__PURE__ */ new Set();
  }
});

// node_modules/lib0/array.js
var last, appendTo, from, some, unfold, isArray;
var init_array = __esm({
  "node_modules/lib0/array.js"() {
    last = (arr) => arr[arr.length - 1];
    appendTo = (dest, src) => {
      for (let i = 0; i < src.length; i++) {
        dest.push(src[i]);
      }
    };
    from = Array.from;
    some = (arr, f) => {
      for (let i = 0; i < arr.length; i++) {
        if (f(arr[i], i, arr)) {
          return true;
        }
      }
      return false;
    };
    unfold = (len, f) => {
      const array = new Array(len);
      for (let i = 0; i < len; i++) {
        array[i] = f(i, array);
      }
      return array;
    };
    isArray = Array.isArray;
  }
});

// node_modules/lib0/observable.js
var ObservableV2, Observable;
var init_observable = __esm({
  "node_modules/lib0/observable.js"() {
    init_map();
    init_set();
    init_array();
    ObservableV2 = class {
      constructor() {
        this._observers = create();
      }
      /**
       * @template {keyof EVENTS & string} NAME
       * @param {NAME} name
       * @param {EVENTS[NAME]} f
       */
      on(name, f) {
        setIfUndefined(
          this._observers,
          /** @type {string} */
          name,
          create2
        ).add(f);
        return f;
      }
      /**
       * @template {keyof EVENTS & string} NAME
       * @param {NAME} name
       * @param {EVENTS[NAME]} f
       */
      once(name, f) {
        const _f = (...args2) => {
          this.off(
            name,
            /** @type {any} */
            _f
          );
          f(...args2);
        };
        this.on(
          name,
          /** @type {any} */
          _f
        );
      }
      /**
       * @template {keyof EVENTS & string} NAME
       * @param {NAME} name
       * @param {EVENTS[NAME]} f
       */
      off(name, f) {
        const observers = this._observers.get(name);
        if (observers !== void 0) {
          observers.delete(f);
          if (observers.size === 0) {
            this._observers.delete(name);
          }
        }
      }
      /**
       * Emit a named event. All registered event listeners that listen to the
       * specified name will receive the event.
       *
       * @todo This should catch exceptions
       *
       * @template {keyof EVENTS & string} NAME
       * @param {NAME} name The event name.
       * @param {Parameters<EVENTS[NAME]>} args The arguments that are applied to the event listener.
       */
      emit(name, args2) {
        return from((this._observers.get(name) || create()).values()).forEach((f) => f(...args2));
      }
      destroy() {
        this._observers = create();
      }
    };
    Observable = class {
      constructor() {
        this._observers = create();
      }
      /**
       * @param {N} name
       * @param {function} f
       */
      on(name, f) {
        setIfUndefined(this._observers, name, create2).add(f);
      }
      /**
       * @param {N} name
       * @param {function} f
       */
      once(name, f) {
        const _f = (...args2) => {
          this.off(name, _f);
          f(...args2);
        };
        this.on(name, _f);
      }
      /**
       * @param {N} name
       * @param {function} f
       */
      off(name, f) {
        const observers = this._observers.get(name);
        if (observers !== void 0) {
          observers.delete(f);
          if (observers.size === 0) {
            this._observers.delete(name);
          }
        }
      }
      /**
       * Emit a named event. All registered event listeners that listen to the
       * specified name will receive the event.
       *
       * @todo This should catch exceptions
       *
       * @param {N} name The event name.
       * @param {Array<any>} args The arguments that are applied to the event listener.
       */
      emit(name, args2) {
        return from((this._observers.get(name) || create()).values()).forEach((f) => f(...args2));
      }
      destroy() {
        this._observers = create();
      }
    };
  }
});

// node_modules/lib0/math.js
var floor, abs, min, max, isNaN, pow, isNegativeZero;
var init_math = __esm({
  "node_modules/lib0/math.js"() {
    floor = Math.floor;
    abs = Math.abs;
    min = (a, b) => a < b ? a : b;
    max = (a, b) => a > b ? a : b;
    isNaN = Number.isNaN;
    pow = Math.pow;
    isNegativeZero = (n) => n !== 0 ? n < 0 : 1 / n < 0;
  }
});

// node_modules/lib0/binary.js
var BIT1, BIT2, BIT3, BIT4, BIT6, BIT7, BIT8, BIT18, BIT19, BIT20, BIT21, BIT22, BIT23, BIT24, BIT25, BIT26, BIT27, BIT28, BIT29, BIT30, BIT31, BIT32, BITS5, BITS6, BITS7, BITS17, BITS18, BITS19, BITS20, BITS21, BITS22, BITS23, BITS24, BITS25, BITS26, BITS27, BITS28, BITS29, BITS30, BITS31;
var init_binary = __esm({
  "node_modules/lib0/binary.js"() {
    BIT1 = 1;
    BIT2 = 2;
    BIT3 = 4;
    BIT4 = 8;
    BIT6 = 32;
    BIT7 = 64;
    BIT8 = 128;
    BIT18 = 1 << 17;
    BIT19 = 1 << 18;
    BIT20 = 1 << 19;
    BIT21 = 1 << 20;
    BIT22 = 1 << 21;
    BIT23 = 1 << 22;
    BIT24 = 1 << 23;
    BIT25 = 1 << 24;
    BIT26 = 1 << 25;
    BIT27 = 1 << 26;
    BIT28 = 1 << 27;
    BIT29 = 1 << 28;
    BIT30 = 1 << 29;
    BIT31 = 1 << 30;
    BIT32 = 1 << 31;
    BITS5 = 31;
    BITS6 = 63;
    BITS7 = 127;
    BITS17 = BIT18 - 1;
    BITS18 = BIT19 - 1;
    BITS19 = BIT20 - 1;
    BITS20 = BIT21 - 1;
    BITS21 = BIT22 - 1;
    BITS22 = BIT23 - 1;
    BITS23 = BIT24 - 1;
    BITS24 = BIT25 - 1;
    BITS25 = BIT26 - 1;
    BITS26 = BIT27 - 1;
    BITS27 = BIT28 - 1;
    BITS28 = BIT29 - 1;
    BITS29 = BIT30 - 1;
    BITS30 = BIT31 - 1;
    BITS31 = 2147483647;
  }
});

// node_modules/lib0/number.js
var MAX_SAFE_INTEGER, MIN_SAFE_INTEGER, LOWEST_INT32, isInteger, isNaN2, parseInt2;
var init_number = __esm({
  "node_modules/lib0/number.js"() {
    init_math();
    MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER;
    MIN_SAFE_INTEGER = Number.MIN_SAFE_INTEGER;
    LOWEST_INT32 = 1 << 31;
    isInteger = Number.isInteger || ((num) => typeof num === "number" && isFinite(num) && floor(num) === num);
    isNaN2 = Number.isNaN;
    parseInt2 = Number.parseInt;
  }
});

// node_modules/lib0/string.js
var fromCharCode, fromCodePoint, MAX_UTF16_CHARACTER, toLowerCase, trimLeftRegex, trimLeft, fromCamelCaseRegex, fromCamelCase, _encodeUtf8Polyfill, utf8TextEncoder, _encodeUtf8Native, encodeUtf8, utf8TextDecoder, repeat;
var init_string = __esm({
  "node_modules/lib0/string.js"() {
    init_array();
    fromCharCode = String.fromCharCode;
    fromCodePoint = String.fromCodePoint;
    MAX_UTF16_CHARACTER = fromCharCode(65535);
    toLowerCase = (s) => s.toLowerCase();
    trimLeftRegex = /^\s*/g;
    trimLeft = (s) => s.replace(trimLeftRegex, "");
    fromCamelCaseRegex = /([A-Z])/g;
    fromCamelCase = (s, separator) => trimLeft(s.replace(fromCamelCaseRegex, (match) => `${separator}${toLowerCase(match)}`));
    _encodeUtf8Polyfill = (str) => {
      const encodedString = unescape(encodeURIComponent(str));
      const len = encodedString.length;
      const buf = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        buf[i] = /** @type {number} */
        encodedString.codePointAt(i);
      }
      return buf;
    };
    utf8TextEncoder = /** @type {TextEncoder} */
    typeof TextEncoder !== "undefined" ? new TextEncoder() : null;
    _encodeUtf8Native = (str) => utf8TextEncoder.encode(str);
    encodeUtf8 = utf8TextEncoder ? _encodeUtf8Native : _encodeUtf8Polyfill;
    utf8TextDecoder = typeof TextDecoder === "undefined" ? null : new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
    if (utf8TextDecoder && utf8TextDecoder.decode(new Uint8Array()).length === 1) {
      utf8TextDecoder = null;
    }
    repeat = (source, n) => unfold(n, () => source).join("");
  }
});

// node_modules/lib0/encoding.js
var Encoder, createEncoder, length, toUint8Array, verifyLen, write, writeUint8, writeVarUint, writeVarInt, _strBuffer, _maxStrBSize, _writeVarStringNative, _writeVarStringPolyfill, writeVarString, writeBinaryEncoder, writeUint8Array, writeVarUint8Array, writeOnDataView, writeFloat32, writeFloat64, writeBigInt64, floatTestBed, isFloat32, writeAny, RleEncoder, flushUintOptRleEncoder, UintOptRleEncoder, flushIntDiffOptRleEncoder, IntDiffOptRleEncoder, StringEncoder;
var init_encoding = __esm({
  "node_modules/lib0/encoding.js"() {
    init_math();
    init_number();
    init_binary();
    init_string();
    init_array();
    Encoder = class {
      constructor() {
        this.cpos = 0;
        this.cbuf = new Uint8Array(100);
        this.bufs = [];
      }
    };
    createEncoder = () => new Encoder();
    length = (encoder) => {
      let len = encoder.cpos;
      for (let i = 0; i < encoder.bufs.length; i++) {
        len += encoder.bufs[i].length;
      }
      return len;
    };
    toUint8Array = (encoder) => {
      const uint8arr = new Uint8Array(length(encoder));
      let curPos = 0;
      for (let i = 0; i < encoder.bufs.length; i++) {
        const d = encoder.bufs[i];
        uint8arr.set(d, curPos);
        curPos += d.length;
      }
      uint8arr.set(new Uint8Array(encoder.cbuf.buffer, 0, encoder.cpos), curPos);
      return uint8arr;
    };
    verifyLen = (encoder, len) => {
      const bufferLen = encoder.cbuf.length;
      if (bufferLen - encoder.cpos < len) {
        encoder.bufs.push(new Uint8Array(encoder.cbuf.buffer, 0, encoder.cpos));
        encoder.cbuf = new Uint8Array(max(bufferLen, len) * 2);
        encoder.cpos = 0;
      }
    };
    write = (encoder, num) => {
      const bufferLen = encoder.cbuf.length;
      if (encoder.cpos === bufferLen) {
        encoder.bufs.push(encoder.cbuf);
        encoder.cbuf = new Uint8Array(bufferLen * 2);
        encoder.cpos = 0;
      }
      encoder.cbuf[encoder.cpos++] = num;
    };
    writeUint8 = write;
    writeVarUint = (encoder, num) => {
      while (num > BITS7) {
        write(encoder, BIT8 | BITS7 & num);
        num = floor(num / 128);
      }
      write(encoder, BITS7 & num);
    };
    writeVarInt = (encoder, num) => {
      const isNegative = isNegativeZero(num);
      if (isNegative) {
        num = -num;
      }
      write(encoder, (num > BITS6 ? BIT8 : 0) | (isNegative ? BIT7 : 0) | BITS6 & num);
      num = floor(num / 64);
      while (num > 0) {
        write(encoder, (num > BITS7 ? BIT8 : 0) | BITS7 & num);
        num = floor(num / 128);
      }
    };
    _strBuffer = new Uint8Array(3e4);
    _maxStrBSize = _strBuffer.length / 3;
    _writeVarStringNative = (encoder, str) => {
      if (str.length < _maxStrBSize) {
        const written = utf8TextEncoder.encodeInto(str, _strBuffer).written || 0;
        writeVarUint(encoder, written);
        for (let i = 0; i < written; i++) {
          write(encoder, _strBuffer[i]);
        }
      } else {
        writeVarUint8Array(encoder, encodeUtf8(str));
      }
    };
    _writeVarStringPolyfill = (encoder, str) => {
      const encodedString = unescape(encodeURIComponent(str));
      const len = encodedString.length;
      writeVarUint(encoder, len);
      for (let i = 0; i < len; i++) {
        write(
          encoder,
          /** @type {number} */
          encodedString.codePointAt(i)
        );
      }
    };
    writeVarString = utf8TextEncoder && /** @type {any} */
    utf8TextEncoder.encodeInto ? _writeVarStringNative : _writeVarStringPolyfill;
    writeBinaryEncoder = (encoder, append) => writeUint8Array(encoder, toUint8Array(append));
    writeUint8Array = (encoder, uint8Array) => {
      const bufferLen = encoder.cbuf.length;
      const cpos = encoder.cpos;
      const leftCopyLen = min(bufferLen - cpos, uint8Array.length);
      const rightCopyLen = uint8Array.length - leftCopyLen;
      encoder.cbuf.set(uint8Array.subarray(0, leftCopyLen), cpos);
      encoder.cpos += leftCopyLen;
      if (rightCopyLen > 0) {
        encoder.bufs.push(encoder.cbuf);
        encoder.cbuf = new Uint8Array(max(bufferLen * 2, rightCopyLen));
        encoder.cbuf.set(uint8Array.subarray(leftCopyLen));
        encoder.cpos = rightCopyLen;
      }
    };
    writeVarUint8Array = (encoder, uint8Array) => {
      writeVarUint(encoder, uint8Array.byteLength);
      writeUint8Array(encoder, uint8Array);
    };
    writeOnDataView = (encoder, len) => {
      verifyLen(encoder, len);
      const dview = new DataView(encoder.cbuf.buffer, encoder.cpos, len);
      encoder.cpos += len;
      return dview;
    };
    writeFloat32 = (encoder, num) => writeOnDataView(encoder, 4).setFloat32(0, num, false);
    writeFloat64 = (encoder, num) => writeOnDataView(encoder, 8).setFloat64(0, num, false);
    writeBigInt64 = (encoder, num) => (
      /** @type {any} */
      writeOnDataView(encoder, 8).setBigInt64(0, num, false)
    );
    floatTestBed = new DataView(new ArrayBuffer(4));
    isFloat32 = (num) => {
      floatTestBed.setFloat32(0, num);
      return floatTestBed.getFloat32(0) === num;
    };
    writeAny = (encoder, data) => {
      switch (typeof data) {
        case "string":
          write(encoder, 119);
          writeVarString(encoder, data);
          break;
        case "number":
          if (isInteger(data) && abs(data) <= BITS31) {
            write(encoder, 125);
            writeVarInt(encoder, data);
          } else if (isFloat32(data)) {
            write(encoder, 124);
            writeFloat32(encoder, data);
          } else {
            write(encoder, 123);
            writeFloat64(encoder, data);
          }
          break;
        case "bigint":
          write(encoder, 122);
          writeBigInt64(encoder, data);
          break;
        case "object":
          if (data === null) {
            write(encoder, 126);
          } else if (isArray(data)) {
            write(encoder, 117);
            writeVarUint(encoder, data.length);
            for (let i = 0; i < data.length; i++) {
              writeAny(encoder, data[i]);
            }
          } else if (data instanceof Uint8Array) {
            write(encoder, 116);
            writeVarUint8Array(encoder, data);
          } else {
            write(encoder, 118);
            const keys2 = Object.keys(data);
            writeVarUint(encoder, keys2.length);
            for (let i = 0; i < keys2.length; i++) {
              const key = keys2[i];
              writeVarString(encoder, key);
              writeAny(encoder, data[key]);
            }
          }
          break;
        case "boolean":
          write(encoder, data ? 120 : 121);
          break;
        default:
          write(encoder, 127);
      }
    };
    RleEncoder = class extends Encoder {
      /**
       * @param {function(Encoder, T):void} writer
       */
      constructor(writer) {
        super();
        this.w = writer;
        this.s = null;
        this.count = 0;
      }
      /**
       * @param {T} v
       */
      write(v) {
        if (this.s === v) {
          this.count++;
        } else {
          if (this.count > 0) {
            writeVarUint(this, this.count - 1);
          }
          this.count = 1;
          this.w(this, v);
          this.s = v;
        }
      }
    };
    flushUintOptRleEncoder = (encoder) => {
      if (encoder.count > 0) {
        writeVarInt(encoder.encoder, encoder.count === 1 ? encoder.s : -encoder.s);
        if (encoder.count > 1) {
          writeVarUint(encoder.encoder, encoder.count - 2);
        }
      }
    };
    UintOptRleEncoder = class {
      constructor() {
        this.encoder = new Encoder();
        this.s = 0;
        this.count = 0;
      }
      /**
       * @param {number} v
       */
      write(v) {
        if (this.s === v) {
          this.count++;
        } else {
          flushUintOptRleEncoder(this);
          this.count = 1;
          this.s = v;
        }
      }
      /**
       * Flush the encoded state and transform this to a Uint8Array.
       *
       * Note that this should only be called once.
       */
      toUint8Array() {
        flushUintOptRleEncoder(this);
        return toUint8Array(this.encoder);
      }
    };
    flushIntDiffOptRleEncoder = (encoder) => {
      if (encoder.count > 0) {
        const encodedDiff = encoder.diff * 2 + (encoder.count === 1 ? 0 : 1);
        writeVarInt(encoder.encoder, encodedDiff);
        if (encoder.count > 1) {
          writeVarUint(encoder.encoder, encoder.count - 2);
        }
      }
    };
    IntDiffOptRleEncoder = class {
      constructor() {
        this.encoder = new Encoder();
        this.s = 0;
        this.count = 0;
        this.diff = 0;
      }
      /**
       * @param {number} v
       */
      write(v) {
        if (this.diff === v - this.s) {
          this.s = v;
          this.count++;
        } else {
          flushIntDiffOptRleEncoder(this);
          this.count = 1;
          this.diff = v - this.s;
          this.s = v;
        }
      }
      /**
       * Flush the encoded state and transform this to a Uint8Array.
       *
       * Note that this should only be called once.
       */
      toUint8Array() {
        flushIntDiffOptRleEncoder(this);
        return toUint8Array(this.encoder);
      }
    };
    StringEncoder = class {
      constructor() {
        this.sarr = [];
        this.s = "";
        this.lensE = new UintOptRleEncoder();
      }
      /**
       * @param {string} string
       */
      write(string) {
        this.s += string;
        if (this.s.length > 19) {
          this.sarr.push(this.s);
          this.s = "";
        }
        this.lensE.write(string.length);
      }
      toUint8Array() {
        const encoder = new Encoder();
        this.sarr.push(this.s);
        this.s = "";
        writeVarString(encoder, this.sarr.join(""));
        writeUint8Array(encoder, this.lensE.toUint8Array());
        return toUint8Array(encoder);
      }
    };
  }
});

// node_modules/lib0/error.js
var create3, methodUnimplemented, unexpectedCase;
var init_error = __esm({
  "node_modules/lib0/error.js"() {
    create3 = (s) => new Error(s);
    methodUnimplemented = () => {
      throw create3("Method unimplemented");
    };
    unexpectedCase = () => {
      throw create3("Unexpected case");
    };
  }
});

// node_modules/lib0/decoding.js
var errorUnexpectedEndOfArray, errorIntegerOutOfRange, Decoder, createDecoder, hasContent, readUint8Array, readVarUint8Array, readUint8, readVarUint, readVarInt, _readVarStringPolyfill, _readVarStringNative, readVarString, readFromDataView, readFloat32, readFloat64, readBigInt64, readAnyLookupTable, readAny, RleDecoder, UintOptRleDecoder, IntDiffOptRleDecoder, StringDecoder;
var init_decoding = __esm({
  "node_modules/lib0/decoding.js"() {
    init_binary();
    init_math();
    init_number();
    init_string();
    init_error();
    errorUnexpectedEndOfArray = create3("Unexpected end of array");
    errorIntegerOutOfRange = create3("Integer out of Range");
    Decoder = class {
      /**
       * @param {Uint8Array<Buf>} uint8Array Binary data to decode
       */
      constructor(uint8Array) {
        this.arr = uint8Array;
        this.pos = 0;
      }
    };
    createDecoder = (uint8Array) => new Decoder(uint8Array);
    hasContent = (decoder) => decoder.pos !== decoder.arr.length;
    readUint8Array = (decoder, len) => {
      const view = new Uint8Array(decoder.arr.buffer, decoder.pos + decoder.arr.byteOffset, len);
      decoder.pos += len;
      return view;
    };
    readVarUint8Array = (decoder) => readUint8Array(decoder, readVarUint(decoder));
    readUint8 = (decoder) => decoder.arr[decoder.pos++];
    readVarUint = (decoder) => {
      let num = 0;
      let mult = 1;
      const len = decoder.arr.length;
      while (decoder.pos < len) {
        const r = decoder.arr[decoder.pos++];
        num = num + (r & BITS7) * mult;
        mult *= 128;
        if (r < BIT8) {
          return num;
        }
        if (num > MAX_SAFE_INTEGER) {
          throw errorIntegerOutOfRange;
        }
      }
      throw errorUnexpectedEndOfArray;
    };
    readVarInt = (decoder) => {
      let r = decoder.arr[decoder.pos++];
      let num = r & BITS6;
      let mult = 64;
      const sign = (r & BIT7) > 0 ? -1 : 1;
      if ((r & BIT8) === 0) {
        return sign * num;
      }
      const len = decoder.arr.length;
      while (decoder.pos < len) {
        r = decoder.arr[decoder.pos++];
        num = num + (r & BITS7) * mult;
        mult *= 128;
        if (r < BIT8) {
          return sign * num;
        }
        if (num > MAX_SAFE_INTEGER) {
          throw errorIntegerOutOfRange;
        }
      }
      throw errorUnexpectedEndOfArray;
    };
    _readVarStringPolyfill = (decoder) => {
      let remainingLen = readVarUint(decoder);
      if (remainingLen === 0) {
        return "";
      } else {
        let encodedString = String.fromCodePoint(readUint8(decoder));
        if (--remainingLen < 100) {
          while (remainingLen--) {
            encodedString += String.fromCodePoint(readUint8(decoder));
          }
        } else {
          while (remainingLen > 0) {
            const nextLen = remainingLen < 1e4 ? remainingLen : 1e4;
            const bytes = decoder.arr.subarray(decoder.pos, decoder.pos + nextLen);
            decoder.pos += nextLen;
            encodedString += String.fromCodePoint.apply(
              null,
              /** @type {any} */
              bytes
            );
            remainingLen -= nextLen;
          }
        }
        return decodeURIComponent(escape(encodedString));
      }
    };
    _readVarStringNative = (decoder) => (
      /** @type any */
      utf8TextDecoder.decode(readVarUint8Array(decoder))
    );
    readVarString = utf8TextDecoder ? _readVarStringNative : _readVarStringPolyfill;
    readFromDataView = (decoder, len) => {
      const dv = new DataView(decoder.arr.buffer, decoder.arr.byteOffset + decoder.pos, len);
      decoder.pos += len;
      return dv;
    };
    readFloat32 = (decoder) => readFromDataView(decoder, 4).getFloat32(0, false);
    readFloat64 = (decoder) => readFromDataView(decoder, 8).getFloat64(0, false);
    readBigInt64 = (decoder) => (
      /** @type {any} */
      readFromDataView(decoder, 8).getBigInt64(0, false)
    );
    readAnyLookupTable = [
      (decoder) => void 0,
      // CASE 127: undefined
      (decoder) => null,
      // CASE 126: null
      readVarInt,
      // CASE 125: integer
      readFloat32,
      // CASE 124: float32
      readFloat64,
      // CASE 123: float64
      readBigInt64,
      // CASE 122: bigint
      (decoder) => false,
      // CASE 121: boolean (false)
      (decoder) => true,
      // CASE 120: boolean (true)
      readVarString,
      // CASE 119: string
      (decoder) => {
        const len = readVarUint(decoder);
        const obj = {};
        for (let i = 0; i < len; i++) {
          const key = readVarString(decoder);
          obj[key] = readAny(decoder);
        }
        return obj;
      },
      (decoder) => {
        const len = readVarUint(decoder);
        const arr = [];
        for (let i = 0; i < len; i++) {
          arr.push(readAny(decoder));
        }
        return arr;
      },
      readVarUint8Array
      // CASE 116: Uint8Array
    ];
    readAny = (decoder) => readAnyLookupTable[127 - readUint8(decoder)](decoder);
    RleDecoder = class extends Decoder {
      /**
       * @param {Uint8Array} uint8Array
       * @param {function(Decoder):T} reader
       */
      constructor(uint8Array, reader) {
        super(uint8Array);
        this.reader = reader;
        this.s = null;
        this.count = 0;
      }
      read() {
        if (this.count === 0) {
          this.s = this.reader(this);
          if (hasContent(this)) {
            this.count = readVarUint(this) + 1;
          } else {
            this.count = -1;
          }
        }
        this.count--;
        return (
          /** @type {T} */
          this.s
        );
      }
    };
    UintOptRleDecoder = class extends Decoder {
      /**
       * @param {Uint8Array} uint8Array
       */
      constructor(uint8Array) {
        super(uint8Array);
        this.s = 0;
        this.count = 0;
      }
      read() {
        if (this.count === 0) {
          this.s = readVarInt(this);
          const isNegative = isNegativeZero(this.s);
          this.count = 1;
          if (isNegative) {
            this.s = -this.s;
            this.count = readVarUint(this) + 2;
          }
        }
        this.count--;
        return (
          /** @type {number} */
          this.s
        );
      }
    };
    IntDiffOptRleDecoder = class extends Decoder {
      /**
       * @param {Uint8Array} uint8Array
       */
      constructor(uint8Array) {
        super(uint8Array);
        this.s = 0;
        this.count = 0;
        this.diff = 0;
      }
      /**
       * @return {number}
       */
      read() {
        if (this.count === 0) {
          const diff = readVarInt(this);
          const hasCount = diff & 1;
          this.diff = floor(diff / 2);
          this.count = 1;
          if (hasCount) {
            this.count = readVarUint(this) + 2;
          }
        }
        this.s += this.diff;
        this.count--;
        return this.s;
      }
    };
    StringDecoder = class {
      /**
       * @param {Uint8Array} uint8Array
       */
      constructor(uint8Array) {
        this.decoder = new UintOptRleDecoder(uint8Array);
        this.str = readVarString(this.decoder);
        this.spos = 0;
      }
      /**
       * @return {string}
       */
      read() {
        const end = this.spos + this.decoder.read();
        const res = this.str.slice(this.spos, end);
        this.spos = end;
        return res;
      }
    };
  }
});

// node_modules/lib0/webcrypto.node.js
var import_node_crypto, subtle, getRandomValues;
var init_webcrypto_node = __esm({
  "node_modules/lib0/webcrypto.node.js"() {
    import_node_crypto = require("node:crypto");
    subtle = /** @type {any} */
    import_node_crypto.webcrypto.subtle;
    getRandomValues = /** @type {any} */
    import_node_crypto.webcrypto.getRandomValues.bind(import_node_crypto.webcrypto);
  }
});

// node_modules/lib0/random.js
var uint32, uuidv4Template, uuidv4;
var init_random = __esm({
  "node_modules/lib0/random.js"() {
    init_webcrypto_node();
    uint32 = () => getRandomValues(new Uint32Array(1))[0];
    uuidv4Template = "10000000-1000-4000-8000" + -1e11;
    uuidv4 = () => uuidv4Template.replace(
      /[018]/g,
      /** @param {number} c */
      (c) => (c ^ uint32() & 15 >> c / 4).toString(16)
    );
  }
});

// node_modules/lib0/time.js
var getUnixTime;
var init_time = __esm({
  "node_modules/lib0/time.js"() {
    getUnixTime = Date.now;
  }
});

// node_modules/lib0/promise.js
var create4, all;
var init_promise = __esm({
  "node_modules/lib0/promise.js"() {
    create4 = (f) => (
      /** @type {Promise<T>} */
      new Promise(f)
    );
    all = Promise.all.bind(Promise);
  }
});

// node_modules/lib0/conditions.js
var undefinedToNull;
var init_conditions = __esm({
  "node_modules/lib0/conditions.js"() {
    undefinedToNull = (v) => v === void 0 ? null : v;
  }
});

// node_modules/lib0/storage.js
var VarStoragePolyfill, _localStorage, usePolyfill, varStorage, onChange, offChange;
var init_storage = __esm({
  "node_modules/lib0/storage.js"() {
    VarStoragePolyfill = class {
      constructor() {
        this.map = /* @__PURE__ */ new Map();
      }
      /**
       * @param {string} key
       * @param {any} newValue
       */
      setItem(key, newValue) {
        this.map.set(key, newValue);
      }
      /**
       * @param {string} key
       */
      getItem(key) {
        return this.map.get(key);
      }
    };
    _localStorage = new VarStoragePolyfill();
    usePolyfill = true;
    try {
      if (typeof localStorage !== "undefined" && localStorage) {
        _localStorage = localStorage;
        usePolyfill = false;
      }
    } catch (e) {
    }
    varStorage = _localStorage;
    onChange = (eventHandler) => usePolyfill || addEventListener(
      "storage",
      /** @type {any} */
      eventHandler
    );
    offChange = (eventHandler) => usePolyfill || removeEventListener(
      "storage",
      /** @type {any} */
      eventHandler
    );
  }
});

// node_modules/lib0/trait/equality.js
var EqualityTraitSymbol, equals;
var init_equality = __esm({
  "node_modules/lib0/trait/equality.js"() {
    EqualityTraitSymbol = Symbol("Equality");
    equals = (a, b) => a === b || !!a?.[EqualityTraitSymbol]?.(b) || false;
  }
});

// node_modules/lib0/object.js
var assign, keys, forEach, map, size, isEmpty, every, hasProperty, equalFlat, freeze, deepFreeze;
var init_object = __esm({
  "node_modules/lib0/object.js"() {
    init_equality();
    assign = Object.assign;
    keys = Object.keys;
    forEach = (obj, f) => {
      for (const key in obj) {
        f(obj[key], key);
      }
    };
    map = (obj, f) => {
      const results = [];
      for (const key in obj) {
        results.push(f(obj[key], key));
      }
      return results;
    };
    size = (obj) => keys(obj).length;
    isEmpty = (obj) => {
      for (const _k in obj) {
        return false;
      }
      return true;
    };
    every = (obj, f) => {
      for (const key in obj) {
        if (!f(obj[key], key)) {
          return false;
        }
      }
      return true;
    };
    hasProperty = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
    equalFlat = (a, b) => a === b || size(a) === size(b) && every(a, (val, key) => (val !== void 0 || hasProperty(b, key)) && equals(b[key], val));
    freeze = Object.freeze;
    deepFreeze = (o) => {
      for (const key in o) {
        const c = o[key];
        if (typeof c === "object" || typeof c === "function") {
          deepFreeze(o[key]);
        }
      }
      return freeze(o);
    };
  }
});

// node_modules/lib0/function.js
var callAll, id, equalityDeep, isOneOf;
var init_function = __esm({
  "node_modules/lib0/function.js"() {
    init_object();
    init_equality();
    callAll = (fs, args2, i = 0) => {
      try {
        for (; i < fs.length; i++) {
          fs[i](...args2);
        }
      } finally {
        if (i < fs.length) {
          callAll(fs, args2, i + 1);
        }
      }
    };
    id = (a) => a;
    equalityDeep = (a, b) => {
      if (a === b) {
        return true;
      }
      if (a == null || b == null || a.constructor !== b.constructor && (a.constructor || Object) !== (b.constructor || Object)) {
        return false;
      }
      if (a[EqualityTraitSymbol] != null) {
        return a[EqualityTraitSymbol](b);
      }
      switch (a.constructor) {
        case ArrayBuffer:
          a = new Uint8Array(a);
          b = new Uint8Array(b);
        case Uint8Array: {
          if (a.byteLength !== b.byteLength) {
            return false;
          }
          for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) {
              return false;
            }
          }
          break;
        }
        case Set: {
          if (a.size !== b.size) {
            return false;
          }
          for (const value of a) {
            if (!b.has(value)) {
              return false;
            }
          }
          break;
        }
        case Map: {
          if (a.size !== b.size) {
            return false;
          }
          for (const key of a.keys()) {
            if (!b.has(key) || !equalityDeep(a.get(key), b.get(key))) {
              return false;
            }
          }
          break;
        }
        case void 0:
        case Object:
          if (size(a) !== size(b)) {
            return false;
          }
          for (const key in a) {
            if (!hasProperty(a, key) || !equalityDeep(a[key], b[key])) {
              return false;
            }
          }
          break;
        case Array:
          if (a.length !== b.length) {
            return false;
          }
          for (let i = 0; i < a.length; i++) {
            if (!equalityDeep(a[i], b[i])) {
              return false;
            }
          }
          break;
        default:
          return false;
      }
      return true;
    };
    isOneOf = (value, options) => options.includes(value);
  }
});

// node_modules/lib0/environment.js
var isNode, isBrowser, isMac, params, args, computeParams, hasParam, getVariable, hasConf, production, forceColor, supportsColor;
var init_environment = __esm({
  "node_modules/lib0/environment.js"() {
    init_map();
    init_string();
    init_conditions();
    init_storage();
    init_function();
    isNode = typeof process !== "undefined" && process.release && /node|io\.js/.test(process.release.name) && Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]";
    isBrowser = typeof window !== "undefined" && typeof document !== "undefined" && !isNode;
    isMac = typeof navigator !== "undefined" ? /Mac/.test(navigator.platform) : false;
    args = [];
    computeParams = () => {
      if (params === void 0) {
        if (isNode) {
          params = create();
          const pargs = process.argv;
          let currParamName = null;
          for (let i = 0; i < pargs.length; i++) {
            const parg = pargs[i];
            if (parg[0] === "-") {
              if (currParamName !== null) {
                params.set(currParamName, "");
              }
              currParamName = parg;
            } else {
              if (currParamName !== null) {
                params.set(currParamName, parg);
                currParamName = null;
              } else {
                args.push(parg);
              }
            }
          }
          if (currParamName !== null) {
            params.set(currParamName, "");
          }
        } else if (typeof location === "object") {
          params = create();
          (location.search || "?").slice(1).split("&").forEach((kv) => {
            if (kv.length !== 0) {
              const [key, value] = kv.split("=");
              params.set(`--${fromCamelCase(key, "-")}`, value);
              params.set(`-${fromCamelCase(key, "-")}`, value);
            }
          });
        } else {
          params = create();
        }
      }
      return params;
    };
    hasParam = (name) => computeParams().has(name);
    getVariable = (name) => isNode ? undefinedToNull(process.env[name.toUpperCase().replaceAll("-", "_")]) : undefinedToNull(varStorage.getItem(name));
    hasConf = (name) => hasParam("--" + name) || getVariable(name) !== null;
    production = hasConf("production");
    forceColor = isNode && isOneOf(process.env.FORCE_COLOR, ["true", "1", "2"]);
    supportsColor = forceColor || !hasParam("--no-colors") && // @todo deprecate --no-colors
    !hasConf("no-color") && (!isNode || process.stdout.isTTY) && (!isNode || hasParam("--color") || getVariable("COLORTERM") !== null || (getVariable("TERM") || "").includes("color"));
  }
});

// node_modules/lib0/buffer.js
var createUint8ArrayFromLen, createUint8ArrayViewFromArrayBuffer, createUint8ArrayFromArrayBuffer, toBase64Browser, toBase64Node, fromBase64Browser, fromBase64Node, toBase64, fromBase64, copyUint8Array;
var init_buffer = __esm({
  "node_modules/lib0/buffer.js"() {
    init_string();
    init_environment();
    createUint8ArrayFromLen = (len) => new Uint8Array(len);
    createUint8ArrayViewFromArrayBuffer = (buffer, byteOffset, length2) => new Uint8Array(buffer, byteOffset, length2);
    createUint8ArrayFromArrayBuffer = (buffer) => new Uint8Array(buffer);
    toBase64Browser = (bytes) => {
      let s = "";
      for (let i = 0; i < bytes.byteLength; i++) {
        s += fromCharCode(bytes[i]);
      }
      return btoa(s);
    };
    toBase64Node = (bytes) => Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString("base64");
    fromBase64Browser = (s) => {
      const a = atob(s);
      const bytes = createUint8ArrayFromLen(a.length);
      for (let i = 0; i < a.length; i++) {
        bytes[i] = a.charCodeAt(i);
      }
      return bytes;
    };
    fromBase64Node = (s) => {
      const buf = Buffer.from(s, "base64");
      return createUint8ArrayViewFromArrayBuffer(buf.buffer, buf.byteOffset, buf.byteLength);
    };
    toBase64 = isBrowser ? toBase64Browser : toBase64Node;
    fromBase64 = isBrowser ? fromBase64Browser : fromBase64Node;
    copyUint8Array = (uint8Array) => {
      const newBuf = createUint8ArrayFromLen(uint8Array.byteLength);
      newBuf.set(uint8Array);
      return newBuf;
    };
  }
});

// node_modules/lib0/symbol.js
var create5;
var init_symbol = __esm({
  "node_modules/lib0/symbol.js"() {
    create5 = Symbol;
  }
});

// node_modules/lib0/logging.common.js
var BOLD, UNBOLD, BLUE, GREY, GREEN, RED, PURPLE, ORANGE, UNCOLOR, computeNoColorLoggingArgs, lastLoggingTime;
var init_logging_common = __esm({
  "node_modules/lib0/logging.common.js"() {
    init_symbol();
    init_time();
    BOLD = create5();
    UNBOLD = create5();
    BLUE = create5();
    GREY = create5();
    GREEN = create5();
    RED = create5();
    PURPLE = create5();
    ORANGE = create5();
    UNCOLOR = create5();
    computeNoColorLoggingArgs = (args2) => {
      if (args2.length === 1 && args2[0]?.constructor === Function) {
        args2 = /** @type {Array<string|Symbol|Object|number>} */
        /** @type {[function]} */
        args2[0]();
      }
      const strBuilder = [];
      const logArgs = [];
      let i = 0;
      for (; i < args2.length; i++) {
        const arg = args2[i];
        if (arg === void 0) {
          break;
        } else if (arg.constructor === String || arg.constructor === Number) {
          strBuilder.push(arg);
        } else if (arg.constructor === Object) {
          break;
        }
      }
      if (i > 0) {
        logArgs.push(strBuilder.join(""));
      }
      for (; i < args2.length; i++) {
        const arg = args2[i];
        if (!(arg instanceof Symbol)) {
          logArgs.push(arg);
        }
      }
      return logArgs;
    };
    lastLoggingTime = getUnixTime();
  }
});

// node_modules/lib0/logging.node.js
var _nodeStyleMap, computeNodeLoggingArgs, computeLoggingArgs, print, warn;
var init_logging_node = __esm({
  "node_modules/lib0/logging.node.js"() {
    init_environment();
    init_logging_common();
    init_logging_common();
    _nodeStyleMap = {
      [BOLD]: "\x1B[1m",
      [UNBOLD]: "\x1B[2m",
      [BLUE]: "\x1B[34m",
      [GREEN]: "\x1B[32m",
      [GREY]: "\x1B[37m",
      [RED]: "\x1B[31m",
      [PURPLE]: "\x1B[35m",
      [ORANGE]: "\x1B[38;5;208m",
      [UNCOLOR]: "\x1B[0m"
    };
    computeNodeLoggingArgs = (args2) => {
      if (args2.length === 1 && args2[0]?.constructor === Function) {
        args2 = /** @type {Array<string|Symbol|Object|number>} */
        /** @type {[function]} */
        args2[0]();
      }
      const strBuilder = [];
      const logArgs = [];
      let i = 0;
      for (; i < args2.length; i++) {
        const arg = args2[i];
        const style = _nodeStyleMap[arg];
        if (style !== void 0) {
          strBuilder.push(style);
        } else {
          if (arg === void 0) {
            break;
          } else if (arg.constructor === String || arg.constructor === Number) {
            strBuilder.push(arg);
          } else {
            break;
          }
        }
      }
      if (i > 0) {
        strBuilder.push("\x1B[0m");
        logArgs.push(strBuilder.join(""));
      }
      for (; i < args2.length; i++) {
        const arg = args2[i];
        if (!(arg instanceof Symbol)) {
          logArgs.push(arg);
        }
      }
      return logArgs;
    };
    computeLoggingArgs = supportsColor ? computeNodeLoggingArgs : computeNoColorLoggingArgs;
    print = (...args2) => {
      console.log(...computeLoggingArgs(args2));
    };
    warn = (...args2) => {
      console.warn(...computeLoggingArgs(args2));
    };
  }
});

// node_modules/lib0/iterator.js
var createIterator, iteratorFilter, iteratorMap;
var init_iterator = __esm({
  "node_modules/lib0/iterator.js"() {
    createIterator = (next) => ({
      /**
       * @return {IterableIterator<T>}
       */
      [Symbol.iterator]() {
        return this;
      },
      // @ts-ignore
      next
    });
    iteratorFilter = (iterator, filter) => createIterator(() => {
      let res;
      do {
        res = iterator.next();
      } while (!res.done && !filter(res.value));
      return res;
    });
    iteratorMap = (iterator, fmap) => createIterator(() => {
      const { done, value } = iterator.next();
      return { done, value: done ? void 0 : fmap(value) };
    });
  }
});

// node_modules/yjs/dist/yjs.mjs
var yjs_exports = {};
__export(yjs_exports, {
  AbsolutePosition: () => AbsolutePosition,
  AbstractConnector: () => AbstractConnector,
  AbstractStruct: () => AbstractStruct,
  AbstractType: () => AbstractType,
  Array: () => YArray,
  ContentAny: () => ContentAny,
  ContentBinary: () => ContentBinary,
  ContentDeleted: () => ContentDeleted,
  ContentDoc: () => ContentDoc,
  ContentEmbed: () => ContentEmbed,
  ContentFormat: () => ContentFormat,
  ContentJSON: () => ContentJSON,
  ContentString: () => ContentString,
  ContentType: () => ContentType,
  Doc: () => Doc,
  GC: () => GC,
  ID: () => ID,
  Item: () => Item,
  Map: () => YMap,
  PermanentUserData: () => PermanentUserData,
  RelativePosition: () => RelativePosition,
  Skip: () => Skip,
  Snapshot: () => Snapshot,
  Text: () => YText,
  Transaction: () => Transaction,
  UndoManager: () => UndoManager,
  UpdateDecoderV1: () => UpdateDecoderV1,
  UpdateDecoderV2: () => UpdateDecoderV2,
  UpdateEncoderV1: () => UpdateEncoderV1,
  UpdateEncoderV2: () => UpdateEncoderV2,
  XmlElement: () => YXmlElement,
  XmlFragment: () => YXmlFragment,
  XmlHook: () => YXmlHook,
  XmlText: () => YXmlText,
  YArrayEvent: () => YArrayEvent,
  YEvent: () => YEvent,
  YMapEvent: () => YMapEvent,
  YTextEvent: () => YTextEvent,
  YXmlEvent: () => YXmlEvent,
  applyUpdate: () => applyUpdate,
  applyUpdateV2: () => applyUpdateV2,
  cleanupYTextFormatting: () => cleanupYTextFormatting,
  compareIDs: () => compareIDs,
  compareRelativePositions: () => compareRelativePositions,
  convertUpdateFormatV1ToV2: () => convertUpdateFormatV1ToV2,
  convertUpdateFormatV2ToV1: () => convertUpdateFormatV2ToV1,
  createAbsolutePositionFromRelativePosition: () => createAbsolutePositionFromRelativePosition,
  createDeleteSet: () => createDeleteSet,
  createDeleteSetFromStructStore: () => createDeleteSetFromStructStore,
  createDocFromSnapshot: () => createDocFromSnapshot,
  createID: () => createID,
  createRelativePositionFromJSON: () => createRelativePositionFromJSON,
  createRelativePositionFromTypeIndex: () => createRelativePositionFromTypeIndex,
  createSnapshot: () => createSnapshot,
  decodeRelativePosition: () => decodeRelativePosition,
  decodeSnapshot: () => decodeSnapshot,
  decodeSnapshotV2: () => decodeSnapshotV2,
  decodeStateVector: () => decodeStateVector,
  decodeUpdate: () => decodeUpdate,
  decodeUpdateV2: () => decodeUpdateV2,
  diffUpdate: () => diffUpdate,
  diffUpdateV2: () => diffUpdateV2,
  emptySnapshot: () => emptySnapshot,
  encodeRelativePosition: () => encodeRelativePosition,
  encodeSnapshot: () => encodeSnapshot,
  encodeSnapshotV2: () => encodeSnapshotV2,
  encodeStateAsUpdate: () => encodeStateAsUpdate,
  encodeStateAsUpdateV2: () => encodeStateAsUpdateV2,
  encodeStateVector: () => encodeStateVector,
  encodeStateVectorFromUpdate: () => encodeStateVectorFromUpdate,
  encodeStateVectorFromUpdateV2: () => encodeStateVectorFromUpdateV2,
  equalDeleteSets: () => equalDeleteSets,
  equalSnapshots: () => equalSnapshots,
  findIndexSS: () => findIndexSS,
  findRootTypeKey: () => findRootTypeKey,
  getItem: () => getItem,
  getItemCleanEnd: () => getItemCleanEnd,
  getItemCleanStart: () => getItemCleanStart,
  getState: () => getState,
  getTypeChildren: () => getTypeChildren,
  isDeleted: () => isDeleted,
  isParentOf: () => isParentOf,
  iterateDeletedStructs: () => iterateDeletedStructs,
  logType: () => logType,
  logUpdate: () => logUpdate,
  logUpdateV2: () => logUpdateV2,
  mergeDeleteSets: () => mergeDeleteSets,
  mergeUpdates: () => mergeUpdates,
  mergeUpdatesV2: () => mergeUpdatesV2,
  obfuscateUpdate: () => obfuscateUpdate,
  obfuscateUpdateV2: () => obfuscateUpdateV2,
  parseUpdateMeta: () => parseUpdateMeta,
  parseUpdateMetaV2: () => parseUpdateMetaV2,
  readUpdate: () => readUpdate,
  readUpdateV2: () => readUpdateV2,
  relativePositionToJSON: () => relativePositionToJSON,
  snapshot: () => snapshot,
  snapshotContainsUpdate: () => snapshotContainsUpdate,
  transact: () => transact,
  tryGc: () => tryGc,
  typeListToArraySnapshot: () => typeListToArraySnapshot,
  typeMapGetAllSnapshot: () => typeMapGetAllSnapshot,
  typeMapGetSnapshot: () => typeMapGetSnapshot
});
function* lazyStructReaderGenerator(decoder) {
  const numOfStateUpdates = readVarUint(decoder.restDecoder);
  for (let i = 0; i < numOfStateUpdates; i++) {
    const numberOfStructs = readVarUint(decoder.restDecoder);
    const client = decoder.readClient();
    let clock = readVarUint(decoder.restDecoder);
    for (let i2 = 0; i2 < numberOfStructs; i2++) {
      const info = decoder.readInfo();
      if (info === 10) {
        const len = readVarUint(decoder.restDecoder);
        yield new Skip(createID(client, clock), len);
        clock += len;
      } else if ((BITS5 & info) !== 0) {
        const cantCopyParentInfo = (info & (BIT7 | BIT8)) === 0;
        const struct = new Item(
          createID(client, clock),
          null,
          // left
          (info & BIT8) === BIT8 ? decoder.readLeftID() : null,
          // origin
          null,
          // right
          (info & BIT7) === BIT7 ? decoder.readRightID() : null,
          // right origin
          // @ts-ignore Force writing a string here.
          cantCopyParentInfo ? decoder.readParentInfo() ? decoder.readString() : decoder.readLeftID() : null,
          // parent
          cantCopyParentInfo && (info & BIT6) === BIT6 ? decoder.readString() : null,
          // parentSub
          readItemContent(decoder, info)
          // item content
        );
        yield struct;
        clock += struct.length;
      } else {
        const len = decoder.readLen();
        yield new GC(createID(client, clock), len);
        clock += len;
      }
    }
  }
}
var AbstractConnector, DeleteItem, DeleteSet, iterateDeletedStructs, findIndexDS, isDeleted, sortAndMergeDeleteSet, mergeDeleteSets, addToDeleteSet, createDeleteSet, createDeleteSetFromStructStore, writeDeleteSet, readDeleteSet, readAndApplyDeleteSet, equalDeleteSets, generateNewClientId, Doc, DSDecoderV1, UpdateDecoderV1, DSDecoderV2, UpdateDecoderV2, DSEncoderV1, UpdateEncoderV1, DSEncoderV2, UpdateEncoderV2, writeStructs, writeClientsStructs, readClientsStructRefs, integrateStructs, writeStructsFromTransaction, readUpdateV2, readUpdate, applyUpdateV2, applyUpdate, writeStateAsUpdate, encodeStateAsUpdateV2, encodeStateAsUpdate, readStateVector, decodeStateVector, writeStateVector, writeDocumentStateVector, encodeStateVectorV2, encodeStateVector, EventHandler, createEventHandler, addEventHandlerListener, removeEventHandlerListener, callEventHandlerListeners, ID, compareIDs, createID, writeID, readID, findRootTypeKey, isParentOf, logType, PermanentUserData, RelativePosition, relativePositionToJSON, createRelativePositionFromJSON, AbsolutePosition, createAbsolutePosition, createRelativePosition, createRelativePositionFromTypeIndex, writeRelativePosition, encodeRelativePosition, readRelativePosition, decodeRelativePosition, getItemWithOffset, createAbsolutePositionFromRelativePosition, compareRelativePositions, Snapshot, equalSnapshots, encodeSnapshotV2, encodeSnapshot, decodeSnapshotV2, decodeSnapshot, createSnapshot, emptySnapshot, snapshot, isVisible, splitSnapshotAffectedStructs, createDocFromSnapshot, snapshotContainsUpdateV2, snapshotContainsUpdate, StructStore, getStateVector, getState, addStruct, findIndexSS, find, getItem, findIndexCleanStart, getItemCleanStart, getItemCleanEnd, replaceStruct, iterateStructs, Transaction, writeUpdateMessageFromTransaction, addChangedTypeToTransaction, tryToMergeWithLefts, tryGcDeleteSet, tryMergeDeleteSet, tryGc, cleanupTransactions, transact, StackItem, clearUndoManagerStackItem, popStackItem, UndoManager, LazyStructReader, logUpdate, logUpdateV2, decodeUpdate, decodeUpdateV2, LazyStructWriter, mergeUpdates, encodeStateVectorFromUpdateV2, encodeStateVectorFromUpdate, parseUpdateMetaV2, parseUpdateMeta, sliceStruct, mergeUpdatesV2, diffUpdateV2, diffUpdate, flushLazyStructWriter, writeStructToLazyStructWriter, finishLazyStructWriting, convertUpdateFormat, createObfuscator, obfuscateUpdate, obfuscateUpdateV2, convertUpdateFormatV1ToV2, convertUpdateFormatV2ToV1, errorComputeChanges, YEvent, getPathTo, warnPrematureAccess, maxSearchMarker, globalSearchMarkerTimestamp, ArraySearchMarker, refreshMarkerTimestamp, overwriteMarker, markPosition, findMarker, updateMarkerChanges, getTypeChildren, callTypeObservers, AbstractType, typeListSlice, typeListToArray, typeListToArraySnapshot, typeListForEach, typeListMap, typeListCreateIterator, typeListGet, typeListInsertGenericsAfter, lengthExceeded, typeListInsertGenerics, typeListPushGenerics, typeListDelete, typeMapDelete, typeMapSet, typeMapGet, typeMapGetAll, typeMapHas, typeMapGetSnapshot, typeMapGetAllSnapshot, createMapIterator, YArrayEvent, YArray, readYArray, YMapEvent, YMap, readYMap, equalAttrs, ItemTextListPosition, findNextPosition, findPosition, insertNegatedAttributes, updateCurrentAttributes, minimizeAttributeChanges, insertAttributes, insertText, formatText, cleanupFormattingGap, cleanupContextlessFormattingGap, cleanupYTextFormatting, cleanupYTextAfterTransaction, deleteText, YTextEvent, YText, readYText, YXmlTreeWalker, YXmlFragment, readYXmlFragment, YXmlElement, readYXmlElement, YXmlEvent, YXmlHook, readYXmlHook, YXmlText, readYXmlText, AbstractStruct, structGCRefNumber, GC, ContentBinary, readContentBinary, ContentDeleted, readContentDeleted, createDocFromOpts, ContentDoc, readContentDoc, ContentEmbed, readContentEmbed, ContentFormat, readContentFormat, ContentJSON, readContentJSON, isDevMode, ContentAny, readContentAny, ContentString, readContentString, typeRefs, YArrayRefID, YMapRefID, YTextRefID, YXmlElementRefID, YXmlFragmentRefID, YXmlHookRefID, YXmlTextRefID, ContentType, readContentType, followRedone, keepItem, splitItem, isDeletedByUndoStack, redoItem, Item, readItemContent, contentRefs, structSkipRefNumber, Skip, glo, importIdentifier;
var init_yjs = __esm({
  "node_modules/yjs/dist/yjs.mjs"() {
    init_observable();
    init_array();
    init_math();
    init_map();
    init_encoding();
    init_decoding();
    init_random();
    init_promise();
    init_buffer();
    init_error();
    init_binary();
    init_function();
    init_function();
    init_set();
    init_logging_node();
    init_time();
    init_string();
    init_iterator();
    init_object();
    init_environment();
    AbstractConnector = class extends ObservableV2 {
      /**
       * @param {Doc} ydoc
       * @param {any} awareness
       */
      constructor(ydoc, awareness) {
        super();
        this.doc = ydoc;
        this.awareness = awareness;
      }
    };
    DeleteItem = class {
      /**
       * @param {number} clock
       * @param {number} len
       */
      constructor(clock, len) {
        this.clock = clock;
        this.len = len;
      }
    };
    DeleteSet = class {
      constructor() {
        this.clients = /* @__PURE__ */ new Map();
      }
    };
    iterateDeletedStructs = (transaction, ds, f) => ds.clients.forEach((deletes, clientid) => {
      const structs = (
        /** @type {Array<GC|Item>} */
        transaction.doc.store.clients.get(clientid)
      );
      if (structs != null) {
        const lastStruct = structs[structs.length - 1];
        const clockState = lastStruct.id.clock + lastStruct.length;
        for (let i = 0, del = deletes[i]; i < deletes.length && del.clock < clockState; del = deletes[++i]) {
          iterateStructs(transaction, structs, del.clock, del.len, f);
        }
      }
    });
    findIndexDS = (dis, clock) => {
      let left = 0;
      let right = dis.length - 1;
      while (left <= right) {
        const midindex = floor((left + right) / 2);
        const mid = dis[midindex];
        const midclock = mid.clock;
        if (midclock <= clock) {
          if (clock < midclock + mid.len) {
            return midindex;
          }
          left = midindex + 1;
        } else {
          right = midindex - 1;
        }
      }
      return null;
    };
    isDeleted = (ds, id2) => {
      const dis = ds.clients.get(id2.client);
      return dis !== void 0 && findIndexDS(dis, id2.clock) !== null;
    };
    sortAndMergeDeleteSet = (ds) => {
      ds.clients.forEach((dels) => {
        dels.sort((a, b) => a.clock - b.clock);
        let i, j;
        for (i = 1, j = 1; i < dels.length; i++) {
          const left = dels[j - 1];
          const right = dels[i];
          if (left.clock + left.len >= right.clock) {
            left.len = max(left.len, right.clock + right.len - left.clock);
          } else {
            if (j < i) {
              dels[j] = right;
            }
            j++;
          }
        }
        dels.length = j;
      });
    };
    mergeDeleteSets = (dss) => {
      const merged = new DeleteSet();
      for (let dssI = 0; dssI < dss.length; dssI++) {
        dss[dssI].clients.forEach((delsLeft, client) => {
          if (!merged.clients.has(client)) {
            const dels = delsLeft.slice();
            for (let i = dssI + 1; i < dss.length; i++) {
              appendTo(dels, dss[i].clients.get(client) || []);
            }
            merged.clients.set(client, dels);
          }
        });
      }
      sortAndMergeDeleteSet(merged);
      return merged;
    };
    addToDeleteSet = (ds, client, clock, length2) => {
      setIfUndefined(ds.clients, client, () => (
        /** @type {Array<DeleteItem>} */
        []
      )).push(new DeleteItem(clock, length2));
    };
    createDeleteSet = () => new DeleteSet();
    createDeleteSetFromStructStore = (ss) => {
      const ds = createDeleteSet();
      ss.clients.forEach((structs, client) => {
        const dsitems = [];
        for (let i = 0; i < structs.length; i++) {
          const struct = structs[i];
          if (struct.deleted) {
            const clock = struct.id.clock;
            let len = struct.length;
            if (i + 1 < structs.length) {
              for (let next = structs[i + 1]; i + 1 < structs.length && next.deleted; next = structs[++i + 1]) {
                len += next.length;
              }
            }
            dsitems.push(new DeleteItem(clock, len));
          }
        }
        if (dsitems.length > 0) {
          ds.clients.set(client, dsitems);
        }
      });
      return ds;
    };
    writeDeleteSet = (encoder, ds) => {
      writeVarUint(encoder.restEncoder, ds.clients.size);
      from(ds.clients.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, dsitems]) => {
        encoder.resetDsCurVal();
        writeVarUint(encoder.restEncoder, client);
        const len = dsitems.length;
        writeVarUint(encoder.restEncoder, len);
        for (let i = 0; i < len; i++) {
          const item = dsitems[i];
          encoder.writeDsClock(item.clock);
          encoder.writeDsLen(item.len);
        }
      });
    };
    readDeleteSet = (decoder) => {
      const ds = new DeleteSet();
      const numClients = readVarUint(decoder.restDecoder);
      for (let i = 0; i < numClients; i++) {
        decoder.resetDsCurVal();
        const client = readVarUint(decoder.restDecoder);
        const numberOfDeletes = readVarUint(decoder.restDecoder);
        if (numberOfDeletes > 0) {
          const dsField = setIfUndefined(ds.clients, client, () => (
            /** @type {Array<DeleteItem>} */
            []
          ));
          for (let i2 = 0; i2 < numberOfDeletes; i2++) {
            dsField.push(new DeleteItem(decoder.readDsClock(), decoder.readDsLen()));
          }
        }
      }
      return ds;
    };
    readAndApplyDeleteSet = (decoder, transaction, store) => {
      const unappliedDS = new DeleteSet();
      const numClients = readVarUint(decoder.restDecoder);
      for (let i = 0; i < numClients; i++) {
        decoder.resetDsCurVal();
        const client = readVarUint(decoder.restDecoder);
        const numberOfDeletes = readVarUint(decoder.restDecoder);
        const structs = store.clients.get(client) || [];
        const state = getState(store, client);
        for (let i2 = 0; i2 < numberOfDeletes; i2++) {
          const clock = decoder.readDsClock();
          const clockEnd = clock + decoder.readDsLen();
          if (clock < state) {
            if (state < clockEnd) {
              addToDeleteSet(unappliedDS, client, state, clockEnd - state);
            }
            let index = findIndexSS(structs, clock);
            let struct = structs[index];
            if (!struct.deleted && struct.id.clock < clock) {
              structs.splice(index + 1, 0, splitItem(transaction, struct, clock - struct.id.clock));
              index++;
            }
            while (index < structs.length) {
              struct = structs[index++];
              if (struct.id.clock < clockEnd) {
                if (!struct.deleted) {
                  if (clockEnd < struct.id.clock + struct.length) {
                    structs.splice(index, 0, splitItem(transaction, struct, clockEnd - struct.id.clock));
                  }
                  struct.delete(transaction);
                }
              } else {
                break;
              }
            }
          } else {
            addToDeleteSet(unappliedDS, client, clock, clockEnd - clock);
          }
        }
      }
      if (unappliedDS.clients.size > 0) {
        const ds = new UpdateEncoderV2();
        writeVarUint(ds.restEncoder, 0);
        writeDeleteSet(ds, unappliedDS);
        return ds.toUint8Array();
      }
      return null;
    };
    equalDeleteSets = (ds1, ds2) => {
      if (ds1.clients.size !== ds2.clients.size)
        return false;
      for (const [client, deleteItems1] of ds1.clients.entries()) {
        const deleteItems2 = (
          /** @type {Array<import('../internals.js').DeleteItem>} */
          ds2.clients.get(client)
        );
        if (deleteItems2 === void 0 || deleteItems1.length !== deleteItems2.length)
          return false;
        for (let i = 0; i < deleteItems1.length; i++) {
          const di1 = deleteItems1[i];
          const di2 = deleteItems2[i];
          if (di1.clock !== di2.clock || di1.len !== di2.len) {
            return false;
          }
        }
      }
      return true;
    };
    generateNewClientId = uint32;
    Doc = class _Doc extends ObservableV2 {
      /**
       * @param {DocOpts} opts configuration
       */
      constructor({ guid = uuidv4(), collectionid = null, gc = true, gcFilter = () => true, meta = null, autoLoad = false, shouldLoad = true } = {}) {
        super();
        this.gc = gc;
        this.gcFilter = gcFilter;
        this.clientID = generateNewClientId();
        this.guid = guid;
        this.collectionid = collectionid;
        this.share = /* @__PURE__ */ new Map();
        this.store = new StructStore();
        this._transaction = null;
        this._transactionCleanups = [];
        this.subdocs = /* @__PURE__ */ new Set();
        this._item = null;
        this.shouldLoad = shouldLoad;
        this.autoLoad = autoLoad;
        this.meta = meta;
        this.isLoaded = false;
        this.isSynced = false;
        this.isDestroyed = false;
        this.whenLoaded = create4((resolve) => {
          this.on("load", () => {
            this.isLoaded = true;
            resolve(this);
          });
        });
        const provideSyncedPromise = () => create4((resolve) => {
          const eventHandler = (isSynced) => {
            if (isSynced === void 0 || isSynced === true) {
              this.off("sync", eventHandler);
              resolve();
            }
          };
          this.on("sync", eventHandler);
        });
        this.on("sync", (isSynced) => {
          if (isSynced === false && this.isSynced) {
            this.whenSynced = provideSyncedPromise();
          }
          this.isSynced = isSynced === void 0 || isSynced === true;
          if (this.isSynced && !this.isLoaded) {
            this.emit("load", [this]);
          }
        });
        this.whenSynced = provideSyncedPromise();
      }
      /**
       * Notify the parent document that you request to load data into this subdocument (if it is a subdocument).
       *
       * `load()` might be used in the future to request any provider to load the most current data.
       *
       * It is safe to call `load()` multiple times.
       */
      load() {
        const item = this._item;
        if (item !== null && !this.shouldLoad) {
          transact(
            /** @type {any} */
            item.parent.doc,
            (transaction) => {
              transaction.subdocsLoaded.add(this);
            },
            null,
            true
          );
        }
        this.shouldLoad = true;
      }
      getSubdocs() {
        return this.subdocs;
      }
      getSubdocGuids() {
        return new Set(from(this.subdocs).map((doc) => doc.guid));
      }
      /**
       * Changes that happen inside of a transaction are bundled. This means that
       * the observer fires _after_ the transaction is finished and that all changes
       * that happened inside of the transaction are sent as one message to the
       * other peers.
       *
       * @template T
       * @param {function(Transaction):T} f The function that should be executed as a transaction
       * @param {any} [origin] Origin of who started the transaction. Will be stored on transaction.origin
       * @return T
       *
       * @public
       */
      transact(f, origin = null) {
        return transact(this, f, origin);
      }
      /**
       * Define a shared data type.
       *
       * Multiple calls of `ydoc.get(name, TypeConstructor)` yield the same result
       * and do not overwrite each other. I.e.
       * `ydoc.get(name, Y.Array) === ydoc.get(name, Y.Array)`
       *
       * After this method is called, the type is also available on `ydoc.share.get(name)`.
       *
       * *Best Practices:*
       * Define all types right after the Y.Doc instance is created and store them in a separate object.
       * Also use the typed methods `getText(name)`, `getArray(name)`, ..
       *
       * @template {typeof AbstractType<any>} Type
       * @example
       *   const ydoc = new Y.Doc(..)
       *   const appState = {
       *     document: ydoc.getText('document')
       *     comments: ydoc.getArray('comments')
       *   }
       *
       * @param {string} name
       * @param {Type} TypeConstructor The constructor of the type definition. E.g. Y.Text, Y.Array, Y.Map, ...
       * @return {InstanceType<Type>} The created type. Constructed with TypeConstructor
       *
       * @public
       */
      get(name, TypeConstructor = (
        /** @type {any} */
        AbstractType
      )) {
        const type = setIfUndefined(this.share, name, () => {
          const t = new TypeConstructor();
          t._integrate(this, null);
          return t;
        });
        const Constr = type.constructor;
        if (TypeConstructor !== AbstractType && Constr !== TypeConstructor) {
          if (Constr === AbstractType) {
            const t = new TypeConstructor();
            t._map = type._map;
            type._map.forEach(
              /** @param {Item?} n */
              (n) => {
                for (; n !== null; n = n.left) {
                  n.parent = t;
                }
              }
            );
            t._start = type._start;
            for (let n = t._start; n !== null; n = n.right) {
              n.parent = t;
            }
            t._length = type._length;
            this.share.set(name, t);
            t._integrate(this, null);
            return (
              /** @type {InstanceType<Type>} */
              t
            );
          } else {
            throw new Error(`Type with the name ${name} has already been defined with a different constructor`);
          }
        }
        return (
          /** @type {InstanceType<Type>} */
          type
        );
      }
      /**
       * @template T
       * @param {string} [name]
       * @return {YArray<T>}
       *
       * @public
       */
      getArray(name = "") {
        return (
          /** @type {YArray<T>} */
          this.get(name, YArray)
        );
      }
      /**
       * @param {string} [name]
       * @return {YText}
       *
       * @public
       */
      getText(name = "") {
        return this.get(name, YText);
      }
      /**
       * @template T
       * @param {string} [name]
       * @return {YMap<T>}
       *
       * @public
       */
      getMap(name = "") {
        return (
          /** @type {YMap<T>} */
          this.get(name, YMap)
        );
      }
      /**
       * @param {string} [name]
       * @return {YXmlElement}
       *
       * @public
       */
      getXmlElement(name = "") {
        return (
          /** @type {YXmlElement<{[key:string]:string}>} */
          this.get(name, YXmlElement)
        );
      }
      /**
       * @param {string} [name]
       * @return {YXmlFragment}
       *
       * @public
       */
      getXmlFragment(name = "") {
        return this.get(name, YXmlFragment);
      }
      /**
       * Converts the entire document into a js object, recursively traversing each yjs type
       * Doesn't log types that have not been defined (using ydoc.getType(..)).
       *
       * @deprecated Do not use this method and rather call toJSON directly on the shared types.
       *
       * @return {Object<string, any>}
       */
      toJSON() {
        const doc = {};
        this.share.forEach((value, key) => {
          doc[key] = value.toJSON();
        });
        return doc;
      }
      /**
       * Emit `destroy` event and unregister all event handlers.
       */
      destroy() {
        this.isDestroyed = true;
        from(this.subdocs).forEach((subdoc) => subdoc.destroy());
        const item = this._item;
        if (item !== null) {
          this._item = null;
          const content = (
            /** @type {ContentDoc} */
            item.content
          );
          content.doc = new _Doc({ guid: this.guid, ...content.opts, shouldLoad: false });
          content.doc._item = item;
          transact(
            /** @type {any} */
            item.parent.doc,
            (transaction) => {
              const doc = content.doc;
              if (!item.deleted) {
                transaction.subdocsAdded.add(doc);
              }
              transaction.subdocsRemoved.add(this);
            },
            null,
            true
          );
        }
        this.emit("destroyed", [true]);
        this.emit("destroy", [this]);
        super.destroy();
      }
    };
    DSDecoderV1 = class {
      /**
       * @param {decoding.Decoder} decoder
       */
      constructor(decoder) {
        this.restDecoder = decoder;
      }
      resetDsCurVal() {
      }
      /**
       * @return {number}
       */
      readDsClock() {
        return readVarUint(this.restDecoder);
      }
      /**
       * @return {number}
       */
      readDsLen() {
        return readVarUint(this.restDecoder);
      }
    };
    UpdateDecoderV1 = class extends DSDecoderV1 {
      /**
       * @return {ID}
       */
      readLeftID() {
        return createID(readVarUint(this.restDecoder), readVarUint(this.restDecoder));
      }
      /**
       * @return {ID}
       */
      readRightID() {
        return createID(readVarUint(this.restDecoder), readVarUint(this.restDecoder));
      }
      /**
       * Read the next client id.
       * Use this in favor of readID whenever possible to reduce the number of objects created.
       */
      readClient() {
        return readVarUint(this.restDecoder);
      }
      /**
       * @return {number} info An unsigned 8-bit integer
       */
      readInfo() {
        return readUint8(this.restDecoder);
      }
      /**
       * @return {string}
       */
      readString() {
        return readVarString(this.restDecoder);
      }
      /**
       * @return {boolean} isKey
       */
      readParentInfo() {
        return readVarUint(this.restDecoder) === 1;
      }
      /**
       * @return {number} info An unsigned 8-bit integer
       */
      readTypeRef() {
        return readVarUint(this.restDecoder);
      }
      /**
       * Write len of a struct - well suited for Opt RLE encoder.
       *
       * @return {number} len
       */
      readLen() {
        return readVarUint(this.restDecoder);
      }
      /**
       * @return {any}
       */
      readAny() {
        return readAny(this.restDecoder);
      }
      /**
       * @return {Uint8Array}
       */
      readBuf() {
        return copyUint8Array(readVarUint8Array(this.restDecoder));
      }
      /**
       * Legacy implementation uses JSON parse. We use any-decoding in v2.
       *
       * @return {any}
       */
      readJSON() {
        return JSON.parse(readVarString(this.restDecoder));
      }
      /**
       * @return {string}
       */
      readKey() {
        return readVarString(this.restDecoder);
      }
    };
    DSDecoderV2 = class {
      /**
       * @param {decoding.Decoder} decoder
       */
      constructor(decoder) {
        this.dsCurrVal = 0;
        this.restDecoder = decoder;
      }
      resetDsCurVal() {
        this.dsCurrVal = 0;
      }
      /**
       * @return {number}
       */
      readDsClock() {
        this.dsCurrVal += readVarUint(this.restDecoder);
        return this.dsCurrVal;
      }
      /**
       * @return {number}
       */
      readDsLen() {
        const diff = readVarUint(this.restDecoder) + 1;
        this.dsCurrVal += diff;
        return diff;
      }
    };
    UpdateDecoderV2 = class extends DSDecoderV2 {
      /**
       * @param {decoding.Decoder} decoder
       */
      constructor(decoder) {
        super(decoder);
        this.keys = [];
        readVarUint(decoder);
        this.keyClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
        this.clientDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
        this.leftClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
        this.rightClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
        this.infoDecoder = new RleDecoder(readVarUint8Array(decoder), readUint8);
        this.stringDecoder = new StringDecoder(readVarUint8Array(decoder));
        this.parentInfoDecoder = new RleDecoder(readVarUint8Array(decoder), readUint8);
        this.typeRefDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
        this.lenDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
      }
      /**
       * @return {ID}
       */
      readLeftID() {
        return new ID(this.clientDecoder.read(), this.leftClockDecoder.read());
      }
      /**
       * @return {ID}
       */
      readRightID() {
        return new ID(this.clientDecoder.read(), this.rightClockDecoder.read());
      }
      /**
       * Read the next client id.
       * Use this in favor of readID whenever possible to reduce the number of objects created.
       */
      readClient() {
        return this.clientDecoder.read();
      }
      /**
       * @return {number} info An unsigned 8-bit integer
       */
      readInfo() {
        return (
          /** @type {number} */
          this.infoDecoder.read()
        );
      }
      /**
       * @return {string}
       */
      readString() {
        return this.stringDecoder.read();
      }
      /**
       * @return {boolean}
       */
      readParentInfo() {
        return this.parentInfoDecoder.read() === 1;
      }
      /**
       * @return {number} An unsigned 8-bit integer
       */
      readTypeRef() {
        return this.typeRefDecoder.read();
      }
      /**
       * Write len of a struct - well suited for Opt RLE encoder.
       *
       * @return {number}
       */
      readLen() {
        return this.lenDecoder.read();
      }
      /**
       * @return {any}
       */
      readAny() {
        return readAny(this.restDecoder);
      }
      /**
       * @return {Uint8Array}
       */
      readBuf() {
        return readVarUint8Array(this.restDecoder);
      }
      /**
       * This is mainly here for legacy purposes.
       *
       * Initial we incoded objects using JSON. Now we use the much faster lib0/any-encoder. This method mainly exists for legacy purposes for the v1 encoder.
       *
       * @return {any}
       */
      readJSON() {
        return readAny(this.restDecoder);
      }
      /**
       * @return {string}
       */
      readKey() {
        const keyClock = this.keyClockDecoder.read();
        if (keyClock < this.keys.length) {
          return this.keys[keyClock];
        } else {
          const key = this.stringDecoder.read();
          this.keys.push(key);
          return key;
        }
      }
    };
    DSEncoderV1 = class {
      constructor() {
        this.restEncoder = createEncoder();
      }
      toUint8Array() {
        return toUint8Array(this.restEncoder);
      }
      resetDsCurVal() {
      }
      /**
       * @param {number} clock
       */
      writeDsClock(clock) {
        writeVarUint(this.restEncoder, clock);
      }
      /**
       * @param {number} len
       */
      writeDsLen(len) {
        writeVarUint(this.restEncoder, len);
      }
    };
    UpdateEncoderV1 = class extends DSEncoderV1 {
      /**
       * @param {ID} id
       */
      writeLeftID(id2) {
        writeVarUint(this.restEncoder, id2.client);
        writeVarUint(this.restEncoder, id2.clock);
      }
      /**
       * @param {ID} id
       */
      writeRightID(id2) {
        writeVarUint(this.restEncoder, id2.client);
        writeVarUint(this.restEncoder, id2.clock);
      }
      /**
       * Use writeClient and writeClock instead of writeID if possible.
       * @param {number} client
       */
      writeClient(client) {
        writeVarUint(this.restEncoder, client);
      }
      /**
       * @param {number} info An unsigned 8-bit integer
       */
      writeInfo(info) {
        writeUint8(this.restEncoder, info);
      }
      /**
       * @param {string} s
       */
      writeString(s) {
        writeVarString(this.restEncoder, s);
      }
      /**
       * @param {boolean} isYKey
       */
      writeParentInfo(isYKey) {
        writeVarUint(this.restEncoder, isYKey ? 1 : 0);
      }
      /**
       * @param {number} info An unsigned 8-bit integer
       */
      writeTypeRef(info) {
        writeVarUint(this.restEncoder, info);
      }
      /**
       * Write len of a struct - well suited for Opt RLE encoder.
       *
       * @param {number} len
       */
      writeLen(len) {
        writeVarUint(this.restEncoder, len);
      }
      /**
       * @param {any} any
       */
      writeAny(any2) {
        writeAny(this.restEncoder, any2);
      }
      /**
       * @param {Uint8Array} buf
       */
      writeBuf(buf) {
        writeVarUint8Array(this.restEncoder, buf);
      }
      /**
       * @param {any} embed
       */
      writeJSON(embed) {
        writeVarString(this.restEncoder, JSON.stringify(embed));
      }
      /**
       * @param {string} key
       */
      writeKey(key) {
        writeVarString(this.restEncoder, key);
      }
    };
    DSEncoderV2 = class {
      constructor() {
        this.restEncoder = createEncoder();
        this.dsCurrVal = 0;
      }
      toUint8Array() {
        return toUint8Array(this.restEncoder);
      }
      resetDsCurVal() {
        this.dsCurrVal = 0;
      }
      /**
       * @param {number} clock
       */
      writeDsClock(clock) {
        const diff = clock - this.dsCurrVal;
        this.dsCurrVal = clock;
        writeVarUint(this.restEncoder, diff);
      }
      /**
       * @param {number} len
       */
      writeDsLen(len) {
        if (len === 0) {
          unexpectedCase();
        }
        writeVarUint(this.restEncoder, len - 1);
        this.dsCurrVal += len;
      }
    };
    UpdateEncoderV2 = class extends DSEncoderV2 {
      constructor() {
        super();
        this.keyMap = /* @__PURE__ */ new Map();
        this.keyClock = 0;
        this.keyClockEncoder = new IntDiffOptRleEncoder();
        this.clientEncoder = new UintOptRleEncoder();
        this.leftClockEncoder = new IntDiffOptRleEncoder();
        this.rightClockEncoder = new IntDiffOptRleEncoder();
        this.infoEncoder = new RleEncoder(writeUint8);
        this.stringEncoder = new StringEncoder();
        this.parentInfoEncoder = new RleEncoder(writeUint8);
        this.typeRefEncoder = new UintOptRleEncoder();
        this.lenEncoder = new UintOptRleEncoder();
      }
      toUint8Array() {
        const encoder = createEncoder();
        writeVarUint(encoder, 0);
        writeVarUint8Array(encoder, this.keyClockEncoder.toUint8Array());
        writeVarUint8Array(encoder, this.clientEncoder.toUint8Array());
        writeVarUint8Array(encoder, this.leftClockEncoder.toUint8Array());
        writeVarUint8Array(encoder, this.rightClockEncoder.toUint8Array());
        writeVarUint8Array(encoder, toUint8Array(this.infoEncoder));
        writeVarUint8Array(encoder, this.stringEncoder.toUint8Array());
        writeVarUint8Array(encoder, toUint8Array(this.parentInfoEncoder));
        writeVarUint8Array(encoder, this.typeRefEncoder.toUint8Array());
        writeVarUint8Array(encoder, this.lenEncoder.toUint8Array());
        writeUint8Array(encoder, toUint8Array(this.restEncoder));
        return toUint8Array(encoder);
      }
      /**
       * @param {ID} id
       */
      writeLeftID(id2) {
        this.clientEncoder.write(id2.client);
        this.leftClockEncoder.write(id2.clock);
      }
      /**
       * @param {ID} id
       */
      writeRightID(id2) {
        this.clientEncoder.write(id2.client);
        this.rightClockEncoder.write(id2.clock);
      }
      /**
       * @param {number} client
       */
      writeClient(client) {
        this.clientEncoder.write(client);
      }
      /**
       * @param {number} info An unsigned 8-bit integer
       */
      writeInfo(info) {
        this.infoEncoder.write(info);
      }
      /**
       * @param {string} s
       */
      writeString(s) {
        this.stringEncoder.write(s);
      }
      /**
       * @param {boolean} isYKey
       */
      writeParentInfo(isYKey) {
        this.parentInfoEncoder.write(isYKey ? 1 : 0);
      }
      /**
       * @param {number} info An unsigned 8-bit integer
       */
      writeTypeRef(info) {
        this.typeRefEncoder.write(info);
      }
      /**
       * Write len of a struct - well suited for Opt RLE encoder.
       *
       * @param {number} len
       */
      writeLen(len) {
        this.lenEncoder.write(len);
      }
      /**
       * @param {any} any
       */
      writeAny(any2) {
        writeAny(this.restEncoder, any2);
      }
      /**
       * @param {Uint8Array} buf
       */
      writeBuf(buf) {
        writeVarUint8Array(this.restEncoder, buf);
      }
      /**
       * This is mainly here for legacy purposes.
       *
       * Initial we incoded objects using JSON. Now we use the much faster lib0/any-encoder. This method mainly exists for legacy purposes for the v1 encoder.
       *
       * @param {any} embed
       */
      writeJSON(embed) {
        writeAny(this.restEncoder, embed);
      }
      /**
       * Property keys are often reused. For example, in y-prosemirror the key `bold` might
       * occur very often. For a 3d application, the key `position` might occur very often.
       *
       * We cache these keys in a Map and refer to them via a unique number.
       *
       * @param {string} key
       */
      writeKey(key) {
        const clock = this.keyMap.get(key);
        if (clock === void 0) {
          this.keyClockEncoder.write(this.keyClock++);
          this.stringEncoder.write(key);
        } else {
          this.keyClockEncoder.write(clock);
        }
      }
    };
    writeStructs = (encoder, structs, client, clock) => {
      clock = max(clock, structs[0].id.clock);
      const startNewStructs = findIndexSS(structs, clock);
      writeVarUint(encoder.restEncoder, structs.length - startNewStructs);
      encoder.writeClient(client);
      writeVarUint(encoder.restEncoder, clock);
      const firstStruct = structs[startNewStructs];
      firstStruct.write(encoder, clock - firstStruct.id.clock);
      for (let i = startNewStructs + 1; i < structs.length; i++) {
        structs[i].write(encoder, 0);
      }
    };
    writeClientsStructs = (encoder, store, _sm) => {
      const sm = /* @__PURE__ */ new Map();
      _sm.forEach((clock, client) => {
        if (getState(store, client) > clock) {
          sm.set(client, clock);
        }
      });
      getStateVector(store).forEach((_clock, client) => {
        if (!_sm.has(client)) {
          sm.set(client, 0);
        }
      });
      writeVarUint(encoder.restEncoder, sm.size);
      from(sm.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, clock]) => {
        writeStructs(
          encoder,
          /** @type {Array<GC|Item>} */
          store.clients.get(client),
          client,
          clock
        );
      });
    };
    readClientsStructRefs = (decoder, doc) => {
      const clientRefs = create();
      const numOfStateUpdates = readVarUint(decoder.restDecoder);
      for (let i = 0; i < numOfStateUpdates; i++) {
        const numberOfStructs = readVarUint(decoder.restDecoder);
        const refs = new Array(numberOfStructs);
        const client = decoder.readClient();
        let clock = readVarUint(decoder.restDecoder);
        clientRefs.set(client, { i: 0, refs });
        for (let i2 = 0; i2 < numberOfStructs; i2++) {
          const info = decoder.readInfo();
          switch (BITS5 & info) {
            case 0: {
              const len = decoder.readLen();
              refs[i2] = new GC(createID(client, clock), len);
              clock += len;
              break;
            }
            case 10: {
              const len = readVarUint(decoder.restDecoder);
              refs[i2] = new Skip(createID(client, clock), len);
              clock += len;
              break;
            }
            default: {
              const cantCopyParentInfo = (info & (BIT7 | BIT8)) === 0;
              const struct = new Item(
                createID(client, clock),
                null,
                // left
                (info & BIT8) === BIT8 ? decoder.readLeftID() : null,
                // origin
                null,
                // right
                (info & BIT7) === BIT7 ? decoder.readRightID() : null,
                // right origin
                cantCopyParentInfo ? decoder.readParentInfo() ? doc.get(decoder.readString()) : decoder.readLeftID() : null,
                // parent
                cantCopyParentInfo && (info & BIT6) === BIT6 ? decoder.readString() : null,
                // parentSub
                readItemContent(decoder, info)
                // item content
              );
              refs[i2] = struct;
              clock += struct.length;
            }
          }
        }
      }
      return clientRefs;
    };
    integrateStructs = (transaction, store, clientsStructRefs) => {
      const stack = [];
      let clientsStructRefsIds = from(clientsStructRefs.keys()).sort((a, b) => a - b);
      if (clientsStructRefsIds.length === 0) {
        return null;
      }
      const getNextStructTarget = () => {
        if (clientsStructRefsIds.length === 0) {
          return null;
        }
        let nextStructsTarget = (
          /** @type {{i:number,refs:Array<GC|Item>}} */
          clientsStructRefs.get(clientsStructRefsIds[clientsStructRefsIds.length - 1])
        );
        while (nextStructsTarget.refs.length === nextStructsTarget.i) {
          clientsStructRefsIds.pop();
          if (clientsStructRefsIds.length > 0) {
            nextStructsTarget = /** @type {{i:number,refs:Array<GC|Item>}} */
            clientsStructRefs.get(clientsStructRefsIds[clientsStructRefsIds.length - 1]);
          } else {
            return null;
          }
        }
        return nextStructsTarget;
      };
      let curStructsTarget = getNextStructTarget();
      if (curStructsTarget === null) {
        return null;
      }
      const restStructs = new StructStore();
      const missingSV = /* @__PURE__ */ new Map();
      const updateMissingSv = (client, clock) => {
        const mclock = missingSV.get(client);
        if (mclock == null || mclock > clock) {
          missingSV.set(client, clock);
        }
      };
      let stackHead = (
        /** @type {any} */
        curStructsTarget.refs[
          /** @type {any} */
          curStructsTarget.i++
        ]
      );
      const state = /* @__PURE__ */ new Map();
      const addStackToRestSS = () => {
        for (const item of stack) {
          const client = item.id.client;
          const inapplicableItems = clientsStructRefs.get(client);
          if (inapplicableItems) {
            inapplicableItems.i--;
            restStructs.clients.set(client, inapplicableItems.refs.slice(inapplicableItems.i));
            clientsStructRefs.delete(client);
            inapplicableItems.i = 0;
            inapplicableItems.refs = [];
          } else {
            restStructs.clients.set(client, [item]);
          }
          clientsStructRefsIds = clientsStructRefsIds.filter((c) => c !== client);
        }
        stack.length = 0;
      };
      while (true) {
        if (stackHead.constructor !== Skip) {
          const localClock = setIfUndefined(state, stackHead.id.client, () => getState(store, stackHead.id.client));
          const offset = localClock - stackHead.id.clock;
          if (offset < 0) {
            stack.push(stackHead);
            updateMissingSv(stackHead.id.client, stackHead.id.clock - 1);
            addStackToRestSS();
          } else {
            const missing = stackHead.getMissing(transaction, store);
            if (missing !== null) {
              stack.push(stackHead);
              const structRefs = clientsStructRefs.get(
                /** @type {number} */
                missing
              ) || { refs: [], i: 0 };
              if (structRefs.refs.length === structRefs.i) {
                updateMissingSv(
                  /** @type {number} */
                  missing,
                  getState(store, missing)
                );
                addStackToRestSS();
              } else {
                stackHead = structRefs.refs[structRefs.i++];
                continue;
              }
            } else if (offset === 0 || offset < stackHead.length) {
              stackHead.integrate(transaction, offset);
              state.set(stackHead.id.client, stackHead.id.clock + stackHead.length);
            }
          }
        }
        if (stack.length > 0) {
          stackHead = /** @type {GC|Item} */
          stack.pop();
        } else if (curStructsTarget !== null && curStructsTarget.i < curStructsTarget.refs.length) {
          stackHead = /** @type {GC|Item} */
          curStructsTarget.refs[curStructsTarget.i++];
        } else {
          curStructsTarget = getNextStructTarget();
          if (curStructsTarget === null) {
            break;
          } else {
            stackHead = /** @type {GC|Item} */
            curStructsTarget.refs[curStructsTarget.i++];
          }
        }
      }
      if (restStructs.clients.size > 0) {
        const encoder = new UpdateEncoderV2();
        writeClientsStructs(encoder, restStructs, /* @__PURE__ */ new Map());
        writeVarUint(encoder.restEncoder, 0);
        return { missing: missingSV, update: encoder.toUint8Array() };
      }
      return null;
    };
    writeStructsFromTransaction = (encoder, transaction) => writeClientsStructs(encoder, transaction.doc.store, transaction.beforeState);
    readUpdateV2 = (decoder, ydoc, transactionOrigin, structDecoder = new UpdateDecoderV2(decoder)) => transact(ydoc, (transaction) => {
      transaction.local = false;
      let retry = false;
      const doc = transaction.doc;
      const store = doc.store;
      const ss = readClientsStructRefs(structDecoder, doc);
      const restStructs = integrateStructs(transaction, store, ss);
      const pending = store.pendingStructs;
      if (pending) {
        for (const [client, clock] of pending.missing) {
          if (clock < getState(store, client)) {
            retry = true;
            break;
          }
        }
        if (restStructs) {
          for (const [client, clock] of restStructs.missing) {
            const mclock = pending.missing.get(client);
            if (mclock == null || mclock > clock) {
              pending.missing.set(client, clock);
            }
          }
          pending.update = mergeUpdatesV2([pending.update, restStructs.update]);
        }
      } else {
        store.pendingStructs = restStructs;
      }
      const dsRest = readAndApplyDeleteSet(structDecoder, transaction, store);
      if (store.pendingDs) {
        const pendingDSUpdate = new UpdateDecoderV2(createDecoder(store.pendingDs));
        readVarUint(pendingDSUpdate.restDecoder);
        const dsRest2 = readAndApplyDeleteSet(pendingDSUpdate, transaction, store);
        if (dsRest && dsRest2) {
          store.pendingDs = mergeUpdatesV2([dsRest, dsRest2]);
        } else {
          store.pendingDs = dsRest || dsRest2;
        }
      } else {
        store.pendingDs = dsRest;
      }
      if (retry) {
        const update = (
          /** @type {{update: Uint8Array}} */
          store.pendingStructs.update
        );
        store.pendingStructs = null;
        applyUpdateV2(transaction.doc, update);
      }
    }, transactionOrigin, false);
    readUpdate = (decoder, ydoc, transactionOrigin) => readUpdateV2(decoder, ydoc, transactionOrigin, new UpdateDecoderV1(decoder));
    applyUpdateV2 = (ydoc, update, transactionOrigin, YDecoder = UpdateDecoderV2) => {
      const decoder = createDecoder(update);
      readUpdateV2(decoder, ydoc, transactionOrigin, new YDecoder(decoder));
    };
    applyUpdate = (ydoc, update, transactionOrigin) => applyUpdateV2(ydoc, update, transactionOrigin, UpdateDecoderV1);
    writeStateAsUpdate = (encoder, doc, targetStateVector = /* @__PURE__ */ new Map()) => {
      writeClientsStructs(encoder, doc.store, targetStateVector);
      writeDeleteSet(encoder, createDeleteSetFromStructStore(doc.store));
    };
    encodeStateAsUpdateV2 = (doc, encodedTargetStateVector = new Uint8Array([0]), encoder = new UpdateEncoderV2()) => {
      const targetStateVector = decodeStateVector(encodedTargetStateVector);
      writeStateAsUpdate(encoder, doc, targetStateVector);
      const updates = [encoder.toUint8Array()];
      if (doc.store.pendingDs) {
        updates.push(doc.store.pendingDs);
      }
      if (doc.store.pendingStructs) {
        updates.push(diffUpdateV2(doc.store.pendingStructs.update, encodedTargetStateVector));
      }
      if (updates.length > 1) {
        if (encoder.constructor === UpdateEncoderV1) {
          return mergeUpdates(updates.map((update, i) => i === 0 ? update : convertUpdateFormatV2ToV1(update)));
        } else if (encoder.constructor === UpdateEncoderV2) {
          return mergeUpdatesV2(updates);
        }
      }
      return updates[0];
    };
    encodeStateAsUpdate = (doc, encodedTargetStateVector) => encodeStateAsUpdateV2(doc, encodedTargetStateVector, new UpdateEncoderV1());
    readStateVector = (decoder) => {
      const ss = /* @__PURE__ */ new Map();
      const ssLength = readVarUint(decoder.restDecoder);
      for (let i = 0; i < ssLength; i++) {
        const client = readVarUint(decoder.restDecoder);
        const clock = readVarUint(decoder.restDecoder);
        ss.set(client, clock);
      }
      return ss;
    };
    decodeStateVector = (decodedState) => readStateVector(new DSDecoderV1(createDecoder(decodedState)));
    writeStateVector = (encoder, sv) => {
      writeVarUint(encoder.restEncoder, sv.size);
      from(sv.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, clock]) => {
        writeVarUint(encoder.restEncoder, client);
        writeVarUint(encoder.restEncoder, clock);
      });
      return encoder;
    };
    writeDocumentStateVector = (encoder, doc) => writeStateVector(encoder, getStateVector(doc.store));
    encodeStateVectorV2 = (doc, encoder = new DSEncoderV2()) => {
      if (doc instanceof Map) {
        writeStateVector(encoder, doc);
      } else {
        writeDocumentStateVector(encoder, doc);
      }
      return encoder.toUint8Array();
    };
    encodeStateVector = (doc) => encodeStateVectorV2(doc, new DSEncoderV1());
    EventHandler = class {
      constructor() {
        this.l = [];
      }
    };
    createEventHandler = () => new EventHandler();
    addEventHandlerListener = (eventHandler, f) => eventHandler.l.push(f);
    removeEventHandlerListener = (eventHandler, f) => {
      const l = eventHandler.l;
      const len = l.length;
      eventHandler.l = l.filter((g) => f !== g);
      if (len === eventHandler.l.length) {
        console.error("[yjs] Tried to remove event handler that doesn't exist.");
      }
    };
    callEventHandlerListeners = (eventHandler, arg0, arg1) => callAll(eventHandler.l, [arg0, arg1]);
    ID = class {
      /**
       * @param {number} client client id
       * @param {number} clock unique per client id, continuous number
       */
      constructor(client, clock) {
        this.client = client;
        this.clock = clock;
      }
    };
    compareIDs = (a, b) => a === b || a !== null && b !== null && a.client === b.client && a.clock === b.clock;
    createID = (client, clock) => new ID(client, clock);
    writeID = (encoder, id2) => {
      writeVarUint(encoder, id2.client);
      writeVarUint(encoder, id2.clock);
    };
    readID = (decoder) => createID(readVarUint(decoder), readVarUint(decoder));
    findRootTypeKey = (type) => {
      for (const [key, value] of type.doc.share.entries()) {
        if (value === type) {
          return key;
        }
      }
      throw unexpectedCase();
    };
    isParentOf = (parent, child) => {
      while (child !== null) {
        if (child.parent === parent) {
          return true;
        }
        child = /** @type {AbstractType<any>} */
        child.parent._item;
      }
      return false;
    };
    logType = (type) => {
      const res = [];
      let n = type._start;
      while (n) {
        res.push(n);
        n = n.right;
      }
      console.log("Children: ", res);
      console.log("Children content: ", res.filter((m) => !m.deleted).map((m) => m.content));
    };
    PermanentUserData = class {
      /**
       * @param {Doc} doc
       * @param {YMap<any>} [storeType]
       */
      constructor(doc, storeType = doc.getMap("users")) {
        const dss = /* @__PURE__ */ new Map();
        this.yusers = storeType;
        this.doc = doc;
        this.clients = /* @__PURE__ */ new Map();
        this.dss = dss;
        const initUser = (user, userDescription) => {
          const ds = user.get("ds");
          const ids = user.get("ids");
          const addClientId = (
            /** @param {number} clientid */
            (clientid) => this.clients.set(clientid, userDescription)
          );
          ds.observe(
            /** @param {YArrayEvent<any>} event */
            (event) => {
              event.changes.added.forEach((item) => {
                item.content.getContent().forEach((encodedDs) => {
                  if (encodedDs instanceof Uint8Array) {
                    this.dss.set(userDescription, mergeDeleteSets([this.dss.get(userDescription) || createDeleteSet(), readDeleteSet(new DSDecoderV1(createDecoder(encodedDs)))]));
                  }
                });
              });
            }
          );
          this.dss.set(userDescription, mergeDeleteSets(ds.map((encodedDs) => readDeleteSet(new DSDecoderV1(createDecoder(encodedDs))))));
          ids.observe(
            /** @param {YArrayEvent<any>} event */
            (event) => event.changes.added.forEach((item) => item.content.getContent().forEach(addClientId))
          );
          ids.forEach(addClientId);
        };
        storeType.observe((event) => {
          event.keysChanged.forEach(
            (userDescription) => initUser(storeType.get(userDescription), userDescription)
          );
        });
        storeType.forEach(initUser);
      }
      /**
       * @param {Doc} doc
       * @param {number} clientid
       * @param {string} userDescription
       * @param {Object} conf
       * @param {function(Transaction, DeleteSet):boolean} [conf.filter]
       */
      setUserMapping(doc, clientid, userDescription, { filter = () => true } = {}) {
        const users = this.yusers;
        let user = users.get(userDescription);
        if (!user) {
          user = new YMap();
          user.set("ids", new YArray());
          user.set("ds", new YArray());
          users.set(userDescription, user);
        }
        user.get("ids").push([clientid]);
        users.observe((_event) => {
          setTimeout(() => {
            const userOverwrite = users.get(userDescription);
            if (userOverwrite !== user) {
              user = userOverwrite;
              this.clients.forEach((_userDescription, clientid2) => {
                if (userDescription === _userDescription) {
                  user.get("ids").push([clientid2]);
                }
              });
              const encoder = new DSEncoderV1();
              const ds = this.dss.get(userDescription);
              if (ds) {
                writeDeleteSet(encoder, ds);
                user.get("ds").push([encoder.toUint8Array()]);
              }
            }
          }, 0);
        });
        doc.on(
          "afterTransaction",
          /** @param {Transaction} transaction */
          (transaction) => {
            setTimeout(() => {
              const yds = user.get("ds");
              const ds = transaction.deleteSet;
              if (transaction.local && ds.clients.size > 0 && filter(transaction, ds)) {
                const encoder = new DSEncoderV1();
                writeDeleteSet(encoder, ds);
                yds.push([encoder.toUint8Array()]);
              }
            });
          }
        );
      }
      /**
       * @param {number} clientid
       * @return {any}
       */
      getUserByClientId(clientid) {
        return this.clients.get(clientid) || null;
      }
      /**
       * @param {ID} id
       * @return {string | null}
       */
      getUserByDeletedId(id2) {
        for (const [userDescription, ds] of this.dss.entries()) {
          if (isDeleted(ds, id2)) {
            return userDescription;
          }
        }
        return null;
      }
    };
    RelativePosition = class {
      /**
       * @param {ID|null} type
       * @param {string|null} tname
       * @param {ID|null} item
       * @param {number} assoc
       */
      constructor(type, tname, item, assoc = 0) {
        this.type = type;
        this.tname = tname;
        this.item = item;
        this.assoc = assoc;
      }
    };
    relativePositionToJSON = (rpos) => {
      const json = {};
      if (rpos.type) {
        json.type = rpos.type;
      }
      if (rpos.tname) {
        json.tname = rpos.tname;
      }
      if (rpos.item) {
        json.item = rpos.item;
      }
      if (rpos.assoc != null) {
        json.assoc = rpos.assoc;
      }
      return json;
    };
    createRelativePositionFromJSON = (json) => new RelativePosition(json.type == null ? null : createID(json.type.client, json.type.clock), json.tname ?? null, json.item == null ? null : createID(json.item.client, json.item.clock), json.assoc == null ? 0 : json.assoc);
    AbsolutePosition = class {
      /**
       * @param {AbstractType<any>} type
       * @param {number} index
       * @param {number} [assoc]
       */
      constructor(type, index, assoc = 0) {
        this.type = type;
        this.index = index;
        this.assoc = assoc;
      }
    };
    createAbsolutePosition = (type, index, assoc = 0) => new AbsolutePosition(type, index, assoc);
    createRelativePosition = (type, item, assoc) => {
      let typeid = null;
      let tname = null;
      if (type._item === null) {
        tname = findRootTypeKey(type);
      } else {
        typeid = createID(type._item.id.client, type._item.id.clock);
      }
      return new RelativePosition(typeid, tname, item, assoc);
    };
    createRelativePositionFromTypeIndex = (type, index, assoc = 0) => {
      let t = type._start;
      if (assoc < 0) {
        if (index === 0) {
          return createRelativePosition(type, null, assoc);
        }
        index--;
      }
      while (t !== null) {
        if (!t.deleted && t.countable) {
          if (t.length > index) {
            return createRelativePosition(type, createID(t.id.client, t.id.clock + index), assoc);
          }
          index -= t.length;
        }
        if (t.right === null && assoc < 0) {
          return createRelativePosition(type, t.lastId, assoc);
        }
        t = t.right;
      }
      return createRelativePosition(type, null, assoc);
    };
    writeRelativePosition = (encoder, rpos) => {
      const { type, tname, item, assoc } = rpos;
      if (item !== null) {
        writeVarUint(encoder, 0);
        writeID(encoder, item);
      } else if (tname !== null) {
        writeUint8(encoder, 1);
        writeVarString(encoder, tname);
      } else if (type !== null) {
        writeUint8(encoder, 2);
        writeID(encoder, type);
      } else {
        throw unexpectedCase();
      }
      writeVarInt(encoder, assoc);
      return encoder;
    };
    encodeRelativePosition = (rpos) => {
      const encoder = createEncoder();
      writeRelativePosition(encoder, rpos);
      return toUint8Array(encoder);
    };
    readRelativePosition = (decoder) => {
      let type = null;
      let tname = null;
      let itemID = null;
      switch (readVarUint(decoder)) {
        case 0:
          itemID = readID(decoder);
          break;
        case 1:
          tname = readVarString(decoder);
          break;
        case 2: {
          type = readID(decoder);
        }
      }
      const assoc = hasContent(decoder) ? readVarInt(decoder) : 0;
      return new RelativePosition(type, tname, itemID, assoc);
    };
    decodeRelativePosition = (uint8Array) => readRelativePosition(createDecoder(uint8Array));
    getItemWithOffset = (store, id2) => {
      const item = getItem(store, id2);
      const diff = id2.clock - item.id.clock;
      return {
        item,
        diff
      };
    };
    createAbsolutePositionFromRelativePosition = (rpos, doc, followUndoneDeletions = true) => {
      const store = doc.store;
      const rightID = rpos.item;
      const typeID = rpos.type;
      const tname = rpos.tname;
      const assoc = rpos.assoc;
      let type = null;
      let index = 0;
      if (rightID !== null) {
        if (getState(store, rightID.client) <= rightID.clock) {
          return null;
        }
        const res = followUndoneDeletions ? followRedone(store, rightID) : getItemWithOffset(store, rightID);
        const right = res.item;
        if (!(right instanceof Item)) {
          return null;
        }
        type = /** @type {AbstractType<any>} */
        right.parent;
        if (type._item === null || !type._item.deleted) {
          index = right.deleted || !right.countable ? 0 : res.diff + (assoc >= 0 ? 0 : 1);
          let n = right.left;
          while (n !== null) {
            if (!n.deleted && n.countable) {
              index += n.length;
            }
            n = n.left;
          }
        }
      } else {
        if (tname !== null) {
          type = doc.get(tname);
        } else if (typeID !== null) {
          if (getState(store, typeID.client) <= typeID.clock) {
            return null;
          }
          const { item } = followUndoneDeletions ? followRedone(store, typeID) : { item: getItem(store, typeID) };
          if (item instanceof Item && item.content instanceof ContentType) {
            type = item.content.type;
          } else {
            return null;
          }
        } else {
          throw unexpectedCase();
        }
        if (assoc >= 0) {
          index = type._length;
        } else {
          index = 0;
        }
      }
      return createAbsolutePosition(type, index, rpos.assoc);
    };
    compareRelativePositions = (a, b) => a === b || a !== null && b !== null && a.tname === b.tname && compareIDs(a.item, b.item) && compareIDs(a.type, b.type) && a.assoc === b.assoc;
    Snapshot = class {
      /**
       * @param {DeleteSet} ds
       * @param {Map<number,number>} sv state map
       */
      constructor(ds, sv) {
        this.ds = ds;
        this.sv = sv;
      }
    };
    equalSnapshots = (snap1, snap2) => {
      const ds1 = snap1.ds.clients;
      const ds2 = snap2.ds.clients;
      const sv1 = snap1.sv;
      const sv2 = snap2.sv;
      if (sv1.size !== sv2.size || ds1.size !== ds2.size) {
        return false;
      }
      for (const [key, value] of sv1.entries()) {
        if (sv2.get(key) !== value) {
          return false;
        }
      }
      for (const [client, dsitems1] of ds1.entries()) {
        const dsitems2 = ds2.get(client) || [];
        if (dsitems1.length !== dsitems2.length) {
          return false;
        }
        for (let i = 0; i < dsitems1.length; i++) {
          const dsitem1 = dsitems1[i];
          const dsitem2 = dsitems2[i];
          if (dsitem1.clock !== dsitem2.clock || dsitem1.len !== dsitem2.len) {
            return false;
          }
        }
      }
      return true;
    };
    encodeSnapshotV2 = (snapshot2, encoder = new DSEncoderV2()) => {
      writeDeleteSet(encoder, snapshot2.ds);
      writeStateVector(encoder, snapshot2.sv);
      return encoder.toUint8Array();
    };
    encodeSnapshot = (snapshot2) => encodeSnapshotV2(snapshot2, new DSEncoderV1());
    decodeSnapshotV2 = (buf, decoder = new DSDecoderV2(createDecoder(buf))) => {
      return new Snapshot(readDeleteSet(decoder), readStateVector(decoder));
    };
    decodeSnapshot = (buf) => decodeSnapshotV2(buf, new DSDecoderV1(createDecoder(buf)));
    createSnapshot = (ds, sm) => new Snapshot(ds, sm);
    emptySnapshot = createSnapshot(createDeleteSet(), /* @__PURE__ */ new Map());
    snapshot = (doc) => createSnapshot(createDeleteSetFromStructStore(doc.store), getStateVector(doc.store));
    isVisible = (item, snapshot2) => snapshot2 === void 0 ? !item.deleted : snapshot2.sv.has(item.id.client) && (snapshot2.sv.get(item.id.client) || 0) > item.id.clock && !isDeleted(snapshot2.ds, item.id);
    splitSnapshotAffectedStructs = (transaction, snapshot2) => {
      const meta = setIfUndefined(transaction.meta, splitSnapshotAffectedStructs, create2);
      const store = transaction.doc.store;
      if (!meta.has(snapshot2)) {
        snapshot2.sv.forEach((clock, client) => {
          if (clock < getState(store, client)) {
            getItemCleanStart(transaction, createID(client, clock));
          }
        });
        iterateDeletedStructs(transaction, snapshot2.ds, (_item) => {
        });
        meta.add(snapshot2);
      }
    };
    createDocFromSnapshot = (originDoc, snapshot2, newDoc = new Doc()) => {
      if (originDoc.gc) {
        throw new Error("Garbage-collection must be disabled in `originDoc`!");
      }
      const { sv, ds } = snapshot2;
      const encoder = new UpdateEncoderV2();
      originDoc.transact((transaction) => {
        let size2 = 0;
        sv.forEach((clock) => {
          if (clock > 0) {
            size2++;
          }
        });
        writeVarUint(encoder.restEncoder, size2);
        for (const [client, clock] of sv) {
          if (clock === 0) {
            continue;
          }
          if (clock < getState(originDoc.store, client)) {
            getItemCleanStart(transaction, createID(client, clock));
          }
          const structs = originDoc.store.clients.get(client) || [];
          const lastStructIndex = findIndexSS(structs, clock - 1);
          writeVarUint(encoder.restEncoder, lastStructIndex + 1);
          encoder.writeClient(client);
          writeVarUint(encoder.restEncoder, 0);
          for (let i = 0; i <= lastStructIndex; i++) {
            structs[i].write(encoder, 0);
          }
        }
        writeDeleteSet(encoder, ds);
      });
      applyUpdateV2(newDoc, encoder.toUint8Array(), "snapshot");
      return newDoc;
    };
    snapshotContainsUpdateV2 = (snapshot2, update, YDecoder = UpdateDecoderV2) => {
      const updateDecoder = new YDecoder(createDecoder(update));
      const lazyDecoder = new LazyStructReader(updateDecoder, false);
      for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) {
        if ((snapshot2.sv.get(curr.id.client) || 0) < curr.id.clock + curr.length) {
          return false;
        }
      }
      const mergedDS = mergeDeleteSets([snapshot2.ds, readDeleteSet(updateDecoder)]);
      return equalDeleteSets(snapshot2.ds, mergedDS);
    };
    snapshotContainsUpdate = (snapshot2, update) => snapshotContainsUpdateV2(snapshot2, update, UpdateDecoderV1);
    StructStore = class {
      constructor() {
        this.clients = /* @__PURE__ */ new Map();
        this.pendingStructs = null;
        this.pendingDs = null;
      }
    };
    getStateVector = (store) => {
      const sm = /* @__PURE__ */ new Map();
      store.clients.forEach((structs, client) => {
        const struct = structs[structs.length - 1];
        sm.set(client, struct.id.clock + struct.length);
      });
      return sm;
    };
    getState = (store, client) => {
      const structs = store.clients.get(client);
      if (structs === void 0) {
        return 0;
      }
      const lastStruct = structs[structs.length - 1];
      return lastStruct.id.clock + lastStruct.length;
    };
    addStruct = (store, struct) => {
      let structs = store.clients.get(struct.id.client);
      if (structs === void 0) {
        structs = [];
        store.clients.set(struct.id.client, structs);
      } else {
        const lastStruct = structs[structs.length - 1];
        if (lastStruct.id.clock + lastStruct.length !== struct.id.clock) {
          throw unexpectedCase();
        }
      }
      structs.push(struct);
    };
    findIndexSS = (structs, clock) => {
      let left = 0;
      let right = structs.length - 1;
      let mid = structs[right];
      let midclock = mid.id.clock;
      if (midclock === clock) {
        return right;
      }
      let midindex = floor(clock / (midclock + mid.length - 1) * right);
      while (left <= right) {
        mid = structs[midindex];
        midclock = mid.id.clock;
        if (midclock <= clock) {
          if (clock < midclock + mid.length) {
            return midindex;
          }
          left = midindex + 1;
        } else {
          right = midindex - 1;
        }
        midindex = floor((left + right) / 2);
      }
      throw unexpectedCase();
    };
    find = (store, id2) => {
      const structs = store.clients.get(id2.client);
      return structs[findIndexSS(structs, id2.clock)];
    };
    getItem = /** @type {function(StructStore,ID):Item} */
    find;
    findIndexCleanStart = (transaction, structs, clock) => {
      const index = findIndexSS(structs, clock);
      const struct = structs[index];
      if (struct.id.clock < clock && struct instanceof Item) {
        structs.splice(index + 1, 0, splitItem(transaction, struct, clock - struct.id.clock));
        return index + 1;
      }
      return index;
    };
    getItemCleanStart = (transaction, id2) => {
      const structs = (
        /** @type {Array<Item>} */
        transaction.doc.store.clients.get(id2.client)
      );
      return structs[findIndexCleanStart(transaction, structs, id2.clock)];
    };
    getItemCleanEnd = (transaction, store, id2) => {
      const structs = store.clients.get(id2.client);
      const index = findIndexSS(structs, id2.clock);
      const struct = structs[index];
      if (id2.clock !== struct.id.clock + struct.length - 1 && struct.constructor !== GC) {
        structs.splice(index + 1, 0, splitItem(transaction, struct, id2.clock - struct.id.clock + 1));
      }
      return struct;
    };
    replaceStruct = (store, struct, newStruct) => {
      const structs = (
        /** @type {Array<GC|Item>} */
        store.clients.get(struct.id.client)
      );
      structs[findIndexSS(structs, struct.id.clock)] = newStruct;
    };
    iterateStructs = (transaction, structs, clockStart, len, f) => {
      if (len === 0) {
        return;
      }
      const clockEnd = clockStart + len;
      let index = findIndexCleanStart(transaction, structs, clockStart);
      let struct;
      do {
        struct = structs[index++];
        if (clockEnd < struct.id.clock + struct.length) {
          findIndexCleanStart(transaction, structs, clockEnd);
        }
        f(struct);
      } while (index < structs.length && structs[index].id.clock < clockEnd);
    };
    Transaction = class {
      /**
       * @param {Doc} doc
       * @param {any} origin
       * @param {boolean} local
       */
      constructor(doc, origin, local) {
        this.doc = doc;
        this.deleteSet = new DeleteSet();
        this.beforeState = getStateVector(doc.store);
        this.afterState = /* @__PURE__ */ new Map();
        this.changed = /* @__PURE__ */ new Map();
        this.changedParentTypes = /* @__PURE__ */ new Map();
        this._mergeStructs = [];
        this.origin = origin;
        this.meta = /* @__PURE__ */ new Map();
        this.local = local;
        this.subdocsAdded = /* @__PURE__ */ new Set();
        this.subdocsRemoved = /* @__PURE__ */ new Set();
        this.subdocsLoaded = /* @__PURE__ */ new Set();
        this._needFormattingCleanup = false;
      }
    };
    writeUpdateMessageFromTransaction = (encoder, transaction) => {
      if (transaction.deleteSet.clients.size === 0 && !any(transaction.afterState, (clock, client) => transaction.beforeState.get(client) !== clock)) {
        return false;
      }
      sortAndMergeDeleteSet(transaction.deleteSet);
      writeStructsFromTransaction(encoder, transaction);
      writeDeleteSet(encoder, transaction.deleteSet);
      return true;
    };
    addChangedTypeToTransaction = (transaction, type, parentSub) => {
      const item = type._item;
      if (item === null || item.id.clock < (transaction.beforeState.get(item.id.client) || 0) && !item.deleted) {
        setIfUndefined(transaction.changed, type, create2).add(parentSub);
      }
    };
    tryToMergeWithLefts = (structs, pos) => {
      let right = structs[pos];
      let left = structs[pos - 1];
      let i = pos;
      for (; i > 0; right = left, left = structs[--i - 1]) {
        if (left.deleted === right.deleted && left.constructor === right.constructor) {
          if (left.mergeWith(right)) {
            if (right instanceof Item && right.parentSub !== null && /** @type {AbstractType<any>} */
            right.parent._map.get(right.parentSub) === right) {
              right.parent._map.set(
                right.parentSub,
                /** @type {Item} */
                left
              );
            }
            continue;
          }
        }
        break;
      }
      const merged = pos - i;
      if (merged) {
        structs.splice(pos + 1 - merged, merged);
      }
      return merged;
    };
    tryGcDeleteSet = (ds, store, gcFilter) => {
      for (const [client, deleteItems] of ds.clients.entries()) {
        const structs = (
          /** @type {Array<GC|Item>} */
          store.clients.get(client)
        );
        for (let di = deleteItems.length - 1; di >= 0; di--) {
          const deleteItem = deleteItems[di];
          const endDeleteItemClock = deleteItem.clock + deleteItem.len;
          for (let si = findIndexSS(structs, deleteItem.clock), struct = structs[si]; si < structs.length && struct.id.clock < endDeleteItemClock; struct = structs[++si]) {
            const struct2 = structs[si];
            if (deleteItem.clock + deleteItem.len <= struct2.id.clock) {
              break;
            }
            if (struct2 instanceof Item && struct2.deleted && !struct2.keep && gcFilter(struct2)) {
              struct2.gc(store, false);
            }
          }
        }
      }
    };
    tryMergeDeleteSet = (ds, store) => {
      ds.clients.forEach((deleteItems, client) => {
        const structs = (
          /** @type {Array<GC|Item>} */
          store.clients.get(client)
        );
        for (let di = deleteItems.length - 1; di >= 0; di--) {
          const deleteItem = deleteItems[di];
          const mostRightIndexToCheck = min(structs.length - 1, 1 + findIndexSS(structs, deleteItem.clock + deleteItem.len - 1));
          for (let si = mostRightIndexToCheck, struct = structs[si]; si > 0 && struct.id.clock >= deleteItem.clock; struct = structs[si]) {
            si -= 1 + tryToMergeWithLefts(structs, si);
          }
        }
      });
    };
    tryGc = (ds, store, gcFilter) => {
      tryGcDeleteSet(ds, store, gcFilter);
      tryMergeDeleteSet(ds, store);
    };
    cleanupTransactions = (transactionCleanups, i) => {
      if (i < transactionCleanups.length) {
        const transaction = transactionCleanups[i];
        const doc = transaction.doc;
        const store = doc.store;
        const ds = transaction.deleteSet;
        const mergeStructs = transaction._mergeStructs;
        try {
          sortAndMergeDeleteSet(ds);
          transaction.afterState = getStateVector(transaction.doc.store);
          doc.emit("beforeObserverCalls", [transaction, doc]);
          const fs = [];
          transaction.changed.forEach(
            (subs, itemtype) => fs.push(() => {
              if (itemtype._item === null || !itemtype._item.deleted) {
                itemtype._callObserver(transaction, subs);
              }
            })
          );
          fs.push(() => {
            transaction.changedParentTypes.forEach((events, type) => {
              if (type._dEH.l.length > 0 && (type._item === null || !type._item.deleted)) {
                events = events.filter(
                  (event) => event.target._item === null || !event.target._item.deleted
                );
                events.forEach((event) => {
                  event.currentTarget = type;
                  event._path = null;
                });
                events.sort((event1, event2) => event1.path.length - event2.path.length);
                fs.push(() => {
                  callEventHandlerListeners(type._dEH, events, transaction);
                });
              }
            });
            fs.push(() => doc.emit("afterTransaction", [transaction, doc]));
            fs.push(() => {
              if (transaction._needFormattingCleanup) {
                cleanupYTextAfterTransaction(transaction);
              }
            });
          });
          callAll(fs, []);
        } finally {
          if (doc.gc) {
            tryGcDeleteSet(ds, store, doc.gcFilter);
          }
          tryMergeDeleteSet(ds, store);
          transaction.afterState.forEach((clock, client) => {
            const beforeClock = transaction.beforeState.get(client) || 0;
            if (beforeClock !== clock) {
              const structs = (
                /** @type {Array<GC|Item>} */
                store.clients.get(client)
              );
              const firstChangePos = max(findIndexSS(structs, beforeClock), 1);
              for (let i2 = structs.length - 1; i2 >= firstChangePos; ) {
                i2 -= 1 + tryToMergeWithLefts(structs, i2);
              }
            }
          });
          for (let i2 = mergeStructs.length - 1; i2 >= 0; i2--) {
            const { client, clock } = mergeStructs[i2].id;
            const structs = (
              /** @type {Array<GC|Item>} */
              store.clients.get(client)
            );
            const replacedStructPos = findIndexSS(structs, clock);
            if (replacedStructPos + 1 < structs.length) {
              if (tryToMergeWithLefts(structs, replacedStructPos + 1) > 1) {
                continue;
              }
            }
            if (replacedStructPos > 0) {
              tryToMergeWithLefts(structs, replacedStructPos);
            }
          }
          if (!transaction.local && transaction.afterState.get(doc.clientID) !== transaction.beforeState.get(doc.clientID)) {
            print(ORANGE, BOLD, "[yjs] ", UNBOLD, RED, "Changed the client-id because another client seems to be using it.");
            doc.clientID = generateNewClientId();
          }
          doc.emit("afterTransactionCleanup", [transaction, doc]);
          if (doc._observers.has("update")) {
            const encoder = new UpdateEncoderV1();
            const hasContent2 = writeUpdateMessageFromTransaction(encoder, transaction);
            if (hasContent2) {
              doc.emit("update", [encoder.toUint8Array(), transaction.origin, doc, transaction]);
            }
          }
          if (doc._observers.has("updateV2")) {
            const encoder = new UpdateEncoderV2();
            const hasContent2 = writeUpdateMessageFromTransaction(encoder, transaction);
            if (hasContent2) {
              doc.emit("updateV2", [encoder.toUint8Array(), transaction.origin, doc, transaction]);
            }
          }
          const { subdocsAdded, subdocsLoaded, subdocsRemoved } = transaction;
          if (subdocsAdded.size > 0 || subdocsRemoved.size > 0 || subdocsLoaded.size > 0) {
            subdocsAdded.forEach((subdoc) => {
              subdoc.clientID = doc.clientID;
              if (subdoc.collectionid == null) {
                subdoc.collectionid = doc.collectionid;
              }
              doc.subdocs.add(subdoc);
            });
            subdocsRemoved.forEach((subdoc) => doc.subdocs.delete(subdoc));
            doc.emit("subdocs", [{ loaded: subdocsLoaded, added: subdocsAdded, removed: subdocsRemoved }, doc, transaction]);
            subdocsRemoved.forEach((subdoc) => subdoc.destroy());
          }
          if (transactionCleanups.length <= i + 1) {
            doc._transactionCleanups = [];
            doc.emit("afterAllTransactions", [doc, transactionCleanups]);
          } else {
            cleanupTransactions(transactionCleanups, i + 1);
          }
        }
      }
    };
    transact = (doc, f, origin = null, local = true) => {
      const transactionCleanups = doc._transactionCleanups;
      let initialCall = false;
      let result = null;
      if (doc._transaction === null) {
        initialCall = true;
        doc._transaction = new Transaction(doc, origin, local);
        transactionCleanups.push(doc._transaction);
        if (transactionCleanups.length === 1) {
          doc.emit("beforeAllTransactions", [doc]);
        }
        doc.emit("beforeTransaction", [doc._transaction, doc]);
      }
      try {
        result = f(doc._transaction);
      } finally {
        if (initialCall) {
          const finishCleanup = doc._transaction === transactionCleanups[0];
          doc._transaction = null;
          if (finishCleanup) {
            cleanupTransactions(transactionCleanups, 0);
          }
        }
      }
      return result;
    };
    StackItem = class {
      /**
       * @param {DeleteSet} deletions
       * @param {DeleteSet} insertions
       */
      constructor(deletions, insertions) {
        this.insertions = insertions;
        this.deletions = deletions;
        this.meta = /* @__PURE__ */ new Map();
      }
    };
    clearUndoManagerStackItem = (tr, um, stackItem) => {
      iterateDeletedStructs(tr, stackItem.deletions, (item) => {
        if (item instanceof Item && um.scope.some((type) => type === tr.doc || isParentOf(
          /** @type {AbstractType<any>} */
          type,
          item
        ))) {
          keepItem(item, false);
        }
      });
    };
    popStackItem = (undoManager, stack, eventType) => {
      let _tr = null;
      const doc = undoManager.doc;
      const scope = undoManager.scope;
      transact(doc, (transaction) => {
        while (stack.length > 0 && undoManager.currStackItem === null) {
          const store = doc.store;
          const stackItem = (
            /** @type {StackItem} */
            stack.pop()
          );
          const itemsToRedo = /* @__PURE__ */ new Set();
          const itemsToDelete = [];
          let performedChange = false;
          iterateDeletedStructs(transaction, stackItem.insertions, (struct) => {
            if (struct instanceof Item) {
              if (struct.redone !== null) {
                let { item, diff } = followRedone(store, struct.id);
                if (diff > 0) {
                  item = getItemCleanStart(transaction, createID(item.id.client, item.id.clock + diff));
                }
                struct = item;
              }
              if (!struct.deleted && scope.some((type) => type === transaction.doc || isParentOf(
                /** @type {AbstractType<any>} */
                type,
                /** @type {Item} */
                struct
              ))) {
                itemsToDelete.push(struct);
              }
            }
          });
          iterateDeletedStructs(transaction, stackItem.deletions, (struct) => {
            if (struct instanceof Item && scope.some((type) => type === transaction.doc || isParentOf(
              /** @type {AbstractType<any>} */
              type,
              struct
            )) && // Never redo structs in stackItem.insertions because they were created and deleted in the same capture interval.
            !isDeleted(stackItem.insertions, struct.id)) {
              itemsToRedo.add(struct);
            }
          });
          itemsToRedo.forEach((struct) => {
            performedChange = redoItem(transaction, struct, itemsToRedo, stackItem.insertions, undoManager.ignoreRemoteMapChanges, undoManager) !== null || performedChange;
          });
          for (let i = itemsToDelete.length - 1; i >= 0; i--) {
            const item = itemsToDelete[i];
            if (undoManager.deleteFilter(item)) {
              item.delete(transaction);
              performedChange = true;
            }
          }
          undoManager.currStackItem = performedChange ? stackItem : null;
        }
        transaction.changed.forEach((subProps, type) => {
          if (subProps.has(null) && type._searchMarker) {
            type._searchMarker.length = 0;
          }
        });
        _tr = transaction;
      }, undoManager);
      const res = undoManager.currStackItem;
      if (res != null) {
        const changedParentTypes = _tr.changedParentTypes;
        undoManager.emit("stack-item-popped", [{ stackItem: res, type: eventType, changedParentTypes, origin: undoManager }, undoManager]);
        undoManager.currStackItem = null;
      }
      return res;
    };
    UndoManager = class extends ObservableV2 {
      /**
       * @param {Doc|AbstractType<any>|Array<AbstractType<any>>} typeScope Limits the scope of the UndoManager. If this is set to a ydoc instance, all changes on that ydoc will be undone. If set to a specific type, only changes on that type or its children will be undone. Also accepts an array of types.
       * @param {UndoManagerOptions} options
       */
      constructor(typeScope, {
        captureTimeout = 500,
        captureTransaction = (_tr) => true,
        deleteFilter = () => true,
        trackedOrigins = /* @__PURE__ */ new Set([null]),
        ignoreRemoteMapChanges = false,
        doc = (
          /** @type {Doc} */
          isArray(typeScope) ? typeScope[0].doc : typeScope instanceof Doc ? typeScope : typeScope.doc
        )
      } = {}) {
        super();
        this.scope = [];
        this.doc = doc;
        this.addToScope(typeScope);
        this.deleteFilter = deleteFilter;
        trackedOrigins.add(this);
        this.trackedOrigins = trackedOrigins;
        this.captureTransaction = captureTransaction;
        this.undoStack = [];
        this.redoStack = [];
        this.undoing = false;
        this.redoing = false;
        this.currStackItem = null;
        this.lastChange = 0;
        this.ignoreRemoteMapChanges = ignoreRemoteMapChanges;
        this.captureTimeout = captureTimeout;
        this.afterTransactionHandler = (transaction) => {
          if (!this.captureTransaction(transaction) || !this.scope.some((type) => transaction.changedParentTypes.has(
            /** @type {AbstractType<any>} */
            type
          ) || type === this.doc) || !this.trackedOrigins.has(transaction.origin) && (!transaction.origin || !this.trackedOrigins.has(transaction.origin.constructor))) {
            return;
          }
          const undoing = this.undoing;
          const redoing = this.redoing;
          const stack = undoing ? this.redoStack : this.undoStack;
          if (undoing) {
            this.stopCapturing();
          } else if (!redoing) {
            this.clear(false, true);
          }
          const insertions = new DeleteSet();
          transaction.afterState.forEach((endClock, client) => {
            const startClock = transaction.beforeState.get(client) || 0;
            const len = endClock - startClock;
            if (len > 0) {
              addToDeleteSet(insertions, client, startClock, len);
            }
          });
          const now = getUnixTime();
          let didAdd = false;
          if (this.lastChange > 0 && now - this.lastChange < this.captureTimeout && stack.length > 0 && !undoing && !redoing) {
            const lastOp = stack[stack.length - 1];
            lastOp.deletions = mergeDeleteSets([lastOp.deletions, transaction.deleteSet]);
            lastOp.insertions = mergeDeleteSets([lastOp.insertions, insertions]);
          } else {
            stack.push(new StackItem(transaction.deleteSet, insertions));
            didAdd = true;
          }
          if (!undoing && !redoing) {
            this.lastChange = now;
          }
          iterateDeletedStructs(
            transaction,
            transaction.deleteSet,
            /** @param {Item|GC} item */
            (item) => {
              if (item instanceof Item && this.scope.some((type) => type === transaction.doc || isParentOf(
                /** @type {AbstractType<any>} */
                type,
                item
              ))) {
                keepItem(item, true);
              }
            }
          );
          const changeEvent = [{ stackItem: stack[stack.length - 1], origin: transaction.origin, type: undoing ? "redo" : "undo", changedParentTypes: transaction.changedParentTypes }, this];
          if (didAdd) {
            this.emit("stack-item-added", changeEvent);
          } else {
            this.emit("stack-item-updated", changeEvent);
          }
        };
        this.doc.on("afterTransaction", this.afterTransactionHandler);
        this.doc.on("destroy", () => {
          this.destroy();
        });
      }
      /**
       * Extend the scope.
       *
       * @param {Array<AbstractType<any> | Doc> | AbstractType<any> | Doc} ytypes
       */
      addToScope(ytypes) {
        const tmpSet = new Set(this.scope);
        ytypes = isArray(ytypes) ? ytypes : [ytypes];
        ytypes.forEach((ytype) => {
          if (!tmpSet.has(ytype)) {
            tmpSet.add(ytype);
            if (ytype instanceof AbstractType ? ytype.doc !== this.doc : ytype !== this.doc)
              warn("[yjs#509] Not same Y.Doc");
            this.scope.push(ytype);
          }
        });
      }
      /**
       * @param {any} origin
       */
      addTrackedOrigin(origin) {
        this.trackedOrigins.add(origin);
      }
      /**
       * @param {any} origin
       */
      removeTrackedOrigin(origin) {
        this.trackedOrigins.delete(origin);
      }
      clear(clearUndoStack = true, clearRedoStack = true) {
        if (clearUndoStack && this.canUndo() || clearRedoStack && this.canRedo()) {
          this.doc.transact((tr) => {
            if (clearUndoStack) {
              this.undoStack.forEach((item) => clearUndoManagerStackItem(tr, this, item));
              this.undoStack = [];
            }
            if (clearRedoStack) {
              this.redoStack.forEach((item) => clearUndoManagerStackItem(tr, this, item));
              this.redoStack = [];
            }
            this.emit("stack-cleared", [{ undoStackCleared: clearUndoStack, redoStackCleared: clearRedoStack }]);
          });
        }
      }
      /**
       * UndoManager merges Undo-StackItem if they are created within time-gap
       * smaller than `options.captureTimeout`. Call `um.stopCapturing()` so that the next
       * StackItem won't be merged.
       *
       *
       * @example
       *     // without stopCapturing
       *     ytext.insert(0, 'a')
       *     ytext.insert(1, 'b')
       *     um.undo()
       *     ytext.toString() // => '' (note that 'ab' was removed)
       *     // with stopCapturing
       *     ytext.insert(0, 'a')
       *     um.stopCapturing()
       *     ytext.insert(0, 'b')
       *     um.undo()
       *     ytext.toString() // => 'a' (note that only 'b' was removed)
       *
       */
      stopCapturing() {
        this.lastChange = 0;
      }
      /**
       * Undo last changes on type.
       *
       * @return {StackItem?} Returns StackItem if a change was applied
       */
      undo() {
        this.undoing = true;
        let res;
        try {
          res = popStackItem(this, this.undoStack, "undo");
        } finally {
          this.undoing = false;
        }
        return res;
      }
      /**
       * Redo last undo operation.
       *
       * @return {StackItem?} Returns StackItem if a change was applied
       */
      redo() {
        this.redoing = true;
        let res;
        try {
          res = popStackItem(this, this.redoStack, "redo");
        } finally {
          this.redoing = false;
        }
        return res;
      }
      /**
       * Are undo steps available?
       *
       * @return {boolean} `true` if undo is possible
       */
      canUndo() {
        return this.undoStack.length > 0;
      }
      /**
       * Are redo steps available?
       *
       * @return {boolean} `true` if redo is possible
       */
      canRedo() {
        return this.redoStack.length > 0;
      }
      destroy() {
        this.trackedOrigins.delete(this);
        this.doc.off("afterTransaction", this.afterTransactionHandler);
        super.destroy();
      }
    };
    LazyStructReader = class {
      /**
       * @param {UpdateDecoderV1 | UpdateDecoderV2} decoder
       * @param {boolean} filterSkips
       */
      constructor(decoder, filterSkips) {
        this.gen = lazyStructReaderGenerator(decoder);
        this.curr = null;
        this.done = false;
        this.filterSkips = filterSkips;
        this.next();
      }
      /**
       * @return {Item | GC | Skip |null}
       */
      next() {
        do {
          this.curr = this.gen.next().value || null;
        } while (this.filterSkips && this.curr !== null && this.curr.constructor === Skip);
        return this.curr;
      }
    };
    logUpdate = (update) => logUpdateV2(update, UpdateDecoderV1);
    logUpdateV2 = (update, YDecoder = UpdateDecoderV2) => {
      const structs = [];
      const updateDecoder = new YDecoder(createDecoder(update));
      const lazyDecoder = new LazyStructReader(updateDecoder, false);
      for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) {
        structs.push(curr);
      }
      print("Structs: ", structs);
      const ds = readDeleteSet(updateDecoder);
      print("DeleteSet: ", ds);
    };
    decodeUpdate = (update) => decodeUpdateV2(update, UpdateDecoderV1);
    decodeUpdateV2 = (update, YDecoder = UpdateDecoderV2) => {
      const structs = [];
      const updateDecoder = new YDecoder(createDecoder(update));
      const lazyDecoder = new LazyStructReader(updateDecoder, false);
      for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) {
        structs.push(curr);
      }
      return {
        structs,
        ds: readDeleteSet(updateDecoder)
      };
    };
    LazyStructWriter = class {
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       */
      constructor(encoder) {
        this.currClient = 0;
        this.startClock = 0;
        this.written = 0;
        this.encoder = encoder;
        this.clientStructs = [];
      }
    };
    mergeUpdates = (updates) => mergeUpdatesV2(updates, UpdateDecoderV1, UpdateEncoderV1);
    encodeStateVectorFromUpdateV2 = (update, YEncoder = DSEncoderV2, YDecoder = UpdateDecoderV2) => {
      const encoder = new YEncoder();
      const updateDecoder = new LazyStructReader(new YDecoder(createDecoder(update)), false);
      let curr = updateDecoder.curr;
      if (curr !== null) {
        let size2 = 0;
        let currClient = curr.id.client;
        let stopCounting = curr.id.clock !== 0;
        let currClock = stopCounting ? 0 : curr.id.clock + curr.length;
        for (; curr !== null; curr = updateDecoder.next()) {
          if (currClient !== curr.id.client) {
            if (currClock !== 0) {
              size2++;
              writeVarUint(encoder.restEncoder, currClient);
              writeVarUint(encoder.restEncoder, currClock);
            }
            currClient = curr.id.client;
            currClock = 0;
            stopCounting = curr.id.clock !== 0;
          }
          if (curr.constructor === Skip) {
            stopCounting = true;
          }
          if (!stopCounting) {
            currClock = curr.id.clock + curr.length;
          }
        }
        if (currClock !== 0) {
          size2++;
          writeVarUint(encoder.restEncoder, currClient);
          writeVarUint(encoder.restEncoder, currClock);
        }
        const enc = createEncoder();
        writeVarUint(enc, size2);
        writeBinaryEncoder(enc, encoder.restEncoder);
        encoder.restEncoder = enc;
        return encoder.toUint8Array();
      } else {
        writeVarUint(encoder.restEncoder, 0);
        return encoder.toUint8Array();
      }
    };
    encodeStateVectorFromUpdate = (update) => encodeStateVectorFromUpdateV2(update, DSEncoderV1, UpdateDecoderV1);
    parseUpdateMetaV2 = (update, YDecoder = UpdateDecoderV2) => {
      const from2 = /* @__PURE__ */ new Map();
      const to = /* @__PURE__ */ new Map();
      const updateDecoder = new LazyStructReader(new YDecoder(createDecoder(update)), false);
      let curr = updateDecoder.curr;
      if (curr !== null) {
        let currClient = curr.id.client;
        let currClock = curr.id.clock;
        from2.set(currClient, currClock);
        for (; curr !== null; curr = updateDecoder.next()) {
          if (currClient !== curr.id.client) {
            to.set(currClient, currClock);
            from2.set(curr.id.client, curr.id.clock);
            currClient = curr.id.client;
          }
          currClock = curr.id.clock + curr.length;
        }
        to.set(currClient, currClock);
      }
      return { from: from2, to };
    };
    parseUpdateMeta = (update) => parseUpdateMetaV2(update, UpdateDecoderV1);
    sliceStruct = (left, diff) => {
      if (left.constructor === GC) {
        const { client, clock } = left.id;
        return new GC(createID(client, clock + diff), left.length - diff);
      } else if (left.constructor === Skip) {
        const { client, clock } = left.id;
        return new Skip(createID(client, clock + diff), left.length - diff);
      } else {
        const leftItem = (
          /** @type {Item} */
          left
        );
        const { client, clock } = leftItem.id;
        return new Item(
          createID(client, clock + diff),
          null,
          createID(client, clock + diff - 1),
          null,
          leftItem.rightOrigin,
          leftItem.parent,
          leftItem.parentSub,
          leftItem.content.splice(diff)
        );
      }
    };
    mergeUpdatesV2 = (updates, YDecoder = UpdateDecoderV2, YEncoder = UpdateEncoderV2) => {
      if (updates.length === 1) {
        return updates[0];
      }
      const updateDecoders = updates.map((update) => new YDecoder(createDecoder(update)));
      let lazyStructDecoders = updateDecoders.map((decoder) => new LazyStructReader(decoder, true));
      let currWrite = null;
      const updateEncoder = new YEncoder();
      const lazyStructEncoder = new LazyStructWriter(updateEncoder);
      while (true) {
        lazyStructDecoders = lazyStructDecoders.filter((dec) => dec.curr !== null);
        lazyStructDecoders.sort(
          /** @type {function(any,any):number} */
          (dec1, dec2) => {
            if (dec1.curr.id.client === dec2.curr.id.client) {
              const clockDiff = dec1.curr.id.clock - dec2.curr.id.clock;
              if (clockDiff === 0) {
                return dec1.curr.constructor === dec2.curr.constructor ? 0 : dec1.curr.constructor === Skip ? 1 : -1;
              } else {
                return clockDiff;
              }
            } else {
              return dec2.curr.id.client - dec1.curr.id.client;
            }
          }
        );
        if (lazyStructDecoders.length === 0) {
          break;
        }
        const currDecoder = lazyStructDecoders[0];
        const firstClient = (
          /** @type {Item | GC} */
          currDecoder.curr.id.client
        );
        if (currWrite !== null) {
          let curr = (
            /** @type {Item | GC | null} */
            currDecoder.curr
          );
          let iterated = false;
          while (curr !== null && curr.id.clock + curr.length <= currWrite.struct.id.clock + currWrite.struct.length && curr.id.client >= currWrite.struct.id.client) {
            curr = currDecoder.next();
            iterated = true;
          }
          if (curr === null || // current decoder is empty
          curr.id.client !== firstClient || // check whether there is another decoder that has has updates from `firstClient`
          iterated && curr.id.clock > currWrite.struct.id.clock + currWrite.struct.length) {
            continue;
          }
          if (firstClient !== currWrite.struct.id.client) {
            writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
            currWrite = { struct: curr, offset: 0 };
            currDecoder.next();
          } else {
            if (currWrite.struct.id.clock + currWrite.struct.length < curr.id.clock) {
              if (currWrite.struct.constructor === Skip) {
                currWrite.struct.length = curr.id.clock + curr.length - currWrite.struct.id.clock;
              } else {
                writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
                const diff = curr.id.clock - currWrite.struct.id.clock - currWrite.struct.length;
                const struct = new Skip(createID(firstClient, currWrite.struct.id.clock + currWrite.struct.length), diff);
                currWrite = { struct, offset: 0 };
              }
            } else {
              const diff = currWrite.struct.id.clock + currWrite.struct.length - curr.id.clock;
              if (diff > 0) {
                if (currWrite.struct.constructor === Skip) {
                  currWrite.struct.length -= diff;
                } else {
                  curr = sliceStruct(curr, diff);
                }
              }
              if (!currWrite.struct.mergeWith(
                /** @type {any} */
                curr
              )) {
                writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
                currWrite = { struct: curr, offset: 0 };
                currDecoder.next();
              }
            }
          }
        } else {
          currWrite = { struct: (
            /** @type {Item | GC} */
            currDecoder.curr
          ), offset: 0 };
          currDecoder.next();
        }
        for (let next = currDecoder.curr; next !== null && next.id.client === firstClient && next.id.clock === currWrite.struct.id.clock + currWrite.struct.length && next.constructor !== Skip; next = currDecoder.next()) {
          writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
          currWrite = { struct: next, offset: 0 };
        }
      }
      if (currWrite !== null) {
        writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
        currWrite = null;
      }
      finishLazyStructWriting(lazyStructEncoder);
      const dss = updateDecoders.map((decoder) => readDeleteSet(decoder));
      const ds = mergeDeleteSets(dss);
      writeDeleteSet(updateEncoder, ds);
      return updateEncoder.toUint8Array();
    };
    diffUpdateV2 = (update, sv, YDecoder = UpdateDecoderV2, YEncoder = UpdateEncoderV2) => {
      const state = decodeStateVector(sv);
      const encoder = new YEncoder();
      const lazyStructWriter = new LazyStructWriter(encoder);
      const decoder = new YDecoder(createDecoder(update));
      const reader = new LazyStructReader(decoder, false);
      while (reader.curr) {
        const curr = reader.curr;
        const currClient = curr.id.client;
        const svClock = state.get(currClient) || 0;
        if (reader.curr.constructor === Skip) {
          reader.next();
          continue;
        }
        if (curr.id.clock + curr.length > svClock) {
          writeStructToLazyStructWriter(lazyStructWriter, curr, max(svClock - curr.id.clock, 0));
          reader.next();
          while (reader.curr && reader.curr.id.client === currClient) {
            writeStructToLazyStructWriter(lazyStructWriter, reader.curr, 0);
            reader.next();
          }
        } else {
          while (reader.curr && reader.curr.id.client === currClient && reader.curr.id.clock + reader.curr.length <= svClock) {
            reader.next();
          }
        }
      }
      finishLazyStructWriting(lazyStructWriter);
      const ds = readDeleteSet(decoder);
      writeDeleteSet(encoder, ds);
      return encoder.toUint8Array();
    };
    diffUpdate = (update, sv) => diffUpdateV2(update, sv, UpdateDecoderV1, UpdateEncoderV1);
    flushLazyStructWriter = (lazyWriter) => {
      if (lazyWriter.written > 0) {
        lazyWriter.clientStructs.push({ written: lazyWriter.written, restEncoder: toUint8Array(lazyWriter.encoder.restEncoder) });
        lazyWriter.encoder.restEncoder = createEncoder();
        lazyWriter.written = 0;
      }
    };
    writeStructToLazyStructWriter = (lazyWriter, struct, offset) => {
      if (lazyWriter.written > 0 && lazyWriter.currClient !== struct.id.client) {
        flushLazyStructWriter(lazyWriter);
      }
      if (lazyWriter.written === 0) {
        lazyWriter.currClient = struct.id.client;
        lazyWriter.encoder.writeClient(struct.id.client);
        writeVarUint(lazyWriter.encoder.restEncoder, struct.id.clock + offset);
      }
      struct.write(lazyWriter.encoder, offset);
      lazyWriter.written++;
    };
    finishLazyStructWriting = (lazyWriter) => {
      flushLazyStructWriter(lazyWriter);
      const restEncoder = lazyWriter.encoder.restEncoder;
      writeVarUint(restEncoder, lazyWriter.clientStructs.length);
      for (let i = 0; i < lazyWriter.clientStructs.length; i++) {
        const partStructs = lazyWriter.clientStructs[i];
        writeVarUint(restEncoder, partStructs.written);
        writeUint8Array(restEncoder, partStructs.restEncoder);
      }
    };
    convertUpdateFormat = (update, blockTransformer, YDecoder, YEncoder) => {
      const updateDecoder = new YDecoder(createDecoder(update));
      const lazyDecoder = new LazyStructReader(updateDecoder, false);
      const updateEncoder = new YEncoder();
      const lazyWriter = new LazyStructWriter(updateEncoder);
      for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) {
        writeStructToLazyStructWriter(lazyWriter, blockTransformer(curr), 0);
      }
      finishLazyStructWriting(lazyWriter);
      const ds = readDeleteSet(updateDecoder);
      writeDeleteSet(updateEncoder, ds);
      return updateEncoder.toUint8Array();
    };
    createObfuscator = ({ formatting = true, subdocs = true, yxml = true } = {}) => {
      let i = 0;
      const mapKeyCache = create();
      const nodeNameCache = create();
      const formattingKeyCache = create();
      const formattingValueCache = create();
      formattingValueCache.set(null, null);
      return (block) => {
        switch (block.constructor) {
          case GC:
          case Skip:
            return block;
          case Item: {
            const item = (
              /** @type {Item} */
              block
            );
            const content = item.content;
            switch (content.constructor) {
              case ContentDeleted:
                break;
              case ContentType: {
                if (yxml) {
                  const type = (
                    /** @type {ContentType} */
                    content.type
                  );
                  if (type instanceof YXmlElement) {
                    type.nodeName = setIfUndefined(nodeNameCache, type.nodeName, () => "node-" + i);
                  }
                  if (type instanceof YXmlHook) {
                    type.hookName = setIfUndefined(nodeNameCache, type.hookName, () => "hook-" + i);
                  }
                }
                break;
              }
              case ContentAny: {
                const c = (
                  /** @type {ContentAny} */
                  content
                );
                c.arr = c.arr.map(() => i);
                break;
              }
              case ContentBinary: {
                const c = (
                  /** @type {ContentBinary} */
                  content
                );
                c.content = new Uint8Array([i]);
                break;
              }
              case ContentDoc: {
                const c = (
                  /** @type {ContentDoc} */
                  content
                );
                if (subdocs) {
                  c.opts = {};
                  c.doc.guid = i + "";
                }
                break;
              }
              case ContentEmbed: {
                const c = (
                  /** @type {ContentEmbed} */
                  content
                );
                c.embed = {};
                break;
              }
              case ContentFormat: {
                const c = (
                  /** @type {ContentFormat} */
                  content
                );
                if (formatting) {
                  c.key = setIfUndefined(formattingKeyCache, c.key, () => i + "");
                  c.value = setIfUndefined(formattingValueCache, c.value, () => ({ i }));
                }
                break;
              }
              case ContentJSON: {
                const c = (
                  /** @type {ContentJSON} */
                  content
                );
                c.arr = c.arr.map(() => i);
                break;
              }
              case ContentString: {
                const c = (
                  /** @type {ContentString} */
                  content
                );
                c.str = repeat(i % 10 + "", c.str.length);
                break;
              }
              default:
                unexpectedCase();
            }
            if (item.parentSub) {
              item.parentSub = setIfUndefined(mapKeyCache, item.parentSub, () => i + "");
            }
            i++;
            return block;
          }
          default:
            unexpectedCase();
        }
      };
    };
    obfuscateUpdate = (update, opts) => convertUpdateFormat(update, createObfuscator(opts), UpdateDecoderV1, UpdateEncoderV1);
    obfuscateUpdateV2 = (update, opts) => convertUpdateFormat(update, createObfuscator(opts), UpdateDecoderV2, UpdateEncoderV2);
    convertUpdateFormatV1ToV2 = (update) => convertUpdateFormat(update, id, UpdateDecoderV1, UpdateEncoderV2);
    convertUpdateFormatV2ToV1 = (update) => convertUpdateFormat(update, id, UpdateDecoderV2, UpdateEncoderV1);
    errorComputeChanges = "You must not compute changes after the event-handler fired.";
    YEvent = class {
      /**
       * @param {T} target The changed type.
       * @param {Transaction} transaction
       */
      constructor(target, transaction) {
        this.target = target;
        this.currentTarget = target;
        this.transaction = transaction;
        this._changes = null;
        this._keys = null;
        this._delta = null;
        this._path = null;
      }
      /**
       * Computes the path from `y` to the changed type.
       *
       * @todo v14 should standardize on path: Array<{parent, index}> because that is easier to work with.
       *
       * The following property holds:
       * @example
       *   let type = y
       *   event.path.forEach(dir => {
       *     type = type.get(dir)
       *   })
       *   type === event.target // => true
       */
      get path() {
        return this._path || (this._path = getPathTo(this.currentTarget, this.target));
      }
      /**
       * Check if a struct is deleted by this event.
       *
       * In contrast to change.deleted, this method also returns true if the struct was added and then deleted.
       *
       * @param {AbstractStruct} struct
       * @return {boolean}
       */
      deletes(struct) {
        return isDeleted(this.transaction.deleteSet, struct.id);
      }
      /**
       * @type {Map<string, { action: 'add' | 'update' | 'delete', oldValue: any }>}
       */
      get keys() {
        if (this._keys === null) {
          if (this.transaction.doc._transactionCleanups.length === 0) {
            throw create3(errorComputeChanges);
          }
          const keys2 = /* @__PURE__ */ new Map();
          const target = this.target;
          const changed = (
            /** @type Set<string|null> */
            this.transaction.changed.get(target)
          );
          changed.forEach((key) => {
            if (key !== null) {
              const item = (
                /** @type {Item} */
                target._map.get(key)
              );
              let action;
              let oldValue;
              if (this.adds(item)) {
                let prev = item.left;
                while (prev !== null && this.adds(prev)) {
                  prev = prev.left;
                }
                if (this.deletes(item)) {
                  if (prev !== null && this.deletes(prev)) {
                    action = "delete";
                    oldValue = last(prev.content.getContent());
                  } else {
                    return;
                  }
                } else {
                  if (prev !== null && this.deletes(prev)) {
                    action = "update";
                    oldValue = last(prev.content.getContent());
                  } else {
                    action = "add";
                    oldValue = void 0;
                  }
                }
              } else {
                if (this.deletes(item)) {
                  action = "delete";
                  oldValue = last(
                    /** @type {Item} */
                    item.content.getContent()
                  );
                } else {
                  return;
                }
              }
              keys2.set(key, { action, oldValue });
            }
          });
          this._keys = keys2;
        }
        return this._keys;
      }
      /**
       * This is a computed property. Note that this can only be safely computed during the
       * event call. Computing this property after other changes happened might result in
       * unexpected behavior (incorrect computation of deltas). A safe way to collect changes
       * is to store the `changes` or the `delta` object. Avoid storing the `transaction` object.
       *
       * @type {Array<{insert?: string | Array<any> | object | AbstractType<any>, retain?: number, delete?: number, attributes?: Object<string, any>}>}
       */
      get delta() {
        return this.changes.delta;
      }
      /**
       * Check if a struct is added by this event.
       *
       * In contrast to change.deleted, this method also returns true if the struct was added and then deleted.
       *
       * @param {AbstractStruct} struct
       * @return {boolean}
       */
      adds(struct) {
        return struct.id.clock >= (this.transaction.beforeState.get(struct.id.client) || 0);
      }
      /**
       * This is a computed property. Note that this can only be safely computed during the
       * event call. Computing this property after other changes happened might result in
       * unexpected behavior (incorrect computation of deltas). A safe way to collect changes
       * is to store the `changes` or the `delta` object. Avoid storing the `transaction` object.
       *
       * @type {{added:Set<Item>,deleted:Set<Item>,keys:Map<string,{action:'add'|'update'|'delete',oldValue:any}>,delta:Array<{insert?:Array<any>|string, delete?:number, retain?:number}>}}
       */
      get changes() {
        let changes = this._changes;
        if (changes === null) {
          if (this.transaction.doc._transactionCleanups.length === 0) {
            throw create3(errorComputeChanges);
          }
          const target = this.target;
          const added = create2();
          const deleted = create2();
          const delta = [];
          changes = {
            added,
            deleted,
            delta,
            keys: this.keys
          };
          const changed = (
            /** @type Set<string|null> */
            this.transaction.changed.get(target)
          );
          if (changed.has(null)) {
            let lastOp = null;
            const packOp = () => {
              if (lastOp) {
                delta.push(lastOp);
              }
            };
            for (let item = target._start; item !== null; item = item.right) {
              if (item.deleted) {
                if (this.deletes(item) && !this.adds(item)) {
                  if (lastOp === null || lastOp.delete === void 0) {
                    packOp();
                    lastOp = { delete: 0 };
                  }
                  lastOp.delete += item.length;
                  deleted.add(item);
                }
              } else {
                if (this.adds(item)) {
                  if (lastOp === null || lastOp.insert === void 0) {
                    packOp();
                    lastOp = { insert: [] };
                  }
                  lastOp.insert = lastOp.insert.concat(item.content.getContent());
                  added.add(item);
                } else {
                  if (lastOp === null || lastOp.retain === void 0) {
                    packOp();
                    lastOp = { retain: 0 };
                  }
                  lastOp.retain += item.length;
                }
              }
            }
            if (lastOp !== null && lastOp.retain === void 0) {
              packOp();
            }
          }
          this._changes = changes;
        }
        return (
          /** @type {any} */
          changes
        );
      }
    };
    getPathTo = (parent, child) => {
      const path = [];
      while (child._item !== null && child !== parent) {
        if (child._item.parentSub !== null) {
          path.unshift(child._item.parentSub);
        } else {
          let i = 0;
          let c = (
            /** @type {AbstractType<any>} */
            child._item.parent._start
          );
          while (c !== child._item && c !== null) {
            if (!c.deleted && c.countable) {
              i += c.length;
            }
            c = c.right;
          }
          path.unshift(i);
        }
        child = /** @type {AbstractType<any>} */
        child._item.parent;
      }
      return path;
    };
    warnPrematureAccess = () => {
      warn("Invalid access: Add Yjs type to a document before reading data.");
    };
    maxSearchMarker = 80;
    globalSearchMarkerTimestamp = 0;
    ArraySearchMarker = class {
      /**
       * @param {Item} p
       * @param {number} index
       */
      constructor(p, index) {
        p.marker = true;
        this.p = p;
        this.index = index;
        this.timestamp = globalSearchMarkerTimestamp++;
      }
    };
    refreshMarkerTimestamp = (marker) => {
      marker.timestamp = globalSearchMarkerTimestamp++;
    };
    overwriteMarker = (marker, p, index) => {
      marker.p.marker = false;
      marker.p = p;
      p.marker = true;
      marker.index = index;
      marker.timestamp = globalSearchMarkerTimestamp++;
    };
    markPosition = (searchMarker, p, index) => {
      if (searchMarker.length >= maxSearchMarker) {
        const marker = searchMarker.reduce((a, b) => a.timestamp < b.timestamp ? a : b);
        overwriteMarker(marker, p, index);
        return marker;
      } else {
        const pm = new ArraySearchMarker(p, index);
        searchMarker.push(pm);
        return pm;
      }
    };
    findMarker = (yarray, index) => {
      if (yarray._start === null || index === 0 || yarray._searchMarker === null) {
        return null;
      }
      const marker = yarray._searchMarker.length === 0 ? null : yarray._searchMarker.reduce((a, b) => abs(index - a.index) < abs(index - b.index) ? a : b);
      let p = yarray._start;
      let pindex = 0;
      if (marker !== null) {
        p = marker.p;
        pindex = marker.index;
        refreshMarkerTimestamp(marker);
      }
      while (p.right !== null && pindex < index) {
        if (!p.deleted && p.countable) {
          if (index < pindex + p.length) {
            break;
          }
          pindex += p.length;
        }
        p = p.right;
      }
      while (p.left !== null && pindex > index) {
        p = p.left;
        if (!p.deleted && p.countable) {
          pindex -= p.length;
        }
      }
      while (p.left !== null && p.left.id.client === p.id.client && p.left.id.clock + p.left.length === p.id.clock) {
        p = p.left;
        if (!p.deleted && p.countable) {
          pindex -= p.length;
        }
      }
      if (marker !== null && abs(marker.index - pindex) < /** @type {YText|YArray<any>} */
      p.parent.length / maxSearchMarker) {
        overwriteMarker(marker, p, pindex);
        return marker;
      } else {
        return markPosition(yarray._searchMarker, p, pindex);
      }
    };
    updateMarkerChanges = (searchMarker, index, len) => {
      for (let i = searchMarker.length - 1; i >= 0; i--) {
        const m = searchMarker[i];
        if (len > 0) {
          let p = m.p;
          p.marker = false;
          while (p && (p.deleted || !p.countable)) {
            p = p.left;
            if (p && !p.deleted && p.countable) {
              m.index -= p.length;
            }
          }
          if (p === null || p.marker === true) {
            searchMarker.splice(i, 1);
            continue;
          }
          m.p = p;
          p.marker = true;
        }
        if (index < m.index || len > 0 && index === m.index) {
          m.index = max(index, m.index + len);
        }
      }
    };
    getTypeChildren = (t) => {
      t.doc ?? warnPrematureAccess();
      let s = t._start;
      const arr = [];
      while (s) {
        arr.push(s);
        s = s.right;
      }
      return arr;
    };
    callTypeObservers = (type, transaction, event) => {
      const changedType = type;
      const changedParentTypes = transaction.changedParentTypes;
      while (true) {
        setIfUndefined(changedParentTypes, type, () => []).push(event);
        if (type._item === null) {
          break;
        }
        type = /** @type {AbstractType<any>} */
        type._item.parent;
      }
      callEventHandlerListeners(changedType._eH, event, transaction);
    };
    AbstractType = class {
      constructor() {
        this._item = null;
        this._map = /* @__PURE__ */ new Map();
        this._start = null;
        this.doc = null;
        this._length = 0;
        this._eH = createEventHandler();
        this._dEH = createEventHandler();
        this._searchMarker = null;
      }
      /**
       * @return {AbstractType<any>|null}
       */
      get parent() {
        return this._item ? (
          /** @type {AbstractType<any>} */
          this._item.parent
        ) : null;
      }
      /**
       * Integrate this type into the Yjs instance.
       *
       * * Save this struct in the os
       * * This type is sent to other client
       * * Observer functions are fired
       *
       * @param {Doc} y The Yjs instance
       * @param {Item|null} item
       */
      _integrate(y, item) {
        this.doc = y;
        this._item = item;
      }
      /**
       * @return {AbstractType<EventType>}
       */
      _copy() {
        throw methodUnimplemented();
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {AbstractType<EventType>}
       */
      clone() {
        throw methodUnimplemented();
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} _encoder
       */
      _write(_encoder) {
      }
      /**
       * The first non-deleted item
       */
      get _first() {
        let n = this._start;
        while (n !== null && n.deleted) {
          n = n.right;
        }
        return n;
      }
      /**
       * Creates YEvent and calls all type observers.
       * Must be implemented by each type.
       *
       * @param {Transaction} transaction
       * @param {Set<null|string>} _parentSubs Keys changed on this type. `null` if list was modified.
       */
      _callObserver(transaction, _parentSubs) {
        if (!transaction.local && this._searchMarker) {
          this._searchMarker.length = 0;
        }
      }
      /**
       * Observe all events that are created on this type.
       *
       * @param {function(EventType, Transaction):void} f Observer function
       */
      observe(f) {
        addEventHandlerListener(this._eH, f);
      }
      /**
       * Observe all events that are created by this type and its children.
       *
       * @param {function(Array<YEvent<any>>,Transaction):void} f Observer function
       */
      observeDeep(f) {
        addEventHandlerListener(this._dEH, f);
      }
      /**
       * Unregister an observer function.
       *
       * @param {function(EventType,Transaction):void} f Observer function
       */
      unobserve(f) {
        removeEventHandlerListener(this._eH, f);
      }
      /**
       * Unregister an observer function.
       *
       * @param {function(Array<YEvent<any>>,Transaction):void} f Observer function
       */
      unobserveDeep(f) {
        removeEventHandlerListener(this._dEH, f);
      }
      /**
       * @abstract
       * @return {any}
       */
      toJSON() {
      }
    };
    typeListSlice = (type, start, end) => {
      type.doc ?? warnPrematureAccess();
      if (start < 0) {
        start = type._length + start;
      }
      if (end < 0) {
        end = type._length + end;
      }
      let len = end - start;
      const cs = [];
      let n = type._start;
      while (n !== null && len > 0) {
        if (n.countable && !n.deleted) {
          const c = n.content.getContent();
          if (c.length <= start) {
            start -= c.length;
          } else {
            for (let i = start; i < c.length && len > 0; i++) {
              cs.push(c[i]);
              len--;
            }
            start = 0;
          }
        }
        n = n.right;
      }
      return cs;
    };
    typeListToArray = (type) => {
      type.doc ?? warnPrematureAccess();
      const cs = [];
      let n = type._start;
      while (n !== null) {
        if (n.countable && !n.deleted) {
          const c = n.content.getContent();
          for (let i = 0; i < c.length; i++) {
            cs.push(c[i]);
          }
        }
        n = n.right;
      }
      return cs;
    };
    typeListToArraySnapshot = (type, snapshot2) => {
      const cs = [];
      let n = type._start;
      while (n !== null) {
        if (n.countable && isVisible(n, snapshot2)) {
          const c = n.content.getContent();
          for (let i = 0; i < c.length; i++) {
            cs.push(c[i]);
          }
        }
        n = n.right;
      }
      return cs;
    };
    typeListForEach = (type, f) => {
      let index = 0;
      let n = type._start;
      type.doc ?? warnPrematureAccess();
      while (n !== null) {
        if (n.countable && !n.deleted) {
          const c = n.content.getContent();
          for (let i = 0; i < c.length; i++) {
            f(c[i], index++, type);
          }
        }
        n = n.right;
      }
    };
    typeListMap = (type, f) => {
      const result = [];
      typeListForEach(type, (c, i) => {
        result.push(f(c, i, type));
      });
      return result;
    };
    typeListCreateIterator = (type) => {
      let n = type._start;
      let currentContent = null;
      let currentContentIndex = 0;
      return {
        [Symbol.iterator]() {
          return this;
        },
        next: () => {
          if (currentContent === null) {
            while (n !== null && n.deleted) {
              n = n.right;
            }
            if (n === null) {
              return {
                done: true,
                value: void 0
              };
            }
            currentContent = n.content.getContent();
            currentContentIndex = 0;
            n = n.right;
          }
          const value = currentContent[currentContentIndex++];
          if (currentContent.length <= currentContentIndex) {
            currentContent = null;
          }
          return {
            done: false,
            value
          };
        }
      };
    };
    typeListGet = (type, index) => {
      type.doc ?? warnPrematureAccess();
      const marker = findMarker(type, index);
      let n = type._start;
      if (marker !== null) {
        n = marker.p;
        index -= marker.index;
      }
      for (; n !== null; n = n.right) {
        if (!n.deleted && n.countable) {
          if (index < n.length) {
            return n.content.getContent()[index];
          }
          index -= n.length;
        }
      }
    };
    typeListInsertGenericsAfter = (transaction, parent, referenceItem, content) => {
      let left = referenceItem;
      const doc = transaction.doc;
      const ownClientId = doc.clientID;
      const store = doc.store;
      const right = referenceItem === null ? parent._start : referenceItem.right;
      let jsonContent = [];
      const packJsonContent = () => {
        if (jsonContent.length > 0) {
          left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentAny(jsonContent));
          left.integrate(transaction, 0);
          jsonContent = [];
        }
      };
      content.forEach((c) => {
        if (c === null) {
          jsonContent.push(c);
        } else {
          switch (c.constructor) {
            case Number:
            case Object:
            case Boolean:
            case Array:
            case String:
              jsonContent.push(c);
              break;
            default:
              packJsonContent();
              switch (c.constructor) {
                case Uint8Array:
                case ArrayBuffer:
                  left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentBinary(new Uint8Array(
                    /** @type {Uint8Array} */
                    c
                  )));
                  left.integrate(transaction, 0);
                  break;
                case Doc:
                  left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentDoc(
                    /** @type {Doc} */
                    c
                  ));
                  left.integrate(transaction, 0);
                  break;
                default:
                  if (c instanceof AbstractType) {
                    left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentType(c));
                    left.integrate(transaction, 0);
                  } else {
                    throw new Error("Unexpected content type in insert operation");
                  }
              }
          }
        }
      });
      packJsonContent();
    };
    lengthExceeded = () => create3("Length exceeded!");
    typeListInsertGenerics = (transaction, parent, index, content) => {
      if (index > parent._length) {
        throw lengthExceeded();
      }
      if (index === 0) {
        if (parent._searchMarker) {
          updateMarkerChanges(parent._searchMarker, index, content.length);
        }
        return typeListInsertGenericsAfter(transaction, parent, null, content);
      }
      const startIndex = index;
      const marker = findMarker(parent, index);
      let n = parent._start;
      if (marker !== null) {
        n = marker.p;
        index -= marker.index;
        if (index === 0) {
          n = n.prev;
          index += n && n.countable && !n.deleted ? n.length : 0;
        }
      }
      for (; n !== null; n = n.right) {
        if (!n.deleted && n.countable) {
          if (index <= n.length) {
            if (index < n.length) {
              getItemCleanStart(transaction, createID(n.id.client, n.id.clock + index));
            }
            break;
          }
          index -= n.length;
        }
      }
      if (parent._searchMarker) {
        updateMarkerChanges(parent._searchMarker, startIndex, content.length);
      }
      return typeListInsertGenericsAfter(transaction, parent, n, content);
    };
    typeListPushGenerics = (transaction, parent, content) => {
      const marker = (parent._searchMarker || []).reduce((maxMarker, currMarker) => currMarker.index > maxMarker.index ? currMarker : maxMarker, { index: 0, p: parent._start });
      let n = marker.p;
      if (n) {
        while (n.right) {
          n = n.right;
        }
      }
      return typeListInsertGenericsAfter(transaction, parent, n, content);
    };
    typeListDelete = (transaction, parent, index, length2) => {
      if (length2 === 0) {
        return;
      }
      const startIndex = index;
      const startLength = length2;
      const marker = findMarker(parent, index);
      let n = parent._start;
      if (marker !== null) {
        n = marker.p;
        index -= marker.index;
      }
      for (; n !== null && index > 0; n = n.right) {
        if (!n.deleted && n.countable) {
          if (index < n.length) {
            getItemCleanStart(transaction, createID(n.id.client, n.id.clock + index));
          }
          index -= n.length;
        }
      }
      while (length2 > 0 && n !== null) {
        if (!n.deleted) {
          if (length2 < n.length) {
            getItemCleanStart(transaction, createID(n.id.client, n.id.clock + length2));
          }
          n.delete(transaction);
          length2 -= n.length;
        }
        n = n.right;
      }
      if (length2 > 0) {
        throw lengthExceeded();
      }
      if (parent._searchMarker) {
        updateMarkerChanges(
          parent._searchMarker,
          startIndex,
          -startLength + length2
          /* in case we remove the above exception */
        );
      }
    };
    typeMapDelete = (transaction, parent, key) => {
      const c = parent._map.get(key);
      if (c !== void 0) {
        c.delete(transaction);
      }
    };
    typeMapSet = (transaction, parent, key, value) => {
      const left = parent._map.get(key) || null;
      const doc = transaction.doc;
      const ownClientId = doc.clientID;
      let content;
      if (value == null) {
        content = new ContentAny([value]);
      } else {
        switch (value.constructor) {
          case Number:
          case Object:
          case Boolean:
          case Array:
          case String:
          case Date:
          case BigInt:
            content = new ContentAny([value]);
            break;
          case Uint8Array:
            content = new ContentBinary(
              /** @type {Uint8Array} */
              value
            );
            break;
          case Doc:
            content = new ContentDoc(
              /** @type {Doc} */
              value
            );
            break;
          default:
            if (value instanceof AbstractType) {
              content = new ContentType(value);
            } else {
              throw new Error("Unexpected content type");
            }
        }
      }
      new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, null, null, parent, key, content).integrate(transaction, 0);
    };
    typeMapGet = (parent, key) => {
      parent.doc ?? warnPrematureAccess();
      const val = parent._map.get(key);
      return val !== void 0 && !val.deleted ? val.content.getContent()[val.length - 1] : void 0;
    };
    typeMapGetAll = (parent) => {
      const res = {};
      parent.doc ?? warnPrematureAccess();
      parent._map.forEach((value, key) => {
        if (!value.deleted) {
          res[key] = value.content.getContent()[value.length - 1];
        }
      });
      return res;
    };
    typeMapHas = (parent, key) => {
      parent.doc ?? warnPrematureAccess();
      const val = parent._map.get(key);
      return val !== void 0 && !val.deleted;
    };
    typeMapGetSnapshot = (parent, key, snapshot2) => {
      let v = parent._map.get(key) || null;
      while (v !== null && (!snapshot2.sv.has(v.id.client) || v.id.clock >= (snapshot2.sv.get(v.id.client) || 0))) {
        v = v.left;
      }
      return v !== null && isVisible(v, snapshot2) ? v.content.getContent()[v.length - 1] : void 0;
    };
    typeMapGetAllSnapshot = (parent, snapshot2) => {
      const res = {};
      parent._map.forEach((value, key) => {
        let v = value;
        while (v !== null && (!snapshot2.sv.has(v.id.client) || v.id.clock >= (snapshot2.sv.get(v.id.client) || 0))) {
          v = v.left;
        }
        if (v !== null && isVisible(v, snapshot2)) {
          res[key] = v.content.getContent()[v.length - 1];
        }
      });
      return res;
    };
    createMapIterator = (type) => {
      type.doc ?? warnPrematureAccess();
      return iteratorFilter(
        type._map.entries(),
        /** @param {any} entry */
        (entry) => !entry[1].deleted
      );
    };
    YArrayEvent = class extends YEvent {
    };
    YArray = class _YArray extends AbstractType {
      constructor() {
        super();
        this._prelimContent = [];
        this._searchMarker = [];
      }
      /**
       * Construct a new YArray containing the specified items.
       * @template {Object<string,any>|Array<any>|number|null|string|Uint8Array} T
       * @param {Array<T>} items
       * @return {YArray<T>}
       */
      static from(items) {
        const a = new _YArray();
        a.push(items);
        return a;
      }
      /**
       * Integrate this type into the Yjs instance.
       *
       * * Save this struct in the os
       * * This type is sent to other client
       * * Observer functions are fired
       *
       * @param {Doc} y The Yjs instance
       * @param {Item} item
       */
      _integrate(y, item) {
        super._integrate(y, item);
        this.insert(
          0,
          /** @type {Array<any>} */
          this._prelimContent
        );
        this._prelimContent = null;
      }
      /**
       * @return {YArray<T>}
       */
      _copy() {
        return new _YArray();
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YArray<T>}
       */
      clone() {
        const arr = new _YArray();
        arr.insert(0, this.toArray().map(
          (el) => el instanceof AbstractType ? (
            /** @type {typeof el} */
            el.clone()
          ) : el
        ));
        return arr;
      }
      get length() {
        this.doc ?? warnPrematureAccess();
        return this._length;
      }
      /**
       * Creates YArrayEvent and calls observers.
       *
       * @param {Transaction} transaction
       * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
       */
      _callObserver(transaction, parentSubs) {
        super._callObserver(transaction, parentSubs);
        callTypeObservers(this, transaction, new YArrayEvent(this, transaction));
      }
      /**
       * Inserts new content at an index.
       *
       * Important: This function expects an array of content. Not just a content
       * object. The reason for this "weirdness" is that inserting several elements
       * is very efficient when it is done as a single operation.
       *
       * @example
       *  // Insert character 'a' at position 0
       *  yarray.insert(0, ['a'])
       *  // Insert numbers 1, 2 at position 1
       *  yarray.insert(1, [1, 2])
       *
       * @param {number} index The index to insert content at.
       * @param {Array<T>} content The array of content
       */
      insert(index, content) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeListInsertGenerics(
              transaction,
              this,
              index,
              /** @type {any} */
              content
            );
          });
        } else {
          this._prelimContent.splice(index, 0, ...content);
        }
      }
      /**
       * Appends content to this YArray.
       *
       * @param {Array<T>} content Array of content to append.
       *
       * @todo Use the following implementation in all types.
       */
      push(content) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeListPushGenerics(
              transaction,
              this,
              /** @type {any} */
              content
            );
          });
        } else {
          this._prelimContent.push(...content);
        }
      }
      /**
       * Prepends content to this YArray.
       *
       * @param {Array<T>} content Array of content to prepend.
       */
      unshift(content) {
        this.insert(0, content);
      }
      /**
       * Deletes elements starting from an index.
       *
       * @param {number} index Index at which to start deleting elements
       * @param {number} length The number of elements to remove. Defaults to 1.
       */
      delete(index, length2 = 1) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeListDelete(transaction, this, index, length2);
          });
        } else {
          this._prelimContent.splice(index, length2);
        }
      }
      /**
       * Returns the i-th element from a YArray.
       *
       * @param {number} index The index of the element to return from the YArray
       * @return {T}
       */
      get(index) {
        return typeListGet(this, index);
      }
      /**
       * Transforms this YArray to a JavaScript Array.
       *
       * @return {Array<T>}
       */
      toArray() {
        return typeListToArray(this);
      }
      /**
       * Returns a portion of this YArray into a JavaScript Array selected
       * from start to end (end not included).
       *
       * @param {number} [start]
       * @param {number} [end]
       * @return {Array<T>}
       */
      slice(start = 0, end = this.length) {
        return typeListSlice(this, start, end);
      }
      /**
       * Transforms this Shared Type to a JSON object.
       *
       * @return {Array<any>}
       */
      toJSON() {
        return this.map((c) => c instanceof AbstractType ? c.toJSON() : c);
      }
      /**
       * Returns an Array with the result of calling a provided function on every
       * element of this YArray.
       *
       * @template M
       * @param {function(T,number,YArray<T>):M} f Function that produces an element of the new Array
       * @return {Array<M>} A new array with each element being the result of the
       *                 callback function
       */
      map(f) {
        return typeListMap(
          this,
          /** @type {any} */
          f
        );
      }
      /**
       * Executes a provided function once on every element of this YArray.
       *
       * @param {function(T,number,YArray<T>):void} f A function to execute on every element of this YArray.
       */
      forEach(f) {
        typeListForEach(this, f);
      }
      /**
       * @return {IterableIterator<T>}
       */
      [Symbol.iterator]() {
        return typeListCreateIterator(this);
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       */
      _write(encoder) {
        encoder.writeTypeRef(YArrayRefID);
      }
    };
    readYArray = (_decoder) => new YArray();
    YMapEvent = class extends YEvent {
      /**
       * @param {YMap<T>} ymap The YArray that changed.
       * @param {Transaction} transaction
       * @param {Set<any>} subs The keys that changed.
       */
      constructor(ymap, transaction, subs) {
        super(ymap, transaction);
        this.keysChanged = subs;
      }
    };
    YMap = class _YMap extends AbstractType {
      /**
       *
       * @param {Iterable<readonly [string, any]>=} entries - an optional iterable to initialize the YMap
       */
      constructor(entries) {
        super();
        this._prelimContent = null;
        if (entries === void 0) {
          this._prelimContent = /* @__PURE__ */ new Map();
        } else {
          this._prelimContent = new Map(entries);
        }
      }
      /**
       * Integrate this type into the Yjs instance.
       *
       * * Save this struct in the os
       * * This type is sent to other client
       * * Observer functions are fired
       *
       * @param {Doc} y The Yjs instance
       * @param {Item} item
       */
      _integrate(y, item) {
        super._integrate(y, item);
        this._prelimContent.forEach((value, key) => {
          this.set(key, value);
        });
        this._prelimContent = null;
      }
      /**
       * @return {YMap<MapType>}
       */
      _copy() {
        return new _YMap();
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YMap<MapType>}
       */
      clone() {
        const map2 = new _YMap();
        this.forEach((value, key) => {
          map2.set(key, value instanceof AbstractType ? (
            /** @type {typeof value} */
            value.clone()
          ) : value);
        });
        return map2;
      }
      /**
       * Creates YMapEvent and calls observers.
       *
       * @param {Transaction} transaction
       * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
       */
      _callObserver(transaction, parentSubs) {
        callTypeObservers(this, transaction, new YMapEvent(this, transaction, parentSubs));
      }
      /**
       * Transforms this Shared Type to a JSON object.
       *
       * @return {Object<string,any>}
       */
      toJSON() {
        this.doc ?? warnPrematureAccess();
        const map2 = {};
        this._map.forEach((item, key) => {
          if (!item.deleted) {
            const v = item.content.getContent()[item.length - 1];
            map2[key] = v instanceof AbstractType ? v.toJSON() : v;
          }
        });
        return map2;
      }
      /**
       * Returns the size of the YMap (count of key/value pairs)
       *
       * @return {number}
       */
      get size() {
        return [...createMapIterator(this)].length;
      }
      /**
       * Returns the keys for each element in the YMap Type.
       *
       * @return {IterableIterator<string>}
       */
      keys() {
        return iteratorMap(
          createMapIterator(this),
          /** @param {any} v */
          (v) => v[0]
        );
      }
      /**
       * Returns the values for each element in the YMap Type.
       *
       * @return {IterableIterator<MapType>}
       */
      values() {
        return iteratorMap(
          createMapIterator(this),
          /** @param {any} v */
          (v) => v[1].content.getContent()[v[1].length - 1]
        );
      }
      /**
       * Returns an Iterator of [key, value] pairs
       *
       * @return {IterableIterator<[string, MapType]>}
       */
      entries() {
        return iteratorMap(
          createMapIterator(this),
          /** @param {any} v */
          (v) => (
            /** @type {any} */
            [v[0], v[1].content.getContent()[v[1].length - 1]]
          )
        );
      }
      /**
       * Executes a provided function on once on every key-value pair.
       *
       * @param {function(MapType,string,YMap<MapType>):void} f A function to execute on every element of this YArray.
       */
      forEach(f) {
        this.doc ?? warnPrematureAccess();
        this._map.forEach((item, key) => {
          if (!item.deleted) {
            f(item.content.getContent()[item.length - 1], key, this);
          }
        });
      }
      /**
       * Returns an Iterator of [key, value] pairs
       *
       * @return {IterableIterator<[string, MapType]>}
       */
      [Symbol.iterator]() {
        return this.entries();
      }
      /**
       * Remove a specified element from this YMap.
       *
       * @param {string} key The key of the element to remove.
       */
      delete(key) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeMapDelete(transaction, this, key);
          });
        } else {
          this._prelimContent.delete(key);
        }
      }
      /**
       * Adds or updates an element with a specified key and value.
       * @template {MapType} VAL
       *
       * @param {string} key The key of the element to add to this YMap
       * @param {VAL} value The value of the element to add
       * @return {VAL}
       */
      set(key, value) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeMapSet(
              transaction,
              this,
              key,
              /** @type {any} */
              value
            );
          });
        } else {
          this._prelimContent.set(key, value);
        }
        return value;
      }
      /**
       * Returns a specified element from this YMap.
       *
       * @param {string} key
       * @return {MapType|undefined}
       */
      get(key) {
        return (
          /** @type {any} */
          typeMapGet(this, key)
        );
      }
      /**
       * Returns a boolean indicating whether the specified key exists or not.
       *
       * @param {string} key The key to test.
       * @return {boolean}
       */
      has(key) {
        return typeMapHas(this, key);
      }
      /**
       * Removes all elements from this YMap.
       */
      clear() {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            this.forEach(function(_value, key, map2) {
              typeMapDelete(transaction, map2, key);
            });
          });
        } else {
          this._prelimContent.clear();
        }
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       */
      _write(encoder) {
        encoder.writeTypeRef(YMapRefID);
      }
    };
    readYMap = (_decoder) => new YMap();
    equalAttrs = (a, b) => a === b || typeof a === "object" && typeof b === "object" && a && b && equalFlat(a, b);
    ItemTextListPosition = class {
      /**
       * @param {Item|null} left
       * @param {Item|null} right
       * @param {number} index
       * @param {Map<string,any>} currentAttributes
       */
      constructor(left, right, index, currentAttributes) {
        this.left = left;
        this.right = right;
        this.index = index;
        this.currentAttributes = currentAttributes;
      }
      /**
       * Only call this if you know that this.right is defined
       */
      forward() {
        if (this.right === null) {
          unexpectedCase();
        }
        switch (this.right.content.constructor) {
          case ContentFormat:
            if (!this.right.deleted) {
              updateCurrentAttributes(
                this.currentAttributes,
                /** @type {ContentFormat} */
                this.right.content
              );
            }
            break;
          default:
            if (!this.right.deleted) {
              this.index += this.right.length;
            }
            break;
        }
        this.left = this.right;
        this.right = this.right.right;
      }
    };
    findNextPosition = (transaction, pos, count) => {
      while (pos.right !== null && count > 0) {
        switch (pos.right.content.constructor) {
          case ContentFormat:
            if (!pos.right.deleted) {
              updateCurrentAttributes(
                pos.currentAttributes,
                /** @type {ContentFormat} */
                pos.right.content
              );
            }
            break;
          default:
            if (!pos.right.deleted) {
              if (count < pos.right.length) {
                getItemCleanStart(transaction, createID(pos.right.id.client, pos.right.id.clock + count));
              }
              pos.index += pos.right.length;
              count -= pos.right.length;
            }
            break;
        }
        pos.left = pos.right;
        pos.right = pos.right.right;
      }
      return pos;
    };
    findPosition = (transaction, parent, index, useSearchMarker) => {
      const currentAttributes = /* @__PURE__ */ new Map();
      const marker = useSearchMarker ? findMarker(parent, index) : null;
      if (marker) {
        const pos = new ItemTextListPosition(marker.p.left, marker.p, marker.index, currentAttributes);
        return findNextPosition(transaction, pos, index - marker.index);
      } else {
        const pos = new ItemTextListPosition(null, parent._start, 0, currentAttributes);
        return findNextPosition(transaction, pos, index);
      }
    };
    insertNegatedAttributes = (transaction, parent, currPos, negatedAttributes) => {
      while (currPos.right !== null && (currPos.right.deleted === true || currPos.right.content.constructor === ContentFormat && equalAttrs(
        negatedAttributes.get(
          /** @type {ContentFormat} */
          currPos.right.content.key
        ),
        /** @type {ContentFormat} */
        currPos.right.content.value
      ))) {
        if (!currPos.right.deleted) {
          negatedAttributes.delete(
            /** @type {ContentFormat} */
            currPos.right.content.key
          );
        }
        currPos.forward();
      }
      const doc = transaction.doc;
      const ownClientId = doc.clientID;
      negatedAttributes.forEach((val, key) => {
        const left = currPos.left;
        const right = currPos.right;
        const nextFormat = new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentFormat(key, val));
        nextFormat.integrate(transaction, 0);
        currPos.right = nextFormat;
        currPos.forward();
      });
    };
    updateCurrentAttributes = (currentAttributes, format) => {
      const { key, value } = format;
      if (value === null) {
        currentAttributes.delete(key);
      } else {
        currentAttributes.set(key, value);
      }
    };
    minimizeAttributeChanges = (currPos, attributes) => {
      while (true) {
        if (currPos.right === null) {
          break;
        } else if (currPos.right.deleted || currPos.right.content.constructor === ContentFormat && equalAttrs(
          attributes[
            /** @type {ContentFormat} */
            currPos.right.content.key
          ] ?? null,
          /** @type {ContentFormat} */
          currPos.right.content.value
        ))
          ;
        else {
          break;
        }
        currPos.forward();
      }
    };
    insertAttributes = (transaction, parent, currPos, attributes) => {
      const doc = transaction.doc;
      const ownClientId = doc.clientID;
      const negatedAttributes = /* @__PURE__ */ new Map();
      for (const key in attributes) {
        const val = attributes[key];
        const currentVal = currPos.currentAttributes.get(key) ?? null;
        if (!equalAttrs(currentVal, val)) {
          negatedAttributes.set(key, currentVal);
          const { left, right } = currPos;
          currPos.right = new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentFormat(key, val));
          currPos.right.integrate(transaction, 0);
          currPos.forward();
        }
      }
      return negatedAttributes;
    };
    insertText = (transaction, parent, currPos, text, attributes) => {
      currPos.currentAttributes.forEach((_val, key) => {
        if (attributes[key] === void 0) {
          attributes[key] = null;
        }
      });
      const doc = transaction.doc;
      const ownClientId = doc.clientID;
      minimizeAttributeChanges(currPos, attributes);
      const negatedAttributes = insertAttributes(transaction, parent, currPos, attributes);
      const content = text.constructor === String ? new ContentString(
        /** @type {string} */
        text
      ) : text instanceof AbstractType ? new ContentType(text) : new ContentEmbed(text);
      let { left, right, index } = currPos;
      if (parent._searchMarker) {
        updateMarkerChanges(parent._searchMarker, currPos.index, content.getLength());
      }
      right = new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, content);
      right.integrate(transaction, 0);
      currPos.right = right;
      currPos.index = index;
      currPos.forward();
      insertNegatedAttributes(transaction, parent, currPos, negatedAttributes);
    };
    formatText = (transaction, parent, currPos, length2, attributes) => {
      const doc = transaction.doc;
      const ownClientId = doc.clientID;
      minimizeAttributeChanges(currPos, attributes);
      const negatedAttributes = insertAttributes(transaction, parent, currPos, attributes);
      iterationLoop:
        while (currPos.right !== null && (length2 > 0 || negatedAttributes.size > 0 && (currPos.right.deleted || currPos.right.content.constructor === ContentFormat))) {
          if (!currPos.right.deleted) {
            switch (currPos.right.content.constructor) {
              case ContentFormat: {
                const { key, value } = (
                  /** @type {ContentFormat} */
                  currPos.right.content
                );
                const attr = attributes[key];
                if (attr !== void 0) {
                  if (equalAttrs(attr, value)) {
                    negatedAttributes.delete(key);
                  } else {
                    if (length2 === 0) {
                      break iterationLoop;
                    }
                    negatedAttributes.set(key, value);
                  }
                  currPos.right.delete(transaction);
                } else {
                  currPos.currentAttributes.set(key, value);
                }
                break;
              }
              default:
                if (length2 < currPos.right.length) {
                  getItemCleanStart(transaction, createID(currPos.right.id.client, currPos.right.id.clock + length2));
                }
                length2 -= currPos.right.length;
                break;
            }
          }
          currPos.forward();
        }
      if (length2 > 0) {
        let newlines = "";
        for (; length2 > 0; length2--) {
          newlines += "\n";
        }
        currPos.right = new Item(createID(ownClientId, getState(doc.store, ownClientId)), currPos.left, currPos.left && currPos.left.lastId, currPos.right, currPos.right && currPos.right.id, parent, null, new ContentString(newlines));
        currPos.right.integrate(transaction, 0);
        currPos.forward();
      }
      insertNegatedAttributes(transaction, parent, currPos, negatedAttributes);
    };
    cleanupFormattingGap = (transaction, start, curr, startAttributes, currAttributes) => {
      let end = start;
      const endFormats = create();
      while (end && (!end.countable || end.deleted)) {
        if (!end.deleted && end.content.constructor === ContentFormat) {
          const cf = (
            /** @type {ContentFormat} */
            end.content
          );
          endFormats.set(cf.key, cf);
        }
        end = end.right;
      }
      let cleanups = 0;
      let reachedCurr = false;
      while (start !== end) {
        if (curr === start) {
          reachedCurr = true;
        }
        if (!start.deleted) {
          const content = start.content;
          switch (content.constructor) {
            case ContentFormat: {
              const { key, value } = (
                /** @type {ContentFormat} */
                content
              );
              const startAttrValue = startAttributes.get(key) ?? null;
              if (endFormats.get(key) !== content || startAttrValue === value) {
                start.delete(transaction);
                cleanups++;
                if (!reachedCurr && (currAttributes.get(key) ?? null) === value && startAttrValue !== value) {
                  if (startAttrValue === null) {
                    currAttributes.delete(key);
                  } else {
                    currAttributes.set(key, startAttrValue);
                  }
                }
              }
              if (!reachedCurr && !start.deleted) {
                updateCurrentAttributes(
                  currAttributes,
                  /** @type {ContentFormat} */
                  content
                );
              }
              break;
            }
          }
        }
        start = /** @type {Item} */
        start.right;
      }
      return cleanups;
    };
    cleanupContextlessFormattingGap = (transaction, item) => {
      while (item && item.right && (item.right.deleted || !item.right.countable)) {
        item = item.right;
      }
      const attrs = /* @__PURE__ */ new Set();
      while (item && (item.deleted || !item.countable)) {
        if (!item.deleted && item.content.constructor === ContentFormat) {
          const key = (
            /** @type {ContentFormat} */
            item.content.key
          );
          if (attrs.has(key)) {
            item.delete(transaction);
          } else {
            attrs.add(key);
          }
        }
        item = item.left;
      }
    };
    cleanupYTextFormatting = (type) => {
      let res = 0;
      transact(
        /** @type {Doc} */
        type.doc,
        (transaction) => {
          let start = (
            /** @type {Item} */
            type._start
          );
          let end = type._start;
          let startAttributes = create();
          const currentAttributes = copy(startAttributes);
          while (end) {
            if (end.deleted === false) {
              switch (end.content.constructor) {
                case ContentFormat:
                  updateCurrentAttributes(
                    currentAttributes,
                    /** @type {ContentFormat} */
                    end.content
                  );
                  break;
                default:
                  res += cleanupFormattingGap(transaction, start, end, startAttributes, currentAttributes);
                  startAttributes = copy(currentAttributes);
                  start = end;
                  break;
              }
            }
            end = end.right;
          }
        }
      );
      return res;
    };
    cleanupYTextAfterTransaction = (transaction) => {
      const needFullCleanup = /* @__PURE__ */ new Set();
      const doc = transaction.doc;
      for (const [client, afterClock] of transaction.afterState.entries()) {
        const clock = transaction.beforeState.get(client) || 0;
        if (afterClock === clock) {
          continue;
        }
        iterateStructs(
          transaction,
          /** @type {Array<Item|GC>} */
          doc.store.clients.get(client),
          clock,
          afterClock,
          (item) => {
            if (!item.deleted && /** @type {Item} */
            item.content.constructor === ContentFormat && item.constructor !== GC) {
              needFullCleanup.add(
                /** @type {any} */
                item.parent
              );
            }
          }
        );
      }
      transact(doc, (t) => {
        iterateDeletedStructs(transaction, transaction.deleteSet, (item) => {
          if (item instanceof GC || !/** @type {YText} */
          item.parent._hasFormatting || needFullCleanup.has(
            /** @type {YText} */
            item.parent
          )) {
            return;
          }
          const parent = (
            /** @type {YText} */
            item.parent
          );
          if (item.content.constructor === ContentFormat) {
            needFullCleanup.add(parent);
          } else {
            cleanupContextlessFormattingGap(t, item);
          }
        });
        for (const yText of needFullCleanup) {
          cleanupYTextFormatting(yText);
        }
      });
    };
    deleteText = (transaction, currPos, length2) => {
      const startLength = length2;
      const startAttrs = copy(currPos.currentAttributes);
      const start = currPos.right;
      while (length2 > 0 && currPos.right !== null) {
        if (currPos.right.deleted === false) {
          switch (currPos.right.content.constructor) {
            case ContentType:
            case ContentEmbed:
            case ContentString:
              if (length2 < currPos.right.length) {
                getItemCleanStart(transaction, createID(currPos.right.id.client, currPos.right.id.clock + length2));
              }
              length2 -= currPos.right.length;
              currPos.right.delete(transaction);
              break;
          }
        }
        currPos.forward();
      }
      if (start) {
        cleanupFormattingGap(transaction, start, currPos.right, startAttrs, currPos.currentAttributes);
      }
      const parent = (
        /** @type {AbstractType<any>} */
        /** @type {Item} */
        (currPos.left || currPos.right).parent
      );
      if (parent._searchMarker) {
        updateMarkerChanges(parent._searchMarker, currPos.index, -startLength + length2);
      }
      return currPos;
    };
    YTextEvent = class extends YEvent {
      /**
       * @param {YText} ytext
       * @param {Transaction} transaction
       * @param {Set<any>} subs The keys that changed
       */
      constructor(ytext, transaction, subs) {
        super(ytext, transaction);
        this.childListChanged = false;
        this.keysChanged = /* @__PURE__ */ new Set();
        subs.forEach((sub) => {
          if (sub === null) {
            this.childListChanged = true;
          } else {
            this.keysChanged.add(sub);
          }
        });
      }
      /**
       * @type {{added:Set<Item>,deleted:Set<Item>,keys:Map<string,{action:'add'|'update'|'delete',oldValue:any}>,delta:Array<{insert?:Array<any>|string, delete?:number, retain?:number}>}}
       */
      get changes() {
        if (this._changes === null) {
          const changes = {
            keys: this.keys,
            delta: this.delta,
            added: /* @__PURE__ */ new Set(),
            deleted: /* @__PURE__ */ new Set()
          };
          this._changes = changes;
        }
        return (
          /** @type {any} */
          this._changes
        );
      }
      /**
       * Compute the changes in the delta format.
       * A {@link https://quilljs.com/docs/delta/|Quill Delta}) that represents the changes on the document.
       *
       * @type {Array<{insert?:string|object|AbstractType<any>, delete?:number, retain?:number, attributes?: Object<string,any>}>}
       *
       * @public
       */
      get delta() {
        if (this._delta === null) {
          const y = (
            /** @type {Doc} */
            this.target.doc
          );
          const delta = [];
          transact(y, (transaction) => {
            const currentAttributes = /* @__PURE__ */ new Map();
            const oldAttributes = /* @__PURE__ */ new Map();
            let item = this.target._start;
            let action = null;
            const attributes = {};
            let insert = "";
            let retain = 0;
            let deleteLen = 0;
            const addOp = () => {
              if (action !== null) {
                let op = null;
                switch (action) {
                  case "delete":
                    if (deleteLen > 0) {
                      op = { delete: deleteLen };
                    }
                    deleteLen = 0;
                    break;
                  case "insert":
                    if (typeof insert === "object" || insert.length > 0) {
                      op = { insert };
                      if (currentAttributes.size > 0) {
                        op.attributes = {};
                        currentAttributes.forEach((value, key) => {
                          if (value !== null) {
                            op.attributes[key] = value;
                          }
                        });
                      }
                    }
                    insert = "";
                    break;
                  case "retain":
                    if (retain > 0) {
                      op = { retain };
                      if (!isEmpty(attributes)) {
                        op.attributes = assign({}, attributes);
                      }
                    }
                    retain = 0;
                    break;
                }
                if (op)
                  delta.push(op);
                action = null;
              }
            };
            while (item !== null) {
              switch (item.content.constructor) {
                case ContentType:
                case ContentEmbed:
                  if (this.adds(item)) {
                    if (!this.deletes(item)) {
                      addOp();
                      action = "insert";
                      insert = item.content.getContent()[0];
                      addOp();
                    }
                  } else if (this.deletes(item)) {
                    if (action !== "delete") {
                      addOp();
                      action = "delete";
                    }
                    deleteLen += 1;
                  } else if (!item.deleted) {
                    if (action !== "retain") {
                      addOp();
                      action = "retain";
                    }
                    retain += 1;
                  }
                  break;
                case ContentString:
                  if (this.adds(item)) {
                    if (!this.deletes(item)) {
                      if (action !== "insert") {
                        addOp();
                        action = "insert";
                      }
                      insert += /** @type {ContentString} */
                      item.content.str;
                    }
                  } else if (this.deletes(item)) {
                    if (action !== "delete") {
                      addOp();
                      action = "delete";
                    }
                    deleteLen += item.length;
                  } else if (!item.deleted) {
                    if (action !== "retain") {
                      addOp();
                      action = "retain";
                    }
                    retain += item.length;
                  }
                  break;
                case ContentFormat: {
                  const { key, value } = (
                    /** @type {ContentFormat} */
                    item.content
                  );
                  if (this.adds(item)) {
                    if (!this.deletes(item)) {
                      const curVal = currentAttributes.get(key) ?? null;
                      if (!equalAttrs(curVal, value)) {
                        if (action === "retain") {
                          addOp();
                        }
                        if (equalAttrs(value, oldAttributes.get(key) ?? null)) {
                          delete attributes[key];
                        } else {
                          attributes[key] = value;
                        }
                      } else if (value !== null) {
                        item.delete(transaction);
                      }
                    }
                  } else if (this.deletes(item)) {
                    oldAttributes.set(key, value);
                    const curVal = currentAttributes.get(key) ?? null;
                    if (!equalAttrs(curVal, value)) {
                      if (action === "retain") {
                        addOp();
                      }
                      attributes[key] = curVal;
                    }
                  } else if (!item.deleted) {
                    oldAttributes.set(key, value);
                    const attr = attributes[key];
                    if (attr !== void 0) {
                      if (!equalAttrs(attr, value)) {
                        if (action === "retain") {
                          addOp();
                        }
                        if (value === null) {
                          delete attributes[key];
                        } else {
                          attributes[key] = value;
                        }
                      } else if (attr !== null) {
                        item.delete(transaction);
                      }
                    }
                  }
                  if (!item.deleted) {
                    if (action === "insert") {
                      addOp();
                    }
                    updateCurrentAttributes(
                      currentAttributes,
                      /** @type {ContentFormat} */
                      item.content
                    );
                  }
                  break;
                }
              }
              item = item.right;
            }
            addOp();
            while (delta.length > 0) {
              const lastOp = delta[delta.length - 1];
              if (lastOp.retain !== void 0 && lastOp.attributes === void 0) {
                delta.pop();
              } else {
                break;
              }
            }
          });
          this._delta = delta;
        }
        return (
          /** @type {any} */
          this._delta
        );
      }
    };
    YText = class _YText extends AbstractType {
      /**
       * @param {String} [string] The initial value of the YText.
       */
      constructor(string) {
        super();
        this._pending = string !== void 0 ? [() => this.insert(0, string)] : [];
        this._searchMarker = [];
        this._hasFormatting = false;
      }
      /**
       * Number of characters of this text type.
       *
       * @type {number}
       */
      get length() {
        this.doc ?? warnPrematureAccess();
        return this._length;
      }
      /**
       * @param {Doc} y
       * @param {Item} item
       */
      _integrate(y, item) {
        super._integrate(y, item);
        try {
          this._pending.forEach((f) => f());
        } catch (e) {
          console.error(e);
        }
        this._pending = null;
      }
      _copy() {
        return new _YText();
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YText}
       */
      clone() {
        const text = new _YText();
        text.applyDelta(this.toDelta());
        return text;
      }
      /**
       * Creates YTextEvent and calls observers.
       *
       * @param {Transaction} transaction
       * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
       */
      _callObserver(transaction, parentSubs) {
        super._callObserver(transaction, parentSubs);
        const event = new YTextEvent(this, transaction, parentSubs);
        callTypeObservers(this, transaction, event);
        if (!transaction.local && this._hasFormatting) {
          transaction._needFormattingCleanup = true;
        }
      }
      /**
       * Returns the unformatted string representation of this YText type.
       *
       * @public
       */
      toString() {
        this.doc ?? warnPrematureAccess();
        let str = "";
        let n = this._start;
        while (n !== null) {
          if (!n.deleted && n.countable && n.content.constructor === ContentString) {
            str += /** @type {ContentString} */
            n.content.str;
          }
          n = n.right;
        }
        return str;
      }
      /**
       * Returns the unformatted string representation of this YText type.
       *
       * @return {string}
       * @public
       */
      toJSON() {
        return this.toString();
      }
      /**
       * Apply a {@link Delta} on this shared YText type.
       *
       * @param {Array<any>} delta The changes to apply on this element.
       * @param {object}  opts
       * @param {boolean} [opts.sanitize] Sanitize input delta. Removes ending newlines if set to true.
       *
       *
       * @public
       */
      applyDelta(delta, { sanitize = true } = {}) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            const currPos = new ItemTextListPosition(null, this._start, 0, /* @__PURE__ */ new Map());
            for (let i = 0; i < delta.length; i++) {
              const op = delta[i];
              if (op.insert !== void 0) {
                const ins = !sanitize && typeof op.insert === "string" && i === delta.length - 1 && currPos.right === null && op.insert.slice(-1) === "\n" ? op.insert.slice(0, -1) : op.insert;
                if (typeof ins !== "string" || ins.length > 0) {
                  insertText(transaction, this, currPos, ins, op.attributes || {});
                }
              } else if (op.retain !== void 0) {
                formatText(transaction, this, currPos, op.retain, op.attributes || {});
              } else if (op.delete !== void 0) {
                deleteText(transaction, currPos, op.delete);
              }
            }
          });
        } else {
          this._pending.push(() => this.applyDelta(delta));
        }
      }
      /**
       * Returns the Delta representation of this YText type.
       *
       * @param {Snapshot} [snapshot]
       * @param {Snapshot} [prevSnapshot]
       * @param {function('removed' | 'added', ID):any} [computeYChange]
       * @return {any} The Delta representation of this type.
       *
       * @public
       */
      toDelta(snapshot2, prevSnapshot, computeYChange) {
        this.doc ?? warnPrematureAccess();
        const ops = [];
        const currentAttributes = /* @__PURE__ */ new Map();
        const doc = (
          /** @type {Doc} */
          this.doc
        );
        let str = "";
        let n = this._start;
        function packStr() {
          if (str.length > 0) {
            const attributes = {};
            let addAttributes = false;
            currentAttributes.forEach((value, key) => {
              addAttributes = true;
              attributes[key] = value;
            });
            const op = { insert: str };
            if (addAttributes) {
              op.attributes = attributes;
            }
            ops.push(op);
            str = "";
          }
        }
        const computeDelta = () => {
          while (n !== null) {
            if (isVisible(n, snapshot2) || prevSnapshot !== void 0 && isVisible(n, prevSnapshot)) {
              switch (n.content.constructor) {
                case ContentString: {
                  const cur = currentAttributes.get("ychange");
                  if (snapshot2 !== void 0 && !isVisible(n, snapshot2)) {
                    if (cur === void 0 || cur.user !== n.id.client || cur.type !== "removed") {
                      packStr();
                      currentAttributes.set("ychange", computeYChange ? computeYChange("removed", n.id) : { type: "removed" });
                    }
                  } else if (prevSnapshot !== void 0 && !isVisible(n, prevSnapshot)) {
                    if (cur === void 0 || cur.user !== n.id.client || cur.type !== "added") {
                      packStr();
                      currentAttributes.set("ychange", computeYChange ? computeYChange("added", n.id) : { type: "added" });
                    }
                  } else if (cur !== void 0) {
                    packStr();
                    currentAttributes.delete("ychange");
                  }
                  str += /** @type {ContentString} */
                  n.content.str;
                  break;
                }
                case ContentType:
                case ContentEmbed: {
                  packStr();
                  const op = {
                    insert: n.content.getContent()[0]
                  };
                  if (currentAttributes.size > 0) {
                    const attrs = (
                      /** @type {Object<string,any>} */
                      {}
                    );
                    op.attributes = attrs;
                    currentAttributes.forEach((value, key) => {
                      attrs[key] = value;
                    });
                  }
                  ops.push(op);
                  break;
                }
                case ContentFormat:
                  if (isVisible(n, snapshot2)) {
                    packStr();
                    updateCurrentAttributes(
                      currentAttributes,
                      /** @type {ContentFormat} */
                      n.content
                    );
                  }
                  break;
              }
            }
            n = n.right;
          }
          packStr();
        };
        if (snapshot2 || prevSnapshot) {
          transact(doc, (transaction) => {
            if (snapshot2) {
              splitSnapshotAffectedStructs(transaction, snapshot2);
            }
            if (prevSnapshot) {
              splitSnapshotAffectedStructs(transaction, prevSnapshot);
            }
            computeDelta();
          }, "cleanup");
        } else {
          computeDelta();
        }
        return ops;
      }
      /**
       * Insert text at a given index.
       *
       * @param {number} index The index at which to start inserting.
       * @param {String} text The text to insert at the specified position.
       * @param {TextAttributes} [attributes] Optionally define some formatting
       *                                    information to apply on the inserted
       *                                    Text.
       * @public
       */
      insert(index, text, attributes) {
        if (text.length <= 0) {
          return;
        }
        const y = this.doc;
        if (y !== null) {
          transact(y, (transaction) => {
            const pos = findPosition(transaction, this, index, !attributes);
            if (!attributes) {
              attributes = {};
              pos.currentAttributes.forEach((v, k) => {
                attributes[k] = v;
              });
            }
            insertText(transaction, this, pos, text, attributes);
          });
        } else {
          this._pending.push(() => this.insert(index, text, attributes));
        }
      }
      /**
       * Inserts an embed at a index.
       *
       * @param {number} index The index to insert the embed at.
       * @param {Object | AbstractType<any>} embed The Object that represents the embed.
       * @param {TextAttributes} [attributes] Attribute information to apply on the
       *                                    embed
       *
       * @public
       */
      insertEmbed(index, embed, attributes) {
        const y = this.doc;
        if (y !== null) {
          transact(y, (transaction) => {
            const pos = findPosition(transaction, this, index, !attributes);
            insertText(transaction, this, pos, embed, attributes || {});
          });
        } else {
          this._pending.push(() => this.insertEmbed(index, embed, attributes || {}));
        }
      }
      /**
       * Deletes text starting from an index.
       *
       * @param {number} index Index at which to start deleting.
       * @param {number} length The number of characters to remove. Defaults to 1.
       *
       * @public
       */
      delete(index, length2) {
        if (length2 === 0) {
          return;
        }
        const y = this.doc;
        if (y !== null) {
          transact(y, (transaction) => {
            deleteText(transaction, findPosition(transaction, this, index, true), length2);
          });
        } else {
          this._pending.push(() => this.delete(index, length2));
        }
      }
      /**
       * Assigns properties to a range of text.
       *
       * @param {number} index The position where to start formatting.
       * @param {number} length The amount of characters to assign properties to.
       * @param {TextAttributes} attributes Attribute information to apply on the
       *                                    text.
       *
       * @public
       */
      format(index, length2, attributes) {
        if (length2 === 0) {
          return;
        }
        const y = this.doc;
        if (y !== null) {
          transact(y, (transaction) => {
            const pos = findPosition(transaction, this, index, false);
            if (pos.right === null) {
              return;
            }
            formatText(transaction, this, pos, length2, attributes);
          });
        } else {
          this._pending.push(() => this.format(index, length2, attributes));
        }
      }
      /**
       * Removes an attribute.
       *
       * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
       *
       * @param {String} attributeName The attribute name that is to be removed.
       *
       * @public
       */
      removeAttribute(attributeName) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeMapDelete(transaction, this, attributeName);
          });
        } else {
          this._pending.push(() => this.removeAttribute(attributeName));
        }
      }
      /**
       * Sets or updates an attribute.
       *
       * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
       *
       * @param {String} attributeName The attribute name that is to be set.
       * @param {any} attributeValue The attribute value that is to be set.
       *
       * @public
       */
      setAttribute(attributeName, attributeValue) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeMapSet(transaction, this, attributeName, attributeValue);
          });
        } else {
          this._pending.push(() => this.setAttribute(attributeName, attributeValue));
        }
      }
      /**
       * Returns an attribute value that belongs to the attribute name.
       *
       * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
       *
       * @param {String} attributeName The attribute name that identifies the
       *                               queried value.
       * @return {any} The queried attribute value.
       *
       * @public
       */
      getAttribute(attributeName) {
        return (
          /** @type {any} */
          typeMapGet(this, attributeName)
        );
      }
      /**
       * Returns all attribute name/value pairs in a JSON Object.
       *
       * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
       *
       * @return {Object<string, any>} A JSON Object that describes the attributes.
       *
       * @public
       */
      getAttributes() {
        return typeMapGetAll(this);
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       */
      _write(encoder) {
        encoder.writeTypeRef(YTextRefID);
      }
    };
    readYText = (_decoder) => new YText();
    YXmlTreeWalker = class {
      /**
       * @param {YXmlFragment | YXmlElement} root
       * @param {function(AbstractType<any>):boolean} [f]
       */
      constructor(root, f = () => true) {
        this._filter = f;
        this._root = root;
        this._currentNode = /** @type {Item} */
        root._start;
        this._firstCall = true;
        root.doc ?? warnPrematureAccess();
      }
      [Symbol.iterator]() {
        return this;
      }
      /**
       * Get the next node.
       *
       * @return {IteratorResult<YXmlElement|YXmlText|YXmlHook>} The next node.
       *
       * @public
       */
      next() {
        let n = this._currentNode;
        let type = n && n.content && /** @type {any} */
        n.content.type;
        if (n !== null && (!this._firstCall || n.deleted || !this._filter(type))) {
          do {
            type = /** @type {any} */
            n.content.type;
            if (!n.deleted && (type.constructor === YXmlElement || type.constructor === YXmlFragment) && type._start !== null) {
              n = type._start;
            } else {
              while (n !== null) {
                const nxt = n.next;
                if (nxt !== null) {
                  n = nxt;
                  break;
                } else if (n.parent === this._root) {
                  n = null;
                } else {
                  n = /** @type {AbstractType<any>} */
                  n.parent._item;
                }
              }
            }
          } while (n !== null && (n.deleted || !this._filter(
            /** @type {ContentType} */
            n.content.type
          )));
        }
        this._firstCall = false;
        if (n === null) {
          return { value: void 0, done: true };
        }
        this._currentNode = n;
        return { value: (
          /** @type {any} */
          n.content.type
        ), done: false };
      }
    };
    YXmlFragment = class _YXmlFragment extends AbstractType {
      constructor() {
        super();
        this._prelimContent = [];
      }
      /**
       * @type {YXmlElement|YXmlText|null}
       */
      get firstChild() {
        const first = this._first;
        return first ? first.content.getContent()[0] : null;
      }
      /**
       * Integrate this type into the Yjs instance.
       *
       * * Save this struct in the os
       * * This type is sent to other client
       * * Observer functions are fired
       *
       * @param {Doc} y The Yjs instance
       * @param {Item} item
       */
      _integrate(y, item) {
        super._integrate(y, item);
        this.insert(
          0,
          /** @type {Array<any>} */
          this._prelimContent
        );
        this._prelimContent = null;
      }
      _copy() {
        return new _YXmlFragment();
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YXmlFragment}
       */
      clone() {
        const el = new _YXmlFragment();
        el.insert(0, this.toArray().map((item) => item instanceof AbstractType ? item.clone() : item));
        return el;
      }
      get length() {
        this.doc ?? warnPrematureAccess();
        return this._prelimContent === null ? this._length : this._prelimContent.length;
      }
      /**
       * Create a subtree of childNodes.
       *
       * @example
       * const walker = elem.createTreeWalker(dom => dom.nodeName === 'div')
       * for (let node in walker) {
       *   // `node` is a div node
       *   nop(node)
       * }
       *
       * @param {function(AbstractType<any>):boolean} filter Function that is called on each child element and
       *                          returns a Boolean indicating whether the child
       *                          is to be included in the subtree.
       * @return {YXmlTreeWalker} A subtree and a position within it.
       *
       * @public
       */
      createTreeWalker(filter) {
        return new YXmlTreeWalker(this, filter);
      }
      /**
       * Returns the first YXmlElement that matches the query.
       * Similar to DOM's {@link querySelector}.
       *
       * Query support:
       *   - tagname
       * TODO:
       *   - id
       *   - attribute
       *
       * @param {CSS_Selector} query The query on the children.
       * @return {YXmlElement|YXmlText|YXmlHook|null} The first element that matches the query or null.
       *
       * @public
       */
      querySelector(query) {
        query = query.toUpperCase();
        const iterator = new YXmlTreeWalker(this, (element) => element.nodeName && element.nodeName.toUpperCase() === query);
        const next = iterator.next();
        if (next.done) {
          return null;
        } else {
          return next.value;
        }
      }
      /**
       * Returns all YXmlElements that match the query.
       * Similar to Dom's {@link querySelectorAll}.
       *
       * @todo Does not yet support all queries. Currently only query by tagName.
       *
       * @param {CSS_Selector} query The query on the children
       * @return {Array<YXmlElement|YXmlText|YXmlHook|null>} The elements that match this query.
       *
       * @public
       */
      querySelectorAll(query) {
        query = query.toUpperCase();
        return from(new YXmlTreeWalker(this, (element) => element.nodeName && element.nodeName.toUpperCase() === query));
      }
      /**
       * Creates YXmlEvent and calls observers.
       *
       * @param {Transaction} transaction
       * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
       */
      _callObserver(transaction, parentSubs) {
        callTypeObservers(this, transaction, new YXmlEvent(this, parentSubs, transaction));
      }
      /**
       * Get the string representation of all the children of this YXmlFragment.
       *
       * @return {string} The string representation of all children.
       */
      toString() {
        return typeListMap(this, (xml) => xml.toString()).join("");
      }
      /**
       * @return {string}
       */
      toJSON() {
        return this.toString();
      }
      /**
       * Creates a Dom Element that mirrors this YXmlElement.
       *
       * @param {Document} [_document=document] The document object (you must define
       *                                        this when calling this method in
       *                                        nodejs)
       * @param {Object<string, any>} [hooks={}] Optional property to customize how hooks
       *                                             are presented in the DOM
       * @param {any} [binding] You should not set this property. This is
       *                               used if DomBinding wants to create a
       *                               association to the created DOM type.
       * @return {Node} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
       *
       * @public
       */
      toDOM(_document = document, hooks = {}, binding) {
        const fragment = _document.createDocumentFragment();
        if (binding !== void 0) {
          binding._createAssociation(fragment, this);
        }
        typeListForEach(this, (xmlType) => {
          fragment.insertBefore(xmlType.toDOM(_document, hooks, binding), null);
        });
        return fragment;
      }
      /**
       * Inserts new content at an index.
       *
       * @example
       *  // Insert character 'a' at position 0
       *  xml.insert(0, [new Y.XmlText('text')])
       *
       * @param {number} index The index to insert content at
       * @param {Array<YXmlElement|YXmlText>} content The array of content
       */
      insert(index, content) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeListInsertGenerics(transaction, this, index, content);
          });
        } else {
          this._prelimContent.splice(index, 0, ...content);
        }
      }
      /**
       * Inserts new content at an index.
       *
       * @example
       *  // Insert character 'a' at position 0
       *  xml.insert(0, [new Y.XmlText('text')])
       *
       * @param {null|Item|YXmlElement|YXmlText} ref The index to insert content at
       * @param {Array<YXmlElement|YXmlText>} content The array of content
       */
      insertAfter(ref, content) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            const refItem = ref && ref instanceof AbstractType ? ref._item : ref;
            typeListInsertGenericsAfter(transaction, this, refItem, content);
          });
        } else {
          const pc = (
            /** @type {Array<any>} */
            this._prelimContent
          );
          const index = ref === null ? 0 : pc.findIndex((el) => el === ref) + 1;
          if (index === 0 && ref !== null) {
            throw create3("Reference item not found");
          }
          pc.splice(index, 0, ...content);
        }
      }
      /**
       * Deletes elements starting from an index.
       *
       * @param {number} index Index at which to start deleting elements
       * @param {number} [length=1] The number of elements to remove. Defaults to 1.
       */
      delete(index, length2 = 1) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeListDelete(transaction, this, index, length2);
          });
        } else {
          this._prelimContent.splice(index, length2);
        }
      }
      /**
       * Transforms this YArray to a JavaScript Array.
       *
       * @return {Array<YXmlElement|YXmlText|YXmlHook>}
       */
      toArray() {
        return typeListToArray(this);
      }
      /**
       * Appends content to this YArray.
       *
       * @param {Array<YXmlElement|YXmlText>} content Array of content to append.
       */
      push(content) {
        this.insert(this.length, content);
      }
      /**
       * Prepends content to this YArray.
       *
       * @param {Array<YXmlElement|YXmlText>} content Array of content to prepend.
       */
      unshift(content) {
        this.insert(0, content);
      }
      /**
       * Returns the i-th element from a YArray.
       *
       * @param {number} index The index of the element to return from the YArray
       * @return {YXmlElement|YXmlText}
       */
      get(index) {
        return typeListGet(this, index);
      }
      /**
       * Returns a portion of this YXmlFragment into a JavaScript Array selected
       * from start to end (end not included).
       *
       * @param {number} [start]
       * @param {number} [end]
       * @return {Array<YXmlElement|YXmlText>}
       */
      slice(start = 0, end = this.length) {
        return typeListSlice(this, start, end);
      }
      /**
       * Executes a provided function on once on every child element.
       *
       * @param {function(YXmlElement|YXmlText,number, typeof self):void} f A function to execute on every element of this YArray.
       */
      forEach(f) {
        typeListForEach(this, f);
      }
      /**
       * Transform the properties of this type to binary and write it to an
       * BinaryEncoder.
       *
       * This is called when this Item is sent to a remote peer.
       *
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
       */
      _write(encoder) {
        encoder.writeTypeRef(YXmlFragmentRefID);
      }
    };
    readYXmlFragment = (_decoder) => new YXmlFragment();
    YXmlElement = class _YXmlElement extends YXmlFragment {
      constructor(nodeName = "UNDEFINED") {
        super();
        this.nodeName = nodeName;
        this._prelimAttrs = /* @__PURE__ */ new Map();
      }
      /**
       * @type {YXmlElement|YXmlText|null}
       */
      get nextSibling() {
        const n = this._item ? this._item.next : null;
        return n ? (
          /** @type {YXmlElement|YXmlText} */
          /** @type {ContentType} */
          n.content.type
        ) : null;
      }
      /**
       * @type {YXmlElement|YXmlText|null}
       */
      get prevSibling() {
        const n = this._item ? this._item.prev : null;
        return n ? (
          /** @type {YXmlElement|YXmlText} */
          /** @type {ContentType} */
          n.content.type
        ) : null;
      }
      /**
       * Integrate this type into the Yjs instance.
       *
       * * Save this struct in the os
       * * This type is sent to other client
       * * Observer functions are fired
       *
       * @param {Doc} y The Yjs instance
       * @param {Item} item
       */
      _integrate(y, item) {
        super._integrate(y, item);
        /** @type {Map<string, any>} */
        this._prelimAttrs.forEach((value, key) => {
          this.setAttribute(key, value);
        });
        this._prelimAttrs = null;
      }
      /**
       * Creates an Item with the same effect as this Item (without position effect)
       *
       * @return {YXmlElement}
       */
      _copy() {
        return new _YXmlElement(this.nodeName);
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YXmlElement<KV>}
       */
      clone() {
        const el = new _YXmlElement(this.nodeName);
        const attrs = this.getAttributes();
        forEach(attrs, (value, key) => {
          el.setAttribute(
            key,
            /** @type {any} */
            value
          );
        });
        el.insert(0, this.toArray().map((v) => v instanceof AbstractType ? v.clone() : v));
        return el;
      }
      /**
       * Returns the XML serialization of this YXmlElement.
       * The attributes are ordered by attribute-name, so you can easily use this
       * method to compare YXmlElements
       *
       * @return {string} The string representation of this type.
       *
       * @public
       */
      toString() {
        const attrs = this.getAttributes();
        const stringBuilder = [];
        const keys2 = [];
        for (const key in attrs) {
          keys2.push(key);
        }
        keys2.sort();
        const keysLen = keys2.length;
        for (let i = 0; i < keysLen; i++) {
          const key = keys2[i];
          stringBuilder.push(key + '="' + attrs[key] + '"');
        }
        const nodeName = this.nodeName.toLocaleLowerCase();
        const attrsString = stringBuilder.length > 0 ? " " + stringBuilder.join(" ") : "";
        return `<${nodeName}${attrsString}>${super.toString()}</${nodeName}>`;
      }
      /**
       * Removes an attribute from this YXmlElement.
       *
       * @param {string} attributeName The attribute name that is to be removed.
       *
       * @public
       */
      removeAttribute(attributeName) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeMapDelete(transaction, this, attributeName);
          });
        } else {
          this._prelimAttrs.delete(attributeName);
        }
      }
      /**
       * Sets or updates an attribute.
       *
       * @template {keyof KV & string} KEY
       *
       * @param {KEY} attributeName The attribute name that is to be set.
       * @param {KV[KEY]} attributeValue The attribute value that is to be set.
       *
       * @public
       */
      setAttribute(attributeName, attributeValue) {
        if (this.doc !== null) {
          transact(this.doc, (transaction) => {
            typeMapSet(transaction, this, attributeName, attributeValue);
          });
        } else {
          this._prelimAttrs.set(attributeName, attributeValue);
        }
      }
      /**
       * Returns an attribute value that belongs to the attribute name.
       *
       * @template {keyof KV & string} KEY
       *
       * @param {KEY} attributeName The attribute name that identifies the
       *                               queried value.
       * @return {KV[KEY]|undefined} The queried attribute value.
       *
       * @public
       */
      getAttribute(attributeName) {
        return (
          /** @type {any} */
          typeMapGet(this, attributeName)
        );
      }
      /**
       * Returns whether an attribute exists
       *
       * @param {string} attributeName The attribute name to check for existence.
       * @return {boolean} whether the attribute exists.
       *
       * @public
       */
      hasAttribute(attributeName) {
        return (
          /** @type {any} */
          typeMapHas(this, attributeName)
        );
      }
      /**
       * Returns all attribute name/value pairs in a JSON Object.
       *
       * @param {Snapshot} [snapshot]
       * @return {{ [Key in Extract<keyof KV,string>]?: KV[Key]}} A JSON Object that describes the attributes.
       *
       * @public
       */
      getAttributes(snapshot2) {
        return (
          /** @type {any} */
          snapshot2 ? typeMapGetAllSnapshot(this, snapshot2) : typeMapGetAll(this)
        );
      }
      /**
       * Creates a Dom Element that mirrors this YXmlElement.
       *
       * @param {Document} [_document=document] The document object (you must define
       *                                        this when calling this method in
       *                                        nodejs)
       * @param {Object<string, any>} [hooks={}] Optional property to customize how hooks
       *                                             are presented in the DOM
       * @param {any} [binding] You should not set this property. This is
       *                               used if DomBinding wants to create a
       *                               association to the created DOM type.
       * @return {Node} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
       *
       * @public
       */
      toDOM(_document = document, hooks = {}, binding) {
        const dom = _document.createElement(this.nodeName);
        const attrs = this.getAttributes();
        for (const key in attrs) {
          const value = attrs[key];
          if (typeof value === "string") {
            dom.setAttribute(key, value);
          }
        }
        typeListForEach(this, (yxml) => {
          dom.appendChild(yxml.toDOM(_document, hooks, binding));
        });
        if (binding !== void 0) {
          binding._createAssociation(dom, this);
        }
        return dom;
      }
      /**
       * Transform the properties of this type to binary and write it to an
       * BinaryEncoder.
       *
       * This is called when this Item is sent to a remote peer.
       *
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
       */
      _write(encoder) {
        encoder.writeTypeRef(YXmlElementRefID);
        encoder.writeKey(this.nodeName);
      }
    };
    readYXmlElement = (decoder) => new YXmlElement(decoder.readKey());
    YXmlEvent = class extends YEvent {
      /**
       * @param {YXmlElement|YXmlText|YXmlFragment} target The target on which the event is created.
       * @param {Set<string|null>} subs The set of changed attributes. `null` is included if the
       *                   child list changed.
       * @param {Transaction} transaction The transaction instance with which the
       *                                  change was created.
       */
      constructor(target, subs, transaction) {
        super(target, transaction);
        this.childListChanged = false;
        this.attributesChanged = /* @__PURE__ */ new Set();
        subs.forEach((sub) => {
          if (sub === null) {
            this.childListChanged = true;
          } else {
            this.attributesChanged.add(sub);
          }
        });
      }
    };
    YXmlHook = class _YXmlHook extends YMap {
      /**
       * @param {string} hookName nodeName of the Dom Node.
       */
      constructor(hookName) {
        super();
        this.hookName = hookName;
      }
      /**
       * Creates an Item with the same effect as this Item (without position effect)
       */
      _copy() {
        return new _YXmlHook(this.hookName);
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YXmlHook}
       */
      clone() {
        const el = new _YXmlHook(this.hookName);
        this.forEach((value, key) => {
          el.set(key, value);
        });
        return el;
      }
      /**
       * Creates a Dom Element that mirrors this YXmlElement.
       *
       * @param {Document} [_document=document] The document object (you must define
       *                                        this when calling this method in
       *                                        nodejs)
       * @param {Object.<string, any>} [hooks] Optional property to customize how hooks
       *                                             are presented in the DOM
       * @param {any} [binding] You should not set this property. This is
       *                               used if DomBinding wants to create a
       *                               association to the created DOM type
       * @return {Element} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
       *
       * @public
       */
      toDOM(_document = document, hooks = {}, binding) {
        const hook = hooks[this.hookName];
        let dom;
        if (hook !== void 0) {
          dom = hook.createDom(this);
        } else {
          dom = document.createElement(this.hookName);
        }
        dom.setAttribute("data-yjs-hook", this.hookName);
        if (binding !== void 0) {
          binding._createAssociation(dom, this);
        }
        return dom;
      }
      /**
       * Transform the properties of this type to binary and write it to an
       * BinaryEncoder.
       *
       * This is called when this Item is sent to a remote peer.
       *
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
       */
      _write(encoder) {
        encoder.writeTypeRef(YXmlHookRefID);
        encoder.writeKey(this.hookName);
      }
    };
    readYXmlHook = (decoder) => new YXmlHook(decoder.readKey());
    YXmlText = class _YXmlText extends YText {
      /**
       * @type {YXmlElement|YXmlText|null}
       */
      get nextSibling() {
        const n = this._item ? this._item.next : null;
        return n ? (
          /** @type {YXmlElement|YXmlText} */
          /** @type {ContentType} */
          n.content.type
        ) : null;
      }
      /**
       * @type {YXmlElement|YXmlText|null}
       */
      get prevSibling() {
        const n = this._item ? this._item.prev : null;
        return n ? (
          /** @type {YXmlElement|YXmlText} */
          /** @type {ContentType} */
          n.content.type
        ) : null;
      }
      _copy() {
        return new _YXmlText();
      }
      /**
       * Makes a copy of this data type that can be included somewhere else.
       *
       * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
       *
       * @return {YXmlText}
       */
      clone() {
        const text = new _YXmlText();
        text.applyDelta(this.toDelta());
        return text;
      }
      /**
       * Creates a Dom Element that mirrors this YXmlText.
       *
       * @param {Document} [_document=document] The document object (you must define
       *                                        this when calling this method in
       *                                        nodejs)
       * @param {Object<string, any>} [hooks] Optional property to customize how hooks
       *                                             are presented in the DOM
       * @param {any} [binding] You should not set this property. This is
       *                               used if DomBinding wants to create a
       *                               association to the created DOM type.
       * @return {Text} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
       *
       * @public
       */
      toDOM(_document = document, hooks, binding) {
        const dom = _document.createTextNode(this.toString());
        if (binding !== void 0) {
          binding._createAssociation(dom, this);
        }
        return dom;
      }
      toString() {
        return this.toDelta().map((delta) => {
          const nestedNodes = [];
          for (const nodeName in delta.attributes) {
            const attrs = [];
            for (const key in delta.attributes[nodeName]) {
              attrs.push({ key, value: delta.attributes[nodeName][key] });
            }
            attrs.sort((a, b) => a.key < b.key ? -1 : 1);
            nestedNodes.push({ nodeName, attrs });
          }
          nestedNodes.sort((a, b) => a.nodeName < b.nodeName ? -1 : 1);
          let str = "";
          for (let i = 0; i < nestedNodes.length; i++) {
            const node = nestedNodes[i];
            str += `<${node.nodeName}`;
            for (let j = 0; j < node.attrs.length; j++) {
              const attr = node.attrs[j];
              str += ` ${attr.key}="${attr.value}"`;
            }
            str += ">";
          }
          str += delta.insert;
          for (let i = nestedNodes.length - 1; i >= 0; i--) {
            str += `</${nestedNodes[i].nodeName}>`;
          }
          return str;
        }).join("");
      }
      /**
       * @return {string}
       */
      toJSON() {
        return this.toString();
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       */
      _write(encoder) {
        encoder.writeTypeRef(YXmlTextRefID);
      }
    };
    readYXmlText = (decoder) => new YXmlText();
    AbstractStruct = class {
      /**
       * @param {ID} id
       * @param {number} length
       */
      constructor(id2, length2) {
        this.id = id2;
        this.length = length2;
      }
      /**
       * @type {boolean}
       */
      get deleted() {
        throw methodUnimplemented();
      }
      /**
       * Merge this struct with the item to the right.
       * This method is already assuming that `this.id.clock + this.length === this.id.clock`.
       * Also this method does *not* remove right from StructStore!
       * @param {AbstractStruct} right
       * @return {boolean} whether this merged with right
       */
      mergeWith(right) {
        return false;
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
       * @param {number} offset
       * @param {number} encodingRef
       */
      write(encoder, offset, encodingRef) {
        throw methodUnimplemented();
      }
      /**
       * @param {Transaction} transaction
       * @param {number} offset
       */
      integrate(transaction, offset) {
        throw methodUnimplemented();
      }
    };
    structGCRefNumber = 0;
    GC = class extends AbstractStruct {
      get deleted() {
        return true;
      }
      delete() {
      }
      /**
       * @param {GC} right
       * @return {boolean}
       */
      mergeWith(right) {
        if (this.constructor !== right.constructor) {
          return false;
        }
        this.length += right.length;
        return true;
      }
      /**
       * @param {Transaction} transaction
       * @param {number} offset
       */
      integrate(transaction, offset) {
        if (offset > 0) {
          this.id.clock += offset;
          this.length -= offset;
        }
        addStruct(transaction.doc.store, this);
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeInfo(structGCRefNumber);
        encoder.writeLen(this.length - offset);
      }
      /**
       * @param {Transaction} transaction
       * @param {StructStore} store
       * @return {null | number}
       */
      getMissing(transaction, store) {
        return null;
      }
    };
    ContentBinary = class _ContentBinary {
      /**
       * @param {Uint8Array} content
       */
      constructor(content) {
        this.content = content;
      }
      /**
       * @return {number}
       */
      getLength() {
        return 1;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return [this.content];
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentBinary}
       */
      copy() {
        return new _ContentBinary(this.content);
      }
      /**
       * @param {number} offset
       * @return {ContentBinary}
       */
      splice(offset) {
        throw methodUnimplemented();
      }
      /**
       * @param {ContentBinary} right
       * @return {boolean}
       */
      mergeWith(right) {
        return false;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeBuf(this.content);
      }
      /**
       * @return {number}
       */
      getRef() {
        return 3;
      }
    };
    readContentBinary = (decoder) => new ContentBinary(decoder.readBuf());
    ContentDeleted = class _ContentDeleted {
      /**
       * @param {number} len
       */
      constructor(len) {
        this.len = len;
      }
      /**
       * @return {number}
       */
      getLength() {
        return this.len;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return [];
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return false;
      }
      /**
       * @return {ContentDeleted}
       */
      copy() {
        return new _ContentDeleted(this.len);
      }
      /**
       * @param {number} offset
       * @return {ContentDeleted}
       */
      splice(offset) {
        const right = new _ContentDeleted(this.len - offset);
        this.len = offset;
        return right;
      }
      /**
       * @param {ContentDeleted} right
       * @return {boolean}
       */
      mergeWith(right) {
        this.len += right.len;
        return true;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
        addToDeleteSet(transaction.deleteSet, item.id.client, item.id.clock, this.len);
        item.markDeleted();
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeLen(this.len - offset);
      }
      /**
       * @return {number}
       */
      getRef() {
        return 1;
      }
    };
    readContentDeleted = (decoder) => new ContentDeleted(decoder.readLen());
    createDocFromOpts = (guid, opts) => new Doc({ guid, ...opts, shouldLoad: opts.shouldLoad || opts.autoLoad || false });
    ContentDoc = class _ContentDoc {
      /**
       * @param {Doc} doc
       */
      constructor(doc) {
        if (doc._item) {
          console.error("This document was already integrated as a sub-document. You should create a second instance instead with the same guid.");
        }
        this.doc = doc;
        const opts = {};
        this.opts = opts;
        if (!doc.gc) {
          opts.gc = false;
        }
        if (doc.autoLoad) {
          opts.autoLoad = true;
        }
        if (doc.meta !== null) {
          opts.meta = doc.meta;
        }
      }
      /**
       * @return {number}
       */
      getLength() {
        return 1;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return [this.doc];
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentDoc}
       */
      copy() {
        return new _ContentDoc(createDocFromOpts(this.doc.guid, this.opts));
      }
      /**
       * @param {number} offset
       * @return {ContentDoc}
       */
      splice(offset) {
        throw methodUnimplemented();
      }
      /**
       * @param {ContentDoc} right
       * @return {boolean}
       */
      mergeWith(right) {
        return false;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
        this.doc._item = item;
        transaction.subdocsAdded.add(this.doc);
        if (this.doc.shouldLoad) {
          transaction.subdocsLoaded.add(this.doc);
        }
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
        if (transaction.subdocsAdded.has(this.doc)) {
          transaction.subdocsAdded.delete(this.doc);
        } else {
          transaction.subdocsRemoved.add(this.doc);
        }
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeString(this.doc.guid);
        encoder.writeAny(this.opts);
      }
      /**
       * @return {number}
       */
      getRef() {
        return 9;
      }
    };
    readContentDoc = (decoder) => new ContentDoc(createDocFromOpts(decoder.readString(), decoder.readAny()));
    ContentEmbed = class _ContentEmbed {
      /**
       * @param {Object} embed
       */
      constructor(embed) {
        this.embed = embed;
      }
      /**
       * @return {number}
       */
      getLength() {
        return 1;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return [this.embed];
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentEmbed}
       */
      copy() {
        return new _ContentEmbed(this.embed);
      }
      /**
       * @param {number} offset
       * @return {ContentEmbed}
       */
      splice(offset) {
        throw methodUnimplemented();
      }
      /**
       * @param {ContentEmbed} right
       * @return {boolean}
       */
      mergeWith(right) {
        return false;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeJSON(this.embed);
      }
      /**
       * @return {number}
       */
      getRef() {
        return 5;
      }
    };
    readContentEmbed = (decoder) => new ContentEmbed(decoder.readJSON());
    ContentFormat = class _ContentFormat {
      /**
       * @param {string} key
       * @param {Object} value
       */
      constructor(key, value) {
        this.key = key;
        this.value = value;
      }
      /**
       * @return {number}
       */
      getLength() {
        return 1;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return [];
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return false;
      }
      /**
       * @return {ContentFormat}
       */
      copy() {
        return new _ContentFormat(this.key, this.value);
      }
      /**
       * @param {number} _offset
       * @return {ContentFormat}
       */
      splice(_offset) {
        throw methodUnimplemented();
      }
      /**
       * @param {ContentFormat} _right
       * @return {boolean}
       */
      mergeWith(_right) {
        return false;
      }
      /**
       * @param {Transaction} _transaction
       * @param {Item} item
       */
      integrate(_transaction, item) {
        const p = (
          /** @type {YText} */
          item.parent
        );
        p._searchMarker = null;
        p._hasFormatting = true;
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeKey(this.key);
        encoder.writeJSON(this.value);
      }
      /**
       * @return {number}
       */
      getRef() {
        return 6;
      }
    };
    readContentFormat = (decoder) => new ContentFormat(decoder.readKey(), decoder.readJSON());
    ContentJSON = class _ContentJSON {
      /**
       * @param {Array<any>} arr
       */
      constructor(arr) {
        this.arr = arr;
      }
      /**
       * @return {number}
       */
      getLength() {
        return this.arr.length;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return this.arr;
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentJSON}
       */
      copy() {
        return new _ContentJSON(this.arr);
      }
      /**
       * @param {number} offset
       * @return {ContentJSON}
       */
      splice(offset) {
        const right = new _ContentJSON(this.arr.slice(offset));
        this.arr = this.arr.slice(0, offset);
        return right;
      }
      /**
       * @param {ContentJSON} right
       * @return {boolean}
       */
      mergeWith(right) {
        this.arr = this.arr.concat(right.arr);
        return true;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        const len = this.arr.length;
        encoder.writeLen(len - offset);
        for (let i = offset; i < len; i++) {
          const c = this.arr[i];
          encoder.writeString(c === void 0 ? "undefined" : JSON.stringify(c));
        }
      }
      /**
       * @return {number}
       */
      getRef() {
        return 2;
      }
    };
    readContentJSON = (decoder) => {
      const len = decoder.readLen();
      const cs = [];
      for (let i = 0; i < len; i++) {
        const c = decoder.readString();
        if (c === "undefined") {
          cs.push(void 0);
        } else {
          cs.push(JSON.parse(c));
        }
      }
      return new ContentJSON(cs);
    };
    isDevMode = getVariable("node_env") === "development";
    ContentAny = class _ContentAny {
      /**
       * @param {Array<any>} arr
       */
      constructor(arr) {
        this.arr = arr;
        isDevMode && deepFreeze(arr);
      }
      /**
       * @return {number}
       */
      getLength() {
        return this.arr.length;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return this.arr;
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentAny}
       */
      copy() {
        return new _ContentAny(this.arr);
      }
      /**
       * @param {number} offset
       * @return {ContentAny}
       */
      splice(offset) {
        const right = new _ContentAny(this.arr.slice(offset));
        this.arr = this.arr.slice(0, offset);
        return right;
      }
      /**
       * @param {ContentAny} right
       * @return {boolean}
       */
      mergeWith(right) {
        this.arr = this.arr.concat(right.arr);
        return true;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        const len = this.arr.length;
        encoder.writeLen(len - offset);
        for (let i = offset; i < len; i++) {
          const c = this.arr[i];
          encoder.writeAny(c);
        }
      }
      /**
       * @return {number}
       */
      getRef() {
        return 8;
      }
    };
    readContentAny = (decoder) => {
      const len = decoder.readLen();
      const cs = [];
      for (let i = 0; i < len; i++) {
        cs.push(decoder.readAny());
      }
      return new ContentAny(cs);
    };
    ContentString = class _ContentString {
      /**
       * @param {string} str
       */
      constructor(str) {
        this.str = str;
      }
      /**
       * @return {number}
       */
      getLength() {
        return this.str.length;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return this.str.split("");
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentString}
       */
      copy() {
        return new _ContentString(this.str);
      }
      /**
       * @param {number} offset
       * @return {ContentString}
       */
      splice(offset) {
        const right = new _ContentString(this.str.slice(offset));
        this.str = this.str.slice(0, offset);
        const firstCharCode = this.str.charCodeAt(offset - 1);
        if (firstCharCode >= 55296 && firstCharCode <= 56319) {
          this.str = this.str.slice(0, offset - 1) + "\uFFFD";
          right.str = "\uFFFD" + right.str.slice(1);
        }
        return right;
      }
      /**
       * @param {ContentString} right
       * @return {boolean}
       */
      mergeWith(right) {
        this.str += right.str;
        return true;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeString(offset === 0 ? this.str : this.str.slice(offset));
      }
      /**
       * @return {number}
       */
      getRef() {
        return 4;
      }
    };
    readContentString = (decoder) => new ContentString(decoder.readString());
    typeRefs = [
      readYArray,
      readYMap,
      readYText,
      readYXmlElement,
      readYXmlFragment,
      readYXmlHook,
      readYXmlText
    ];
    YArrayRefID = 0;
    YMapRefID = 1;
    YTextRefID = 2;
    YXmlElementRefID = 3;
    YXmlFragmentRefID = 4;
    YXmlHookRefID = 5;
    YXmlTextRefID = 6;
    ContentType = class _ContentType {
      /**
       * @param {AbstractType<any>} type
       */
      constructor(type) {
        this.type = type;
      }
      /**
       * @return {number}
       */
      getLength() {
        return 1;
      }
      /**
       * @return {Array<any>}
       */
      getContent() {
        return [this.type];
      }
      /**
       * @return {boolean}
       */
      isCountable() {
        return true;
      }
      /**
       * @return {ContentType}
       */
      copy() {
        return new _ContentType(this.type._copy());
      }
      /**
       * @param {number} offset
       * @return {ContentType}
       */
      splice(offset) {
        throw methodUnimplemented();
      }
      /**
       * @param {ContentType} right
       * @return {boolean}
       */
      mergeWith(right) {
        return false;
      }
      /**
       * @param {Transaction} transaction
       * @param {Item} item
       */
      integrate(transaction, item) {
        this.type._integrate(transaction.doc, item);
      }
      /**
       * @param {Transaction} transaction
       */
      delete(transaction) {
        let item = this.type._start;
        while (item !== null) {
          if (!item.deleted) {
            item.delete(transaction);
          } else if (item.id.clock < (transaction.beforeState.get(item.id.client) || 0)) {
            transaction._mergeStructs.push(item);
          }
          item = item.right;
        }
        this.type._map.forEach((item2) => {
          if (!item2.deleted) {
            item2.delete(transaction);
          } else if (item2.id.clock < (transaction.beforeState.get(item2.id.client) || 0)) {
            transaction._mergeStructs.push(item2);
          }
        });
        transaction.changed.delete(this.type);
      }
      /**
       * @param {StructStore} store
       */
      gc(store) {
        let item = this.type._start;
        while (item !== null) {
          item.gc(store, true);
          item = item.right;
        }
        this.type._start = null;
        this.type._map.forEach(
          /** @param {Item | null} item */
          (item2) => {
            while (item2 !== null) {
              item2.gc(store, true);
              item2 = item2.left;
            }
          }
        );
        this.type._map = /* @__PURE__ */ new Map();
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        this.type._write(encoder);
      }
      /**
       * @return {number}
       */
      getRef() {
        return 7;
      }
    };
    readContentType = (decoder) => new ContentType(typeRefs[decoder.readTypeRef()](decoder));
    followRedone = (store, id2) => {
      let nextID = id2;
      let diff = 0;
      let item;
      do {
        if (diff > 0) {
          nextID = createID(nextID.client, nextID.clock + diff);
        }
        item = getItem(store, nextID);
        diff = nextID.clock - item.id.clock;
        nextID = item.redone;
      } while (nextID !== null && item instanceof Item);
      return {
        item,
        diff
      };
    };
    keepItem = (item, keep) => {
      while (item !== null && item.keep !== keep) {
        item.keep = keep;
        item = /** @type {AbstractType<any>} */
        item.parent._item;
      }
    };
    splitItem = (transaction, leftItem, diff) => {
      const { client, clock } = leftItem.id;
      const rightItem = new Item(
        createID(client, clock + diff),
        leftItem,
        createID(client, clock + diff - 1),
        leftItem.right,
        leftItem.rightOrigin,
        leftItem.parent,
        leftItem.parentSub,
        leftItem.content.splice(diff)
      );
      if (leftItem.deleted) {
        rightItem.markDeleted();
      }
      if (leftItem.keep) {
        rightItem.keep = true;
      }
      if (leftItem.redone !== null) {
        rightItem.redone = createID(leftItem.redone.client, leftItem.redone.clock + diff);
      }
      leftItem.right = rightItem;
      if (rightItem.right !== null) {
        rightItem.right.left = rightItem;
      }
      transaction._mergeStructs.push(rightItem);
      if (rightItem.parentSub !== null && rightItem.right === null) {
        rightItem.parent._map.set(rightItem.parentSub, rightItem);
      }
      leftItem.length = diff;
      return rightItem;
    };
    isDeletedByUndoStack = (stack, id2) => some(
      stack,
      /** @param {StackItem} s */
      (s) => isDeleted(s.deletions, id2)
    );
    redoItem = (transaction, item, redoitems, itemsToDelete, ignoreRemoteMapChanges, um) => {
      const doc = transaction.doc;
      const store = doc.store;
      const ownClientID = doc.clientID;
      const redone = item.redone;
      if (redone !== null) {
        return getItemCleanStart(transaction, redone);
      }
      let parentItem = (
        /** @type {AbstractType<any>} */
        item.parent._item
      );
      let left = null;
      let right;
      if (parentItem !== null && parentItem.deleted === true) {
        if (parentItem.redone === null && (!redoitems.has(parentItem) || redoItem(transaction, parentItem, redoitems, itemsToDelete, ignoreRemoteMapChanges, um) === null)) {
          return null;
        }
        while (parentItem.redone !== null) {
          parentItem = getItemCleanStart(transaction, parentItem.redone);
        }
      }
      const parentType = parentItem === null ? (
        /** @type {AbstractType<any>} */
        item.parent
      ) : (
        /** @type {ContentType} */
        parentItem.content.type
      );
      if (item.parentSub === null) {
        left = item.left;
        right = item;
        while (left !== null) {
          let leftTrace = left;
          while (leftTrace !== null && /** @type {AbstractType<any>} */
          leftTrace.parent._item !== parentItem) {
            leftTrace = leftTrace.redone === null ? null : getItemCleanStart(transaction, leftTrace.redone);
          }
          if (leftTrace !== null && /** @type {AbstractType<any>} */
          leftTrace.parent._item === parentItem) {
            left = leftTrace;
            break;
          }
          left = left.left;
        }
        while (right !== null) {
          let rightTrace = right;
          while (rightTrace !== null && /** @type {AbstractType<any>} */
          rightTrace.parent._item !== parentItem) {
            rightTrace = rightTrace.redone === null ? null : getItemCleanStart(transaction, rightTrace.redone);
          }
          if (rightTrace !== null && /** @type {AbstractType<any>} */
          rightTrace.parent._item === parentItem) {
            right = rightTrace;
            break;
          }
          right = right.right;
        }
      } else {
        right = null;
        if (item.right && !ignoreRemoteMapChanges) {
          left = item;
          while (left !== null && left.right !== null && (left.right.redone || isDeleted(itemsToDelete, left.right.id) || isDeletedByUndoStack(um.undoStack, left.right.id) || isDeletedByUndoStack(um.redoStack, left.right.id))) {
            left = left.right;
            while (left.redone)
              left = getItemCleanStart(transaction, left.redone);
          }
          if (left && left.right !== null) {
            return null;
          }
        } else {
          left = parentType._map.get(item.parentSub) || null;
        }
      }
      const nextClock = getState(store, ownClientID);
      const nextId = createID(ownClientID, nextClock);
      const redoneItem = new Item(
        nextId,
        left,
        left && left.lastId,
        right,
        right && right.id,
        parentType,
        item.parentSub,
        item.content.copy()
      );
      item.redone = nextId;
      keepItem(redoneItem, true);
      redoneItem.integrate(transaction, 0);
      return redoneItem;
    };
    Item = class _Item extends AbstractStruct {
      /**
       * @param {ID} id
       * @param {Item | null} left
       * @param {ID | null} origin
       * @param {Item | null} right
       * @param {ID | null} rightOrigin
       * @param {AbstractType<any>|ID|null} parent Is a type if integrated, is null if it is possible to copy parent from left or right, is ID before integration to search for it.
       * @param {string | null} parentSub
       * @param {AbstractContent} content
       */
      constructor(id2, left, origin, right, rightOrigin, parent, parentSub, content) {
        super(id2, content.getLength());
        this.origin = origin;
        this.left = left;
        this.right = right;
        this.rightOrigin = rightOrigin;
        this.parent = parent;
        this.parentSub = parentSub;
        this.redone = null;
        this.content = content;
        this.info = this.content.isCountable() ? BIT2 : 0;
      }
      /**
       * This is used to mark the item as an indexed fast-search marker
       *
       * @type {boolean}
       */
      set marker(isMarked) {
        if ((this.info & BIT4) > 0 !== isMarked) {
          this.info ^= BIT4;
        }
      }
      get marker() {
        return (this.info & BIT4) > 0;
      }
      /**
       * If true, do not garbage collect this Item.
       */
      get keep() {
        return (this.info & BIT1) > 0;
      }
      set keep(doKeep) {
        if (this.keep !== doKeep) {
          this.info ^= BIT1;
        }
      }
      get countable() {
        return (this.info & BIT2) > 0;
      }
      /**
       * Whether this item was deleted or not.
       * @type {Boolean}
       */
      get deleted() {
        return (this.info & BIT3) > 0;
      }
      set deleted(doDelete) {
        if (this.deleted !== doDelete) {
          this.info ^= BIT3;
        }
      }
      markDeleted() {
        this.info |= BIT3;
      }
      /**
       * Return the creator clientID of the missing op or define missing items and return null.
       *
       * @param {Transaction} transaction
       * @param {StructStore} store
       * @return {null | number}
       */
      getMissing(transaction, store) {
        if (this.origin && this.origin.client !== this.id.client && this.origin.clock >= getState(store, this.origin.client)) {
          return this.origin.client;
        }
        if (this.rightOrigin && this.rightOrigin.client !== this.id.client && this.rightOrigin.clock >= getState(store, this.rightOrigin.client)) {
          return this.rightOrigin.client;
        }
        if (this.parent && this.parent.constructor === ID && this.id.client !== this.parent.client && this.parent.clock >= getState(store, this.parent.client)) {
          return this.parent.client;
        }
        if (this.origin) {
          this.left = getItemCleanEnd(transaction, store, this.origin);
          this.origin = this.left.lastId;
        }
        if (this.rightOrigin) {
          this.right = getItemCleanStart(transaction, this.rightOrigin);
          this.rightOrigin = this.right.id;
        }
        if (this.left && this.left.constructor === GC || this.right && this.right.constructor === GC) {
          this.parent = null;
        } else if (!this.parent) {
          if (this.left && this.left.constructor === _Item) {
            this.parent = this.left.parent;
            this.parentSub = this.left.parentSub;
          } else if (this.right && this.right.constructor === _Item) {
            this.parent = this.right.parent;
            this.parentSub = this.right.parentSub;
          }
        } else if (this.parent.constructor === ID) {
          const parentItem = getItem(store, this.parent);
          if (parentItem.constructor === GC) {
            this.parent = null;
          } else {
            this.parent = /** @type {ContentType} */
            parentItem.content.type;
          }
        }
        return null;
      }
      /**
       * @param {Transaction} transaction
       * @param {number} offset
       */
      integrate(transaction, offset) {
        if (offset > 0) {
          this.id.clock += offset;
          this.left = getItemCleanEnd(transaction, transaction.doc.store, createID(this.id.client, this.id.clock - 1));
          this.origin = this.left.lastId;
          this.content = this.content.splice(offset);
          this.length -= offset;
        }
        if (this.parent) {
          if (!this.left && (!this.right || this.right.left !== null) || this.left && this.left.right !== this.right) {
            let left = this.left;
            let o;
            if (left !== null) {
              o = left.right;
            } else if (this.parentSub !== null) {
              o = /** @type {AbstractType<any>} */
              this.parent._map.get(this.parentSub) || null;
              while (o !== null && o.left !== null) {
                o = o.left;
              }
            } else {
              o = /** @type {AbstractType<any>} */
              this.parent._start;
            }
            const conflictingItems = /* @__PURE__ */ new Set();
            const itemsBeforeOrigin = /* @__PURE__ */ new Set();
            while (o !== null && o !== this.right) {
              itemsBeforeOrigin.add(o);
              conflictingItems.add(o);
              if (compareIDs(this.origin, o.origin)) {
                if (o.id.client < this.id.client) {
                  left = o;
                  conflictingItems.clear();
                } else if (compareIDs(this.rightOrigin, o.rightOrigin)) {
                  break;
                }
              } else if (o.origin !== null && itemsBeforeOrigin.has(getItem(transaction.doc.store, o.origin))) {
                if (!conflictingItems.has(getItem(transaction.doc.store, o.origin))) {
                  left = o;
                  conflictingItems.clear();
                }
              } else {
                break;
              }
              o = o.right;
            }
            this.left = left;
          }
          if (this.left !== null) {
            const right = this.left.right;
            this.right = right;
            this.left.right = this;
          } else {
            let r;
            if (this.parentSub !== null) {
              r = /** @type {AbstractType<any>} */
              this.parent._map.get(this.parentSub) || null;
              while (r !== null && r.left !== null) {
                r = r.left;
              }
            } else {
              r = /** @type {AbstractType<any>} */
              this.parent._start;
              this.parent._start = this;
            }
            this.right = r;
          }
          if (this.right !== null) {
            this.right.left = this;
          } else if (this.parentSub !== null) {
            this.parent._map.set(this.parentSub, this);
            if (this.left !== null) {
              this.left.delete(transaction);
            }
          }
          if (this.parentSub === null && this.countable && !this.deleted) {
            this.parent._length += this.length;
          }
          addStruct(transaction.doc.store, this);
          this.content.integrate(transaction, this);
          addChangedTypeToTransaction(
            transaction,
            /** @type {AbstractType<any>} */
            this.parent,
            this.parentSub
          );
          if (
            /** @type {AbstractType<any>} */
            this.parent._item !== null && /** @type {AbstractType<any>} */
            this.parent._item.deleted || this.parentSub !== null && this.right !== null
          ) {
            this.delete(transaction);
          }
        } else {
          new GC(this.id, this.length).integrate(transaction, 0);
        }
      }
      /**
       * Returns the next non-deleted item
       */
      get next() {
        let n = this.right;
        while (n !== null && n.deleted) {
          n = n.right;
        }
        return n;
      }
      /**
       * Returns the previous non-deleted item
       */
      get prev() {
        let n = this.left;
        while (n !== null && n.deleted) {
          n = n.left;
        }
        return n;
      }
      /**
       * Computes the last content address of this Item.
       */
      get lastId() {
        return this.length === 1 ? this.id : createID(this.id.client, this.id.clock + this.length - 1);
      }
      /**
       * Try to merge two items
       *
       * @param {Item} right
       * @return {boolean}
       */
      mergeWith(right) {
        if (this.constructor === right.constructor && compareIDs(right.origin, this.lastId) && this.right === right && compareIDs(this.rightOrigin, right.rightOrigin) && this.id.client === right.id.client && this.id.clock + this.length === right.id.clock && this.deleted === right.deleted && this.redone === null && right.redone === null && this.content.constructor === right.content.constructor && this.content.mergeWith(right.content)) {
          const searchMarker = (
            /** @type {AbstractType<any>} */
            this.parent._searchMarker
          );
          if (searchMarker) {
            searchMarker.forEach((marker) => {
              if (marker.p === right) {
                marker.p = this;
                if (!this.deleted && this.countable) {
                  marker.index -= this.length;
                }
              }
            });
          }
          if (right.keep) {
            this.keep = true;
          }
          this.right = right.right;
          if (this.right !== null) {
            this.right.left = this;
          }
          this.length += right.length;
          return true;
        }
        return false;
      }
      /**
       * Mark this Item as deleted.
       *
       * @param {Transaction} transaction
       */
      delete(transaction) {
        if (!this.deleted) {
          const parent = (
            /** @type {AbstractType<any>} */
            this.parent
          );
          if (this.countable && this.parentSub === null) {
            parent._length -= this.length;
          }
          this.markDeleted();
          addToDeleteSet(transaction.deleteSet, this.id.client, this.id.clock, this.length);
          addChangedTypeToTransaction(transaction, parent, this.parentSub);
          this.content.delete(transaction);
        }
      }
      /**
       * @param {StructStore} store
       * @param {boolean} parentGCd
       */
      gc(store, parentGCd) {
        if (!this.deleted) {
          throw unexpectedCase();
        }
        this.content.gc(store);
        if (parentGCd) {
          replaceStruct(store, this, new GC(this.id, this.length));
        } else {
          this.content = new ContentDeleted(this.length);
        }
      }
      /**
       * Transform the properties of this type to binary and write it to an
       * BinaryEncoder.
       *
       * This is called when this Item is sent to a remote peer.
       *
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
       * @param {number} offset
       */
      write(encoder, offset) {
        const origin = offset > 0 ? createID(this.id.client, this.id.clock + offset - 1) : this.origin;
        const rightOrigin = this.rightOrigin;
        const parentSub = this.parentSub;
        const info = this.content.getRef() & BITS5 | (origin === null ? 0 : BIT8) | // origin is defined
        (rightOrigin === null ? 0 : BIT7) | // right origin is defined
        (parentSub === null ? 0 : BIT6);
        encoder.writeInfo(info);
        if (origin !== null) {
          encoder.writeLeftID(origin);
        }
        if (rightOrigin !== null) {
          encoder.writeRightID(rightOrigin);
        }
        if (origin === null && rightOrigin === null) {
          const parent = (
            /** @type {AbstractType<any>} */
            this.parent
          );
          if (parent._item !== void 0) {
            const parentItem = parent._item;
            if (parentItem === null) {
              const ykey = findRootTypeKey(parent);
              encoder.writeParentInfo(true);
              encoder.writeString(ykey);
            } else {
              encoder.writeParentInfo(false);
              encoder.writeLeftID(parentItem.id);
            }
          } else if (parent.constructor === String) {
            encoder.writeParentInfo(true);
            encoder.writeString(parent);
          } else if (parent.constructor === ID) {
            encoder.writeParentInfo(false);
            encoder.writeLeftID(parent);
          } else {
            unexpectedCase();
          }
          if (parentSub !== null) {
            encoder.writeString(parentSub);
          }
        }
        this.content.write(encoder, offset);
      }
    };
    readItemContent = (decoder, info) => contentRefs[info & BITS5](decoder);
    contentRefs = [
      () => {
        unexpectedCase();
      },
      // GC is not ItemContent
      readContentDeleted,
      // 1
      readContentJSON,
      // 2
      readContentBinary,
      // 3
      readContentString,
      // 4
      readContentEmbed,
      // 5
      readContentFormat,
      // 6
      readContentType,
      // 7
      readContentAny,
      // 8
      readContentDoc,
      // 9
      () => {
        unexpectedCase();
      }
      // 10 - Skip is not ItemContent
    ];
    structSkipRefNumber = 10;
    Skip = class extends AbstractStruct {
      get deleted() {
        return true;
      }
      delete() {
      }
      /**
       * @param {Skip} right
       * @return {boolean}
       */
      mergeWith(right) {
        if (this.constructor !== right.constructor) {
          return false;
        }
        this.length += right.length;
        return true;
      }
      /**
       * @param {Transaction} transaction
       * @param {number} offset
       */
      integrate(transaction, offset) {
        unexpectedCase();
      }
      /**
       * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
       * @param {number} offset
       */
      write(encoder, offset) {
        encoder.writeInfo(structSkipRefNumber);
        writeVarUint(encoder.restEncoder, this.length - offset);
      }
      /**
       * @param {Transaction} transaction
       * @param {StructStore} store
       * @return {null | number}
       */
      getMissing(transaction, store) {
        return null;
      }
    };
    glo = /** @type {any} */
    typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {};
    importIdentifier = "__ $YJS$ __";
    if (glo[importIdentifier] === true) {
      console.error("Yjs was already imported. This breaks constructor checks and will lead to issues! - https://github.com/yjs/yjs/issues/438");
    }
    glo[importIdentifier] = true;
  }
});

// node_modules/lib0/broadcastchannel.js
var channels, LocalStoragePolyfill, BC, getChannel, subscribe, unsubscribe, publish;
var init_broadcastchannel = __esm({
  "node_modules/lib0/broadcastchannel.js"() {
    init_map();
    init_set();
    init_buffer();
    init_storage();
    channels = /* @__PURE__ */ new Map();
    LocalStoragePolyfill = class {
      /**
       * @param {string} room
       */
      constructor(room) {
        this.room = room;
        this.onmessage = null;
        this._onChange = (e) => e.key === room && this.onmessage !== null && this.onmessage({ data: fromBase64(e.newValue || "") });
        onChange(this._onChange);
      }
      /**
       * @param {ArrayBuffer} buf
       */
      postMessage(buf) {
        varStorage.setItem(this.room, toBase64(createUint8ArrayFromArrayBuffer(buf)));
      }
      close() {
        offChange(this._onChange);
      }
    };
    BC = typeof BroadcastChannel === "undefined" ? LocalStoragePolyfill : BroadcastChannel;
    getChannel = (room) => setIfUndefined(channels, room, () => {
      const subs = create2();
      const bc = new BC(room);
      bc.onmessage = (e) => subs.forEach((sub) => sub(e.data, "broadcastchannel"));
      return {
        bc,
        subs
      };
    });
    subscribe = (room, f) => {
      getChannel(room).subs.add(f);
      return f;
    };
    unsubscribe = (room, f) => {
      const channel = getChannel(room);
      const unsubscribed = channel.subs.delete(f);
      if (unsubscribed && channel.subs.size === 0) {
        channel.bc.close();
        channels.delete(room);
      }
      return unsubscribed;
    };
    publish = (room, data, origin = null) => {
      const c = getChannel(room);
      c.bc.postMessage(data);
      c.subs.forEach((sub) => sub(data, origin));
    };
  }
});

// node_modules/y-protocols/sync.js
var messageYjsSyncStep1, messageYjsSyncStep2, messageYjsUpdate, writeSyncStep1, writeSyncStep2, readSyncStep1, readSyncStep2, writeUpdate, readUpdate2, readSyncMessage;
var init_sync = __esm({
  "node_modules/y-protocols/sync.js"() {
    init_encoding();
    init_decoding();
    init_yjs();
    messageYjsSyncStep1 = 0;
    messageYjsSyncStep2 = 1;
    messageYjsUpdate = 2;
    writeSyncStep1 = (encoder, doc) => {
      writeVarUint(encoder, messageYjsSyncStep1);
      const sv = encodeStateVector(doc);
      writeVarUint8Array(encoder, sv);
    };
    writeSyncStep2 = (encoder, doc, encodedStateVector) => {
      writeVarUint(encoder, messageYjsSyncStep2);
      writeVarUint8Array(encoder, encodeStateAsUpdate(doc, encodedStateVector));
    };
    readSyncStep1 = (decoder, encoder, doc) => writeSyncStep2(encoder, doc, readVarUint8Array(decoder));
    readSyncStep2 = (decoder, doc, transactionOrigin, errorHandler) => {
      try {
        applyUpdate(doc, readVarUint8Array(decoder), transactionOrigin);
      } catch (error) {
        if (errorHandler != null)
          errorHandler(
            /** @type {Error} */
            error
          );
        console.error("Caught error while handling a Yjs update", error);
      }
    };
    writeUpdate = (encoder, update) => {
      writeVarUint(encoder, messageYjsUpdate);
      writeVarUint8Array(encoder, update);
    };
    readUpdate2 = readSyncStep2;
    readSyncMessage = (decoder, encoder, doc, transactionOrigin, errorHandler) => {
      const messageType = readVarUint(decoder);
      switch (messageType) {
        case messageYjsSyncStep1:
          readSyncStep1(decoder, encoder, doc);
          break;
        case messageYjsSyncStep2:
          readSyncStep2(decoder, doc, transactionOrigin, errorHandler);
          break;
        case messageYjsUpdate:
          readUpdate2(decoder, doc, transactionOrigin, errorHandler);
          break;
        default:
          throw new Error("Unknown message type");
      }
      return messageType;
    };
  }
});

// node_modules/y-protocols/auth.js
var messagePermissionDenied, readAuthMessage;
var init_auth = __esm({
  "node_modules/y-protocols/auth.js"() {
    init_decoding();
    messagePermissionDenied = 0;
    readAuthMessage = (decoder, y, permissionDeniedHandler2) => {
      switch (readVarUint(decoder)) {
        case messagePermissionDenied:
          permissionDeniedHandler2(y, readVarString(decoder));
      }
    };
  }
});

// node_modules/y-protocols/awareness.js
var outdatedTimeout, Awareness, removeAwarenessStates, encodeAwarenessUpdate, applyAwarenessUpdate;
var init_awareness = __esm({
  "node_modules/y-protocols/awareness.js"() {
    init_encoding();
    init_decoding();
    init_time();
    init_math();
    init_observable();
    init_function();
    outdatedTimeout = 3e4;
    Awareness = class extends Observable {
      /**
       * @param {Y.Doc} doc
       */
      constructor(doc) {
        super();
        this.doc = doc;
        this.clientID = doc.clientID;
        this.states = /* @__PURE__ */ new Map();
        this.meta = /* @__PURE__ */ new Map();
        this._checkInterval = /** @type {any} */
        setInterval(() => {
          const now = getUnixTime();
          if (this.getLocalState() !== null && outdatedTimeout / 2 <= now - /** @type {{lastUpdated:number}} */
          this.meta.get(this.clientID).lastUpdated) {
            this.setLocalState(this.getLocalState());
          }
          const remove = [];
          this.meta.forEach((meta, clientid) => {
            if (clientid !== this.clientID && outdatedTimeout <= now - meta.lastUpdated && this.states.has(clientid)) {
              remove.push(clientid);
            }
          });
          if (remove.length > 0) {
            removeAwarenessStates(this, remove, "timeout");
          }
        }, floor(outdatedTimeout / 10));
        doc.on("destroy", () => {
          this.destroy();
        });
        this.setLocalState({});
      }
      destroy() {
        this.emit("destroy", [this]);
        this.setLocalState(null);
        super.destroy();
        clearInterval(this._checkInterval);
      }
      /**
       * @return {Object<string,any>|null}
       */
      getLocalState() {
        return this.states.get(this.clientID) || null;
      }
      /**
       * @param {Object<string,any>|null} state
       */
      setLocalState(state) {
        const clientID = this.clientID;
        const currLocalMeta = this.meta.get(clientID);
        const clock = currLocalMeta === void 0 ? 0 : currLocalMeta.clock + 1;
        const prevState = this.states.get(clientID);
        if (state === null) {
          this.states.delete(clientID);
        } else {
          this.states.set(clientID, state);
        }
        this.meta.set(clientID, {
          clock,
          lastUpdated: getUnixTime()
        });
        const added = [];
        const updated = [];
        const filteredUpdated = [];
        const removed = [];
        if (state === null) {
          removed.push(clientID);
        } else if (prevState == null) {
          if (state != null) {
            added.push(clientID);
          }
        } else {
          updated.push(clientID);
          if (!equalityDeep(prevState, state)) {
            filteredUpdated.push(clientID);
          }
        }
        if (added.length > 0 || filteredUpdated.length > 0 || removed.length > 0) {
          this.emit("change", [{ added, updated: filteredUpdated, removed }, "local"]);
        }
        this.emit("update", [{ added, updated, removed }, "local"]);
      }
      /**
       * @param {string} field
       * @param {any} value
       */
      setLocalStateField(field, value) {
        const state = this.getLocalState();
        if (state !== null) {
          this.setLocalState({
            ...state,
            [field]: value
          });
        }
      }
      /**
       * @return {Map<number,Object<string,any>>}
       */
      getStates() {
        return this.states;
      }
    };
    removeAwarenessStates = (awareness, clients, origin) => {
      const removed = [];
      for (let i = 0; i < clients.length; i++) {
        const clientID = clients[i];
        if (awareness.states.has(clientID)) {
          awareness.states.delete(clientID);
          if (clientID === awareness.clientID) {
            const curMeta = (
              /** @type {MetaClientState} */
              awareness.meta.get(clientID)
            );
            awareness.meta.set(clientID, {
              clock: curMeta.clock + 1,
              lastUpdated: getUnixTime()
            });
          }
          removed.push(clientID);
        }
      }
      if (removed.length > 0) {
        awareness.emit("change", [{ added: [], updated: [], removed }, origin]);
        awareness.emit("update", [{ added: [], updated: [], removed }, origin]);
      }
    };
    encodeAwarenessUpdate = (awareness, clients, states = awareness.states) => {
      const len = clients.length;
      const encoder = createEncoder();
      writeVarUint(encoder, len);
      for (let i = 0; i < len; i++) {
        const clientID = clients[i];
        const state = states.get(clientID) || null;
        const clock = (
          /** @type {MetaClientState} */
          awareness.meta.get(clientID).clock
        );
        writeVarUint(encoder, clientID);
        writeVarUint(encoder, clock);
        writeVarString(encoder, JSON.stringify(state));
      }
      return toUint8Array(encoder);
    };
    applyAwarenessUpdate = (awareness, update, origin) => {
      const decoder = createDecoder(update);
      const timestamp = getUnixTime();
      const added = [];
      const updated = [];
      const filteredUpdated = [];
      const removed = [];
      const len = readVarUint(decoder);
      for (let i = 0; i < len; i++) {
        const clientID = readVarUint(decoder);
        let clock = readVarUint(decoder);
        const state = JSON.parse(readVarString(decoder));
        const clientMeta = awareness.meta.get(clientID);
        const prevState = awareness.states.get(clientID);
        const currClock = clientMeta === void 0 ? 0 : clientMeta.clock;
        if (currClock < clock || currClock === clock && state === null && awareness.states.has(clientID)) {
          if (state === null) {
            if (clientID === awareness.clientID && awareness.getLocalState() != null) {
              clock++;
            } else {
              awareness.states.delete(clientID);
            }
          } else {
            awareness.states.set(clientID, state);
          }
          awareness.meta.set(clientID, {
            clock,
            lastUpdated: timestamp
          });
          if (clientMeta === void 0 && state !== null) {
            added.push(clientID);
          } else if (clientMeta !== void 0 && state === null) {
            removed.push(clientID);
          } else if (state !== null) {
            if (!equalityDeep(state, prevState)) {
              filteredUpdated.push(clientID);
            }
            updated.push(clientID);
          }
        }
      }
      if (added.length > 0 || filteredUpdated.length > 0 || removed.length > 0) {
        awareness.emit("change", [{
          added,
          updated: filteredUpdated,
          removed
        }, origin]);
      }
      if (added.length > 0 || updated.length > 0 || removed.length > 0) {
        awareness.emit("update", [{
          added,
          updated,
          removed
        }, origin]);
      }
    };
  }
});

// node_modules/lib0/url.js
var encodeQueryParams;
var init_url = __esm({
  "node_modules/lib0/url.js"() {
    init_object();
    encodeQueryParams = (params2) => map(params2, (val, key) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`).join("&");
  }
});

// node_modules/y-websocket/src/y-websocket.js
var y_websocket_exports = {};
__export(y_websocket_exports, {
  WebsocketProvider: () => WebsocketProvider,
  messageAuth: () => messageAuth,
  messageAwareness: () => messageAwareness,
  messageQueryAwareness: () => messageQueryAwareness,
  messageSync: () => messageSync
});
var messageSync, messageQueryAwareness, messageAwareness, messageAuth, messageHandlers, messageReconnectTimeout, permissionDeniedHandler, readMessage, setupWS, broadcastMessage, WebsocketProvider;
var init_y_websocket = __esm({
  "node_modules/y-websocket/src/y-websocket.js"() {
    init_broadcastchannel();
    init_time();
    init_encoding();
    init_decoding();
    init_sync();
    init_auth();
    init_awareness();
    init_observable();
    init_math();
    init_url();
    init_environment();
    messageSync = 0;
    messageQueryAwareness = 3;
    messageAwareness = 1;
    messageAuth = 2;
    messageHandlers = [];
    messageHandlers[messageSync] = (encoder, decoder, provider, emitSynced, _messageType) => {
      writeVarUint(encoder, messageSync);
      const syncMessageType = readSyncMessage(
        decoder,
        encoder,
        provider.doc,
        provider
      );
      if (emitSynced && syncMessageType === messageYjsSyncStep2 && !provider.synced) {
        provider.synced = true;
      }
    };
    messageHandlers[messageQueryAwareness] = (encoder, _decoder, provider, _emitSynced, _messageType) => {
      writeVarUint(encoder, messageAwareness);
      writeVarUint8Array(
        encoder,
        encodeAwarenessUpdate(
          provider.awareness,
          Array.from(provider.awareness.getStates().keys())
        )
      );
    };
    messageHandlers[messageAwareness] = (_encoder, decoder, provider, _emitSynced, _messageType) => {
      applyAwarenessUpdate(
        provider.awareness,
        readVarUint8Array(decoder),
        provider
      );
    };
    messageHandlers[messageAuth] = (_encoder, decoder, provider, _emitSynced, _messageType) => {
      readAuthMessage(
        decoder,
        provider.doc,
        (_ydoc, reason) => permissionDeniedHandler(provider, reason)
      );
    };
    messageReconnectTimeout = 3e4;
    permissionDeniedHandler = (provider, reason) => console.warn(`Permission denied to access ${provider.url}.
${reason}`);
    readMessage = (provider, buf, emitSynced) => {
      const decoder = createDecoder(buf);
      const encoder = createEncoder();
      const messageType = readVarUint(decoder);
      const messageHandler = provider.messageHandlers[messageType];
      if (
        /** @type {any} */
        messageHandler
      ) {
        messageHandler(encoder, decoder, provider, emitSynced, messageType);
      } else {
        console.error("Unable to compute message");
      }
      return encoder;
    };
    setupWS = (provider) => {
      if (provider.shouldConnect && provider.ws === null) {
        const websocket = new provider._WS(provider.url);
        websocket.binaryType = "arraybuffer";
        provider.ws = websocket;
        provider.wsconnecting = true;
        provider.wsconnected = false;
        provider.synced = false;
        websocket.onmessage = (event) => {
          provider.wsLastMessageReceived = getUnixTime();
          const encoder = readMessage(provider, new Uint8Array(event.data), true);
          if (length(encoder) > 1) {
            websocket.send(toUint8Array(encoder));
          }
        };
        websocket.onerror = (event) => {
          provider.emit("connection-error", [event, provider]);
        };
        websocket.onclose = (event) => {
          provider.emit("connection-close", [event, provider]);
          provider.ws = null;
          provider.wsconnecting = false;
          if (provider.wsconnected) {
            provider.wsconnected = false;
            provider.synced = false;
            removeAwarenessStates(
              provider.awareness,
              Array.from(provider.awareness.getStates().keys()).filter(
                (client) => client !== provider.doc.clientID
              ),
              provider
            );
            provider.emit("status", [{
              status: "disconnected"
            }]);
          } else {
            provider.wsUnsuccessfulReconnects++;
          }
          setTimeout(
            setupWS,
            min(
              pow(2, provider.wsUnsuccessfulReconnects) * 100,
              provider.maxBackoffTime
            ),
            provider
          );
        };
        websocket.onopen = () => {
          provider.wsLastMessageReceived = getUnixTime();
          provider.wsconnecting = false;
          provider.wsconnected = true;
          provider.wsUnsuccessfulReconnects = 0;
          provider.emit("status", [{
            status: "connected"
          }]);
          const encoder = createEncoder();
          writeVarUint(encoder, messageSync);
          writeSyncStep1(encoder, provider.doc);
          websocket.send(toUint8Array(encoder));
          if (provider.awareness.getLocalState() !== null) {
            const encoderAwarenessState = createEncoder();
            writeVarUint(encoderAwarenessState, messageAwareness);
            writeVarUint8Array(
              encoderAwarenessState,
              encodeAwarenessUpdate(provider.awareness, [
                provider.doc.clientID
              ])
            );
            websocket.send(toUint8Array(encoderAwarenessState));
          }
        };
        provider.emit("status", [{
          status: "connecting"
        }]);
      }
    };
    broadcastMessage = (provider, buf) => {
      const ws = provider.ws;
      if (provider.wsconnected && ws && ws.readyState === ws.OPEN) {
        ws.send(buf);
      }
      if (provider.bcconnected) {
        publish(provider.bcChannel, buf, provider);
      }
    };
    WebsocketProvider = class extends Observable {
      /**
       * @param {string} serverUrl
       * @param {string} roomname
       * @param {Y.Doc} doc
       * @param {object} opts
       * @param {boolean} [opts.connect]
       * @param {awarenessProtocol.Awareness} [opts.awareness]
       * @param {Object<string,string>} [opts.params]
       * @param {typeof WebSocket} [opts.WebSocketPolyfill] Optionall provide a WebSocket polyfill
       * @param {number} [opts.resyncInterval] Request server state every `resyncInterval` milliseconds
       * @param {number} [opts.maxBackoffTime] Maximum amount of time to wait before trying to reconnect (we try to reconnect using exponential backoff)
       * @param {boolean} [opts.disableBc] Disable cross-tab BroadcastChannel communication
       */
      constructor(serverUrl, roomname, doc, {
        connect = true,
        awareness = new Awareness(doc),
        params: params2 = {},
        WebSocketPolyfill = WebSocket,
        resyncInterval = -1,
        maxBackoffTime = 2500,
        disableBc = false
      } = {}) {
        super();
        while (serverUrl[serverUrl.length - 1] === "/") {
          serverUrl = serverUrl.slice(0, serverUrl.length - 1);
        }
        const encodedParams = encodeQueryParams(params2);
        this.maxBackoffTime = maxBackoffTime;
        this.bcChannel = serverUrl + "/" + roomname;
        this.url = serverUrl + "/" + roomname + (encodedParams.length === 0 ? "" : "?" + encodedParams);
        this.roomname = roomname;
        this.doc = doc;
        this._WS = WebSocketPolyfill;
        this.awareness = awareness;
        this.wsconnected = false;
        this.wsconnecting = false;
        this.bcconnected = false;
        this.disableBc = disableBc;
        this.wsUnsuccessfulReconnects = 0;
        this.messageHandlers = messageHandlers.slice();
        this._synced = false;
        this.ws = null;
        this.wsLastMessageReceived = 0;
        this.shouldConnect = connect;
        this._resyncInterval = 0;
        if (resyncInterval > 0) {
          this._resyncInterval = /** @type {any} */
          setInterval(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
              const encoder = createEncoder();
              writeVarUint(encoder, messageSync);
              writeSyncStep1(encoder, doc);
              this.ws.send(toUint8Array(encoder));
            }
          }, resyncInterval);
        }
        this._bcSubscriber = (data, origin) => {
          if (origin !== this) {
            const encoder = readMessage(this, new Uint8Array(data), false);
            if (length(encoder) > 1) {
              publish(this.bcChannel, toUint8Array(encoder), this);
            }
          }
        };
        this._updateHandler = (update, origin) => {
          if (origin !== this) {
            const encoder = createEncoder();
            writeVarUint(encoder, messageSync);
            writeUpdate(encoder, update);
            broadcastMessage(this, toUint8Array(encoder));
          }
        };
        this.doc.on("update", this._updateHandler);
        this._awarenessUpdateHandler = ({ added, updated, removed }, _origin) => {
          const changedClients = added.concat(updated).concat(removed);
          const encoder = createEncoder();
          writeVarUint(encoder, messageAwareness);
          writeVarUint8Array(
            encoder,
            encodeAwarenessUpdate(awareness, changedClients)
          );
          broadcastMessage(this, toUint8Array(encoder));
        };
        this._exitHandler = () => {
          removeAwarenessStates(
            this.awareness,
            [doc.clientID],
            "app closed"
          );
        };
        if (isNode && typeof process !== "undefined") {
          process.on("exit", this._exitHandler);
        }
        awareness.on("update", this._awarenessUpdateHandler);
        this._checkInterval = /** @type {any} */
        setInterval(() => {
          if (this.wsconnected && messageReconnectTimeout < getUnixTime() - this.wsLastMessageReceived) {
            this.ws.close();
          }
        }, messageReconnectTimeout / 10);
        if (connect) {
          this.connect();
        }
      }
      /**
       * @type {boolean}
       */
      get synced() {
        return this._synced;
      }
      set synced(state) {
        if (this._synced !== state) {
          this._synced = state;
          this.emit("synced", [state]);
          this.emit("sync", [state]);
        }
      }
      destroy() {
        if (this._resyncInterval !== 0) {
          clearInterval(this._resyncInterval);
        }
        clearInterval(this._checkInterval);
        this.disconnect();
        if (isNode && typeof process !== "undefined") {
          process.off("exit", this._exitHandler);
        }
        this.awareness.off("update", this._awarenessUpdateHandler);
        this.doc.off("update", this._updateHandler);
        super.destroy();
      }
      connectBc() {
        if (this.disableBc) {
          return;
        }
        if (!this.bcconnected) {
          subscribe(this.bcChannel, this._bcSubscriber);
          this.bcconnected = true;
        }
        const encoderSync = createEncoder();
        writeVarUint(encoderSync, messageSync);
        writeSyncStep1(encoderSync, this.doc);
        publish(this.bcChannel, toUint8Array(encoderSync), this);
        const encoderState = createEncoder();
        writeVarUint(encoderState, messageSync);
        writeSyncStep2(encoderState, this.doc);
        publish(this.bcChannel, toUint8Array(encoderState), this);
        const encoderAwarenessQuery = createEncoder();
        writeVarUint(encoderAwarenessQuery, messageQueryAwareness);
        publish(
          this.bcChannel,
          toUint8Array(encoderAwarenessQuery),
          this
        );
        const encoderAwarenessState = createEncoder();
        writeVarUint(encoderAwarenessState, messageAwareness);
        writeVarUint8Array(
          encoderAwarenessState,
          encodeAwarenessUpdate(this.awareness, [
            this.doc.clientID
          ])
        );
        publish(
          this.bcChannel,
          toUint8Array(encoderAwarenessState),
          this
        );
      }
      disconnectBc() {
        const encoder = createEncoder();
        writeVarUint(encoder, messageAwareness);
        writeVarUint8Array(
          encoder,
          encodeAwarenessUpdate(this.awareness, [
            this.doc.clientID
          ], /* @__PURE__ */ new Map())
        );
        broadcastMessage(this, toUint8Array(encoder));
        if (this.bcconnected) {
          unsubscribe(this.bcChannel, this._bcSubscriber);
          this.bcconnected = false;
        }
      }
      disconnect() {
        this.shouldConnect = false;
        this.disconnectBc();
        if (this.ws !== null) {
          this.ws.close();
        }
      }
      connect() {
        this.shouldConnect = true;
        if (!this.wsconnected && this.ws === null) {
          setupWS(this);
          this.connectBc();
        }
      }
    };
  }
});

// node_modules/async-limiter/index.js
var require_async_limiter = __commonJS({
  "node_modules/async-limiter/index.js"(exports2, module2) {
    "use strict";
    function Queue(options) {
      if (!(this instanceof Queue)) {
        return new Queue(options);
      }
      options = options || {};
      this.concurrency = options.concurrency || Infinity;
      this.pending = 0;
      this.jobs = [];
      this.cbs = [];
      this._done = done.bind(this);
    }
    var arrayAddMethods = [
      "push",
      "unshift",
      "splice"
    ];
    arrayAddMethods.forEach(function(method) {
      Queue.prototype[method] = function() {
        var methodResult = Array.prototype[method].apply(this.jobs, arguments);
        this._run();
        return methodResult;
      };
    });
    Object.defineProperty(Queue.prototype, "length", {
      get: function() {
        return this.pending + this.jobs.length;
      }
    });
    Queue.prototype._run = function() {
      if (this.pending === this.concurrency) {
        return;
      }
      if (this.jobs.length) {
        var job = this.jobs.shift();
        this.pending++;
        job(this._done);
        this._run();
      }
      if (this.pending === 0) {
        while (this.cbs.length !== 0) {
          var cb = this.cbs.pop();
          process.nextTick(cb);
        }
      }
    };
    Queue.prototype.onDone = function(cb) {
      if (typeof cb === "function") {
        this.cbs.push(cb);
        this._run();
      }
    };
    function done() {
      this.pending--;
      this._run();
    }
    module2.exports = Queue;
  }
});

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      BINARY_TYPES: ["nodebuffer", "arraybuffer", "fragments"],
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      EMPTY_BUFFER: Buffer.alloc(0),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    function concat(list, totalLength) {
      if (list.length === 0)
        return EMPTY_BUFFER;
      if (list.length === 1)
        return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      var offset = 0;
      for (var i = 0; i < list.length; i++) {
        const buf = list[i];
        buf.copy(target, offset);
        offset += buf.length;
      }
      return target;
    }
    function _mask(source, mask, output, offset, length2) {
      for (var i = 0; i < length2; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      const length2 = buffer.length;
      for (var i = 0; i < length2; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.byteLength === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data))
        return data;
      var buf;
      if (data instanceof ArrayBuffer) {
        buf = Buffer.from(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = viewToBuffer(data);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    function viewToBuffer(view) {
      const buf = Buffer.from(view.buffer);
      if (view.byteLength !== view.buffer.byteLength) {
        return buf.slice(view.byteOffset, view.byteOffset + view.byteLength);
      }
      return buf;
    }
    try {
      const bufferUtil = require("bufferutil");
      const bu = bufferUtil.BufferUtil || bufferUtil;
      module2.exports = {
        concat,
        mask(source, mask, output, offset, length2) {
          if (length2 < 48)
            _mask(source, mask, output, offset, length2);
          else
            bu.mask(source, mask, output, offset, length2);
        },
        toArrayBuffer,
        toBuffer,
        unmask(buffer, mask) {
          if (buffer.length < 32)
            _unmask(buffer, mask);
          else
            bu.unmask(buffer, mask);
        }
      };
    } catch (e) {
      module2.exports = {
        concat,
        mask: _mask,
        toArrayBuffer,
        toBuffer,
        unmask: _unmask
      };
    }
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var Limiter = require_async_limiter();
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var { kStatusCode, NOOP } = require_constants();
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var EMPTY_BLOCK = Buffer.from([0]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} options.serverNoContextTakeover Request/accept disabling
       *     of server context takeover
       * @param {Boolean} options.clientNoContextTakeover Advertise/acknowledge
       *     disabling of client context takeover
       * @param {(Boolean|Number)} options.serverMaxWindowBits Request/confirm the
       *     use of a custom server window size
       * @param {(Boolean|Number)} options.clientMaxWindowBits Advertise support
       *     for, or request, a custom client window size
       * @param {Object} options.zlibDeflateOptions Options to pass to zlib on deflate
       * @param {Object} options.zlibInflateOptions Options to pass to zlib on inflate
       * @param {Number} options.threshold Size (in bytes) below which messages
       *     should not be compressed
       * @param {Number} options.concurrencyLimit The number of concurrent calls to
       *     zlib
       * @param {Boolean} isServer Create the instance in either server or client
       *     mode
       * @param {Number} maxPayload The maximum allowed message length
       */
      constructor(options, isServer, maxPayload) {
        this._maxPayload = maxPayload | 0;
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._isServer = !!isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter({ concurrency });
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params2 = {};
        if (this._options.serverNoContextTakeover) {
          params2.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params2.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params2.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params2.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params2.client_max_window_bits = true;
        }
        return params2;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          this._deflate.close();
          this._deflate = null;
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params2) => {
          if (opts.serverNoContextTakeover === false && params2.server_no_context_takeover || params2.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params2.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params2.client_max_window_bits) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params2 = response[0];
        if (this._options.clientNoContextTakeover === false && params2.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params2.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params2.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params2.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params2;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params2) => {
          Object.keys(params2).forEach((key) => {
            var value = params2[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params2[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited by async-limiter.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.push((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited by async-limiter.
       *
       * @param {Buffer} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.push((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw(
            Object.assign({}, this._options.zlibInflateOptions, { windowBits })
          );
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin)
          this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {Buffer} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        if (!data || data.length === 0) {
          process.nextTick(callback, null, EMPTY_BLOCK);
          return;
        }
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw(
            Object.assign({}, this._options.zlibDeflateOptions, { windowBits })
          );
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("error", NOOP);
          this._deflate.on("data", deflateOnData);
        }
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          var data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin)
            data2 = data2.slice(0, data2.length - 4);
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.close();
            this._deflate = null;
          } else {
            this._deflate[kTotalLength] = 0;
            this._deflate[kBuffers] = [];
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @param {Object} target A reference to the target to which the event was dispatched
       */
      constructor(type, target) {
        this.target = target;
        this.type = type;
      }
    };
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {(String|Buffer|ArrayBuffer|Buffer[])} data The received data
       * @param {WebSocket} target A reference to the target to which the event was dispatched
       */
      constructor(data, target) {
        super("message", target);
        this.data = data;
      }
    };
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {Number} code The status code explaining why the connection is being closed
       * @param {String} reason A human-readable string explaining why the connection is closing
       * @param {WebSocket} target A reference to the target to which the event was dispatched
       */
      constructor(code, reason, target) {
        super("close", target);
        this.wasClean = target._closeFrameReceived && target._closeFrameSent;
        this.reason = reason;
        this.code = code;
      }
    };
    var OpenEvent = class extends Event {
      /**
       * Create a new `OpenEvent`.
       *
       * @param {WebSocket} target A reference to the target to which the event was dispatched
       */
      constructor(target) {
        super("open", target);
      }
    };
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {Object} error The error that generated this event
       * @param {WebSocket} target A reference to the target to which the event was dispatched
       */
      constructor(error, target) {
        super("error", target);
        this.message = error.message;
        this.error = error;
      }
    };
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} method A string representing the event type to listen for
       * @param {Function} listener The listener to add
       * @public
       */
      addEventListener(method, listener) {
        if (typeof listener !== "function")
          return;
        function onMessage(data) {
          listener.call(this, new MessageEvent(data, this));
        }
        function onClose(code, message) {
          listener.call(this, new CloseEvent(code, message, this));
        }
        function onError(error) {
          listener.call(this, new ErrorEvent(error, this));
        }
        function onOpen() {
          listener.call(this, new OpenEvent(this));
        }
        if (method === "message") {
          onMessage._listener = listener;
          this.on(method, onMessage);
        } else if (method === "close") {
          onClose._listener = listener;
          this.on(method, onClose);
        } else if (method === "error") {
          onError._listener = listener;
          this.on(method, onError);
        } else if (method === "open") {
          onOpen._listener = listener;
          this.on(method, onOpen);
        } else {
          this.on(method, listener);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} method A string representing the event type to remove
       * @param {Function} listener The listener to remove
       * @public
       */
      removeEventListener(method, listener) {
        const listeners = this.listeners(method);
        for (var i = 0; i < listeners.length; i++) {
          if (listeners[i] === listener || listeners[i]._listener === listener) {
            this.removeListener(method, listeners[i]);
          }
        }
      }
    };
    module2.exports = EventTarget;
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function push(dest, name, elem) {
      if (Object.prototype.hasOwnProperty.call(dest, name))
        dest[name].push(elem);
      else
        dest[name] = [elem];
    }
    function parse(header) {
      const offers = {};
      if (header === void 0 || header === "")
        return offers;
      var params2 = {};
      var mustUnescape = false;
      var isEscaping = false;
      var inQuotes = false;
      var extensionName;
      var paramName;
      var start = -1;
      var end = -1;
      for (var i = 0; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1)
              start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1)
              end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1)
              end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params2);
              params2 = {};
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1)
              start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1)
              end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1)
              end = i;
            push(params2, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params2);
              params2 = {};
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1)
              start = i;
            else if (!mustUnescape)
              mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1)
                start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1)
              start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1)
              end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1)
              end = i;
            var value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params2, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params2);
              params2 = {};
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1)
        end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, {});
      } else {
        if (paramName === void 0) {
          push(params2, token, true);
        } else if (mustUnescape) {
          push(params2, paramName, token.replace(/\\/g, ""));
        } else {
          push(params2, paramName, token);
        }
        push(offers, extensionName, params2);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension) => {
        var configurations = extensions[extension];
        if (!Array.isArray(configurations))
          configurations = [configurations];
        return configurations.map((params2) => {
          return [extension].concat(
            Object.keys(params2).map((k) => {
              var values = params2[k];
              if (!Array.isArray(values))
                values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports2) {
    "use strict";
    try {
      const isValidUTF8 = require("utf-8-validate");
      exports2.isValidUTF8 = typeof isValidUTF8 === "object" ? isValidUTF8.Validation.isValidUTF8 : isValidUTF8;
    } catch (e) {
      exports2.isValidUTF8 = () => true;
    }
    exports2.isValidStatusCode = (code) => {
      return code >= 1e3 && code <= 1013 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    };
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var Receiver = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {String} binaryType The type for binary data
       * @param {Object} extensions An object containing the negotiated extensions
       * @param {Number} maxPayload The maximum allowed message length
       */
      constructor(binaryType, extensions, maxPayload) {
        super();
        this._binaryType = binaryType || BINARY_TYPES[0];
        this[kWebSocket] = void 0;
        this._extensions = extensions || {};
        this._maxPayload = maxPayload | 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragments = [];
        this._state = GET_INFO;
        this._loop = false;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO)
          return cb();
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length)
          return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = buf.slice(n);
          return buf.slice(0, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          if (n >= buf.length) {
            this._buffers.shift().copy(dst, dst.length - n);
          } else {
            buf.copy(dst, dst.length - n, 0, n);
            this._buffers[0] = buf.slice(n);
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        var err;
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              err = this.getInfo();
              break;
            case GET_PAYLOAD_LENGTH_16:
              err = this.getPayloadLength16();
              break;
            case GET_PAYLOAD_LENGTH_64:
              err = this.getPayloadLength64();
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              err = this.getData(cb);
              break;
            default:
              this._loop = false;
              return;
          }
        } while (this._loop);
        cb(err);
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @return {(RangeError|undefined)} A possible error
       * @private
       */
      getInfo() {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          this._loop = false;
          return error(RangeError, "RSV2 and RSV3 must be clear", true, 1002);
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
          this._loop = false;
          return error(RangeError, "RSV1 must be clear", true, 1002);
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            this._loop = false;
            return error(RangeError, "RSV1 must be clear", true, 1002);
          }
          if (!this._fragmented) {
            this._loop = false;
            return error(RangeError, "invalid opcode 0", true, 1002);
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            this._loop = false;
            return error(RangeError, `invalid opcode ${this._opcode}`, true, 1002);
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            this._loop = false;
            return error(RangeError, "FIN must be set", true, 1002);
          }
          if (compressed) {
            this._loop = false;
            return error(RangeError, "RSV1 must be clear", true, 1002);
          }
          if (this._payloadLength > 125) {
            this._loop = false;
            return error(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002
            );
          }
        } else {
          this._loop = false;
          return error(RangeError, `invalid opcode ${this._opcode}`, true, 1002);
        }
        if (!this._fin && !this._fragmented)
          this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._payloadLength === 126)
          this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127)
          this._state = GET_PAYLOAD_LENGTH_64;
        else
          return this.haveLength();
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @return {(RangeError|undefined)} A possible error
       * @private
       */
      getPayloadLength16() {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        return this.haveLength();
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @return {(RangeError|undefined)} A possible error
       * @private
       */
      getPayloadLength64() {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          this._loop = false;
          return error(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009
          );
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        return this.haveLength();
      }
      /**
       * Payload length has been read.
       *
       * @return {(RangeError|undefined)} A possible error
       * @private
       */
      haveLength() {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            this._loop = false;
            return error(RangeError, "Max payload size exceeded", false, 1009);
          }
        }
        if (this._masked)
          this._state = GET_MASK;
        else
          this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      getData(cb) {
        var data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked)
            unmask(data, this._mask);
        }
        if (this._opcode > 7)
          return this.controlMessage(data);
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        return this.dataMessage();
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err)
            return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              return cb(
                error(RangeError, "Max payload size exceeded", false, 1009)
              );
            }
            this._fragments.push(buf);
          }
          const er = this.dataMessage();
          if (er)
            return cb(er);
          this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @return {(Error|undefined)} A possible error
       * @private
       */
      dataMessage() {
        if (this._fin) {
          const messageLength = this._messageLength;
          const fragments = this._fragments;
          this._totalPayloadLength = 0;
          this._messageLength = 0;
          this._fragmented = 0;
          this._fragments = [];
          if (this._opcode === 2) {
            var data;
            if (this._binaryType === "nodebuffer") {
              data = concat(fragments, messageLength);
            } else if (this._binaryType === "arraybuffer") {
              data = toArrayBuffer(concat(fragments, messageLength));
            } else {
              data = fragments;
            }
            this.emit("message", data);
          } else {
            const buf = concat(fragments, messageLength);
            if (!isValidUTF8(buf)) {
              this._loop = false;
              return error(Error, "invalid UTF-8 sequence", true, 1007);
            }
            this.emit("message", buf.toString());
          }
        }
        this._state = GET_INFO;
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data) {
        if (this._opcode === 8) {
          this._loop = false;
          if (data.length === 0) {
            this.emit("conclude", 1005, "");
            this.end();
          } else if (data.length === 1) {
            return error(RangeError, "invalid payload length 1", true, 1002);
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              return error(RangeError, `invalid status code ${code}`, true, 1002);
            }
            const buf = data.slice(2);
            if (!isValidUTF8(buf)) {
              return error(Error, "invalid UTF-8 sequence", true, 1007);
            }
            this.emit("conclude", code, buf.toString());
            this.end();
          }
        } else if (this._opcode === 9) {
          this.emit("ping", data);
        } else {
          this.emit("pong", data);
        }
        this._state = GET_INFO;
      }
    };
    module2.exports = Receiver;
    function error(ErrorCtor, message, prefix, statusCode) {
      const err = new ErrorCtor(
        prefix ? `Invalid WebSocket frame: ${message}` : message
      );
      Error.captureStackTrace(err, error);
      err[kStatusCode] = statusCode;
      return err;
    }
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { randomBytes } = require("crypto");
    var PerMessageDeflate = require_permessage_deflate();
    var { EMPTY_BUFFER } = require_constants();
    var { isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var Sender = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {net.Socket} socket The connection socket
       * @param {Object} extensions An object containing the negotiated extensions
       */
      constructor(socket, extensions) {
        this._extensions = extensions || {};
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._deflating = false;
        this._queue = [];
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {Buffer} data The data to frame
       * @param {Object} options Options object
       * @param {Number} options.opcode The opcode
       * @param {Boolean} options.readOnly Specifies whether `data` can be modified
       * @param {Boolean} options.fin Specifies whether or not to set the FIN bit
       * @param {Boolean} options.mask Specifies whether or not to mask `data`
       * @param {Boolean} options.rsv1 Specifies whether or not to set the RSV1 bit
       * @return {Buffer[]} The framed data as a list of `Buffer` instances
       * @public
       */
      static frame(data, options) {
        const merge = options.mask && options.readOnly;
        var offset = options.mask ? 6 : 2;
        var payloadLength = data.length;
        if (data.length >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (data.length > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? data.length + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1)
          target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(data.length, 2);
        } else if (payloadLength === 127) {
          target.writeUInt32BE(0, 2);
          target.writeUInt32BE(data.length, 6);
        }
        if (!options.mask)
          return [target, data];
        const mask = randomBytes(4);
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (merge) {
          applyMask(data, mask, target, offset, data.length);
          return [target];
        }
        applyMask(data, mask, data, 0, data.length);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {(Number|undefined)} code The status code component of the body
       * @param {String} data The message component of the body
       * @param {Boolean} mask Specifies whether or not to mask the message
       * @param {Function} cb Callback
       * @public
       */
      close(code, data, mask, cb) {
        var buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || data === "") {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          buf = Buffer.allocUnsafe(2 + Buffer.byteLength(data));
          buf.writeUInt16BE(code, 0);
          buf.write(data, 2);
        }
        if (this._deflating) {
          this.enqueue([this.doClose, buf, mask, cb]);
        } else {
          this.doClose(buf, mask, cb);
        }
      }
      /**
       * Frames and sends a close message.
       *
       * @param {Buffer} data The message to send
       * @param {Boolean} mask Specifies whether or not to mask `data`
       * @param {Function} cb Callback
       * @private
       */
      doClose(data, mask, cb) {
        this.sendFrame(
          _Sender.frame(data, {
            fin: true,
            rsv1: false,
            opcode: 8,
            mask,
            readOnly: false
          }),
          cb
        );
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} mask Specifies whether or not to mask `data`
       * @param {Function} cb Callback
       * @public
       */
      ping(data, mask, cb) {
        const buf = toBuffer(data);
        if (this._deflating) {
          this.enqueue([this.doPing, buf, mask, toBuffer.readOnly, cb]);
        } else {
          this.doPing(buf, mask, toBuffer.readOnly, cb);
        }
      }
      /**
       * Frames and sends a ping message.
       *
       * @param {*} data The message to send
       * @param {Boolean} mask Specifies whether or not to mask `data`
       * @param {Boolean} readOnly Specifies whether `data` can be modified
       * @param {Function} cb Callback
       * @private
       */
      doPing(data, mask, readOnly, cb) {
        this.sendFrame(
          _Sender.frame(data, {
            fin: true,
            rsv1: false,
            opcode: 9,
            mask,
            readOnly
          }),
          cb
        );
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} mask Specifies whether or not to mask `data`
       * @param {Function} cb Callback
       * @public
       */
      pong(data, mask, cb) {
        const buf = toBuffer(data);
        if (this._deflating) {
          this.enqueue([this.doPong, buf, mask, toBuffer.readOnly, cb]);
        } else {
          this.doPong(buf, mask, toBuffer.readOnly, cb);
        }
      }
      /**
       * Frames and sends a pong message.
       *
       * @param {*} data The message to send
       * @param {Boolean} mask Specifies whether or not to mask `data`
       * @param {Boolean} readOnly Specifies whether `data` can be modified
       * @param {Function} cb Callback
       * @private
       */
      doPong(data, mask, readOnly, cb) {
        this.sendFrame(
          _Sender.frame(data, {
            fin: true,
            rsv1: false,
            opcode: 10,
            mask,
            readOnly
          }),
          cb
        );
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} options.compress Specifies whether or not to compress `data`
       * @param {Boolean} options.binary Specifies whether `data` is binary or text
       * @param {Boolean} options.fin Specifies whether the fragment is the last one
       * @param {Boolean} options.mask Specifies whether or not to mask `data`
       * @param {Function} cb Callback
       * @public
       */
      send(data, options, cb) {
        const buf = toBuffer(data);
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        var opcode = options.binary ? 2 : 1;
        var rsv1 = options.compress;
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate) {
            rsv1 = buf.length >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin)
          this._firstFragment = true;
        if (perMessageDeflate) {
          const opts = {
            fin: options.fin,
            rsv1,
            opcode,
            mask: options.mask,
            readOnly: toBuffer.readOnly
          };
          if (this._deflating) {
            this.enqueue([this.dispatch, buf, this._compress, opts, cb]);
          } else {
            this.dispatch(buf, this._compress, opts, cb);
          }
        } else {
          this.sendFrame(
            _Sender.frame(buf, {
              fin: options.fin,
              rsv1: false,
              opcode,
              mask: options.mask,
              readOnly: toBuffer.readOnly
            }),
            cb
          );
        }
      }
      /**
       * Dispatches a data message.
       *
       * @param {Buffer} data The message to send
       * @param {Boolean} compress Specifies whether or not to compress `data`
       * @param {Object} options Options object
       * @param {Number} options.opcode The opcode
       * @param {Boolean} options.readOnly Specifies whether `data` can be modified
       * @param {Boolean} options.fin Specifies whether or not to set the FIN bit
       * @param {Boolean} options.mask Specifies whether or not to mask `data`
       * @param {Boolean} options.rsv1 Specifies whether or not to set the RSV1 bit
       * @param {Function} cb Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        this._deflating = true;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          this._deflating = false;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (!this._deflating && this._queue.length) {
          const params2 = this._queue.shift();
          this._bufferedBytes -= params2[1].length;
          params2[0].apply(this, params2.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params2) {
        this._bufferedBytes += params2[1].length;
        this._queue.push(params2);
      }
      /**
       * Sends a frame.
       *
       * @param {Buffer[]} list The frame to send
       * @param {Function} cb Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender;
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var crypto = require("crypto");
    var https = require("https");
    var http = require("http");
    var net = require("net");
    var tls = require("tls");
    var url = require("url");
    var PerMessageDeflate = require_permessage_deflate();
    var EventTarget = require_event_target();
    var extension = require_extension();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      GUID,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var protocolVersions = [8, 13];
    var closeTimeout = 30 * 1e3;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|url.Url|url.URL)} address The URL to which to connect
       * @param {(String|String[])} protocols The subprotocols
       * @param {Object} options Connection options
       */
      constructor(address, protocols, options) {
        super();
        this.readyState = _WebSocket.CONNECTING;
        this.protocol = "";
        this._binaryType = BINARY_TYPES[0];
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = "";
        this._closeTimer = null;
        this._closeCode = 1006;
        this._extensions = {};
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._isServer = false;
          this._redirects = 0;
          if (Array.isArray(protocols)) {
            protocols = protocols.join(", ");
          } else if (typeof protocols === "object" && protocols !== null) {
            options = protocols;
            protocols = void 0;
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._isServer = true;
        }
      }
      get CONNECTING() {
        return _WebSocket.CONNECTING;
      }
      get CLOSING() {
        return _WebSocket.CLOSING;
      }
      get CLOSED() {
        return _WebSocket.CLOSED;
      }
      get OPEN() {
        return _WebSocket.OPEN;
      }
      /**
       * This deviates from the WHATWG interface since ws doesn't support the
       * required default "blob" type (instead we define a custom "nodebuffer"
       * type).
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type))
          return;
        this._binaryType = type;
        if (this._receiver)
          this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket)
          return 0;
        return (this._socket.bufferSize || 0) + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {net.Socket} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Number} maxPayload The maximum allowed message size
       * @private
       */
      setSocket(socket, head, maxPayload) {
        const receiver = new Receiver(
          this._binaryType,
          this._extensions,
          maxPayload
        );
        this._sender = new Sender(socket, this._extensions);
        this._receiver = receiver;
        this._socket = socket;
        receiver[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        socket.setTimeout(0);
        socket.setNoDelay();
        if (head.length > 0)
          socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this.readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        this.readyState = _WebSocket.CLOSED;
        if (!this._socket) {
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate.extensionName]) {
          this._extensions[PerMessageDeflate.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} code Status code explaining why the connection is closing
       * @param {String} data A string explaining why the connection is closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED)
          return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          return abortHandshake(this, this._req, msg);
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && this._closeFrameReceived)
            this._socket.end();
          return;
        }
        this.readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err)
            return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived)
            this._socket.end();
        });
        this._closeTimer = setTimeout(
          this._socket.destroy.bind(this._socket),
          closeTimeout
        );
      }
      /**
       * Send a ping.
       *
       * @param {*} data The data to send
       * @param {Boolean} mask Indicates whether or not to mask `data`
       * @param {Function} cb Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (this.readyState !== _WebSocket.OPEN) {
          const err = new Error(
            `WebSocket is not open: readyState ${this.readyState} (${readyStates[this.readyState]})`
          );
          if (cb)
            return cb(err);
          throw err;
        }
        if (typeof data === "number")
          data = data.toString();
        if (mask === void 0)
          mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} data The data to send
       * @param {Boolean} mask Indicates whether or not to mask `data`
       * @param {Function} cb Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (this.readyState !== _WebSocket.OPEN) {
          const err = new Error(
            `WebSocket is not open: readyState ${this.readyState} (${readyStates[this.readyState]})`
          );
          if (cb)
            return cb(err);
          throw err;
        }
        if (typeof data === "number")
          data = data.toString();
        if (mask === void 0)
          mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} options.compress Specifies whether or not to compress `data`
       * @param {Boolean} options.binary Specifies whether `data` is binary or text
       * @param {Boolean} options.fin Specifies whether the fragment is the last one
       * @param {Boolean} options.mask Specifies whether or not to mask `data`
       * @param {Function} cb Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (this.readyState !== _WebSocket.OPEN) {
          const err = new Error(
            `WebSocket is not open: readyState ${this.readyState} (${readyStates[this.readyState]})`
          );
          if (cb)
            return cb(err);
          throw err;
        }
        if (typeof data === "number")
          data = data.toString();
        const opts = Object.assign(
          {
            binary: typeof data !== "string",
            mask: !this._isServer,
            compress: true,
            fin: true
          },
          options
        );
        if (!this._extensions[PerMessageDeflate.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED)
          return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          return abortHandshake(this, this._req, msg);
        }
        if (this._socket) {
          this.readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    readyStates.forEach((readyState, i) => {
      WebSocket2[readyState] = i;
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        /**
         * Return the listener of the event.
         *
         * @return {(Function|undefined)} The event listener or `undefined`
         * @public
         */
        get() {
          const listeners = this.listeners(method);
          for (var i = 0; i < listeners.length; i++) {
            if (listeners[i]._listener)
              return listeners[i]._listener;
          }
          return void 0;
        },
        /**
         * Add a listener for the event.
         *
         * @param {Function} listener The listener to add
         * @public
         */
        set(listener) {
          const listeners = this.listeners(method);
          for (var i = 0; i < listeners.length; i++) {
            if (listeners[i]._listener)
              this.removeListener(method, listeners[i]);
          }
          this.addEventListener(method, listener);
        }
      });
    });
    WebSocket2.prototype.addEventListener = EventTarget.addEventListener;
    WebSocket2.prototype.removeEventListener = EventTarget.removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = Object.assign(
        {
          protocolVersion: protocolVersions[1],
          maxPayload: 100 * 1024 * 1024,
          perMessageDeflate: true,
          followRedirects: false,
          maxRedirects: 10
        },
        options,
        {
          createConnection: void 0,
          socketPath: void 0,
          hostname: void 0,
          protocol: void 0,
          timeout: void 0,
          method: void 0,
          auth: void 0,
          host: void 0,
          path: void 0,
          port: void 0
        }
      );
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      var parsedUrl;
      if (typeof address === "object" && address.href !== void 0) {
        parsedUrl = address;
        websocket.url = address.href;
      } else {
        parsedUrl = url.URL ? new url.URL(address) : url.parse(address);
        websocket.url = address;
      }
      const isUnixSocket = parsedUrl.protocol === "ws+unix:";
      if (!parsedUrl.host && (!isUnixSocket || !parsedUrl.pathname)) {
        throw new Error(`Invalid URL: ${websocket.url}`);
      }
      const isSecure = parsedUrl.protocol === "wss:" || parsedUrl.protocol === "https:";
      const defaultPort = isSecure ? 443 : 80;
      const key = crypto.randomBytes(16).toString("base64");
      const get = isSecure ? https.get : http.get;
      const path = parsedUrl.search ? `${parsedUrl.pathname || "/"}${parsedUrl.search}` : parsedUrl.pathname || "/";
      var perMessageDeflate;
      opts.createConnection = isSecure ? tlsConnect : netConnect;
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = Object.assign(
        {
          "Sec-WebSocket-Version": opts.protocolVersion,
          "Sec-WebSocket-Key": key,
          Connection: "Upgrade",
          Upgrade: "websocket"
        },
        opts.headers
      );
      opts.path = path;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate(
          opts.perMessageDeflate !== true ? opts.perMessageDeflate : {},
          false,
          opts.maxPayload
        );
        opts.headers["Sec-WebSocket-Extensions"] = extension.format({
          [PerMessageDeflate.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols) {
        opts.headers["Sec-WebSocket-Protocol"] = protocols;
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.auth) {
        opts.auth = parsedUrl.auth;
      } else if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isUnixSocket) {
        const parts = path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      var req = websocket._req = get(opts);
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (websocket._req.aborted)
          return;
        req = websocket._req = null;
        websocket.readyState = WebSocket2.CLOSING;
        websocket.emit("error", err);
        websocket.emitClose();
      });
      req.on("response", (res) => {
        const location2 = res.headers.location;
        const statusCode = res.statusCode;
        if (location2 && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          const addr = url.URL ? new url.URL(location2, address) : url.resolve(address, location2);
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING)
          return;
        req = websocket._req = null;
        const digest = crypto.createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        const protList = (protocols || "").split(/, */);
        var protError;
        if (!protocols && serverProt) {
          protError = "Server sent a subprotocol but none was requested";
        } else if (protocols && !serverProt) {
          protError = "Server sent no subprotocol";
        } else if (serverProt && !protList.includes(serverProt)) {
          protError = "Server sent an invalid subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt)
          websocket.protocol = serverProt;
        if (perMessageDeflate) {
          try {
            const extensions = extension.parse(
              res.headers["sec-websocket-extensions"]
            );
            if (extensions[PerMessageDeflate.extensionName]) {
              perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
              websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            abortHandshake(
              websocket,
              socket,
              "Invalid Sec-WebSocket-Extensions header"
            );
            return;
          }
        }
        websocket.setSocket(socket, head, opts.maxPayload);
      });
    }
    function netConnect(options) {
      if (options.protocolVersion)
        options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      options.servername = options.servername || options.host;
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket.readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream.abort();
        stream.once("abort", websocket.emitClose.bind(websocket));
        websocket.emit("error", err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._socket.removeListener("data", socketOnData);
      websocket._socket.resume();
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (code === 1005)
        websocket.close();
      else
        websocket.close(code, reason);
    }
    function receiverOnDrain() {
      this[kWebSocket]._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      websocket._socket.removeListener("data", socketOnData);
      websocket.readyState = WebSocket2.CLOSING;
      websocket._closeCode = err[kStatusCode];
      websocket.emit("error", err);
      websocket._socket.destroy();
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data) {
      this[kWebSocket].emit("message", data);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      websocket.pong(data, !websocket._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("end", socketOnEnd);
      websocket.readyState = WebSocket2.CLOSING;
      websocket._socket.read();
      websocket._receiver.end();
      this.removeListener("data", socketOnData);
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket.readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      websocket.readyState = WebSocket2.CLOSING;
      this.destroy();
    }
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var crypto = require("crypto");
    var http = require("http");
    var PerMessageDeflate = require_permessage_deflate();
    var extension = require_extension();
    var WebSocket2 = require_websocket();
    var { GUID } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var WebSocketServer = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Number} options.backlog The maximum length of the queue of pending
       *     connections
       * @param {Boolean} options.clientTracking Specifies whether or not to track
       *     clients
       * @param {Function} options.handleProtocols An hook to handle protocols
       * @param {String} options.host The hostname where to bind the server
       * @param {Number} options.maxPayload The maximum allowed message size
       * @param {Boolean} options.noServer Enable no server mode
       * @param {String} options.path Accept only connections matching this path
       * @param {(Boolean|Object)} options.perMessageDeflate Enable/disable
       *     permessage-deflate
       * @param {Number} options.port The port where to bind the server
       * @param {http.Server} options.server A pre-created HTTP/S server to use
       * @param {Function} options.verifyClient An hook to reject connections
       * @param {Function} callback A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = Object.assign(
          {
            maxPayload: 100 * 1024 * 1024,
            perMessageDeflate: false,
            handleProtocols: null,
            clientTracking: true,
            verifyClient: null,
            noServer: false,
            backlog: null,
            // use default (511 as implemented in net.js)
            server: null,
            host: null,
            path: null,
            port: null
          },
          options
        );
        if (options.port == null && !options.server && !options.noServer) {
          throw new TypeError(
            'One of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, (ws) => {
                this.emit("connection", ws, req);
              });
            }
          });
        }
        if (options.perMessageDeflate === true)
          options.perMessageDeflate = {};
        if (options.clientTracking)
          this.clients = /* @__PURE__ */ new Set();
        this.options = options;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server)
          return null;
        return this._server.address();
      }
      /**
       * Close the server.
       *
       * @param {Function} cb Callback
       * @public
       */
      close(cb) {
        if (cb)
          this.once("close", cb);
        if (this.clients) {
          for (const client of this.clients)
            client.terminate();
        }
        const server = this._server;
        if (server) {
          this._removeListeners();
          this._removeListeners = this._server = null;
          if (this.options.port != null) {
            server.close(() => this.emit("close"));
            return;
          }
        }
        process.nextTick(emitClose, this);
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path)
            return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {net.Socket} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"] !== void 0 ? req.headers["sec-websocket-key"].trim() : false;
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        const extensions = {};
        if (req.method !== "GET" || upgrade === void 0 || upgrade.toLowerCase() !== "websocket" || !key || !keyRegex.test(key) || version !== 8 && version !== 13 || !this.shouldHandle(req)) {
          return abortHandshake(socket, 400);
        }
        if (this.options.perMessageDeflate) {
          const perMessageDeflate = new PerMessageDeflate(
            this.options.perMessageDeflate,
            true,
            this.options.maxPayload
          );
          try {
            const offers = extension.parse(req.headers["sec-websocket-extensions"]);
            if (offers[PerMessageDeflate.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
              extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            return abortHandshake(socket, 400);
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.connection.authorized || req.connection.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(key, extensions, req, socket, head, cb);
            });
            return;
          }
          if (!this.options.verifyClient(info))
            return abortHandshake(socket, 401);
        }
        this.completeUpgrade(key, extensions, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Object} extensions The accepted extensions
       * @param {http.IncomingMessage} req The request object
       * @param {net.Socket} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @private
       */
      completeUpgrade(key, extensions, req, socket, head, cb) {
        if (!socket.readable || !socket.writable)
          return socket.destroy();
        const digest = crypto.createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new WebSocket2(null);
        var protocol = req.headers["sec-websocket-protocol"];
        if (protocol) {
          protocol = protocol.split(",").map(trim);
          if (this.options.handleProtocols) {
            protocol = this.options.handleProtocols(protocol, req);
          } else {
            protocol = protocol[0];
          }
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws.protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate.extensionName]) {
          const params2 = extensions[PerMessageDeflate.extensionName].params;
          const value = extension.format({
            [PerMessageDeflate.extensionName]: [params2]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, this.options.maxPayload);
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => this.clients.delete(ws));
        }
        cb(ws);
      }
    };
    module2.exports = WebSocketServer;
    function addListeners(server, map2) {
      for (const event of Object.keys(map2))
        server.on(event, map2[event]);
      return function removeListeners() {
        for (const event of Object.keys(map2)) {
          server.removeListener(event, map2[event]);
        }
      };
    }
    function emitClose(server) {
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      if (socket.writable) {
        message = message || http.STATUS_CODES[code];
        headers = Object.assign(
          {
            Connection: "close",
            "Content-type": "text/html",
            "Content-Length": Buffer.byteLength(message)
          },
          headers
        );
        socket.write(
          `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
        );
      }
      socket.removeListener("error", socketOnError);
      socket.destroy();
    }
    function trim(str) {
      return str.trim();
    }
  }
});

// node_modules/ws/index.js
var require_ws = __commonJS({
  "node_modules/ws/index.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    WebSocket2.Server = require_websocket_server();
    WebSocket2.Receiver = require_receiver();
    WebSocket2.Sender = require_sender();
    module2.exports = WebSocket2;
  }
});

// src/api-client.js
var require_api_client = __commonJS({
  "src/api-client.js"(exports2, module2) {
    "use strict";
    var http = require("http");
    var ApiClient = class {
      constructor(port = 2019, logger = null) {
        this.port = port;
        this.host = "127.0.0.1";
        this.logger = logger;
      }
      /**
       * Check if the Tropy API is reachable.
       */
      async ping() {
        try {
          let res = await this.get("/");
          return res && res.status === "ok";
        } catch {
          return false;
        }
      }
      /**
       * Get project info including the project file path.
       * @returns {{ status, project, version }} project info
       */
      async getProjectInfo() {
        return this.get("/");
      }
      /**
       * Get all items in the project.
       * Returns an array of item summaries (id, template, etc.)
       */
      async getItems(query = {}) {
        let params2 = new URLSearchParams();
        if (query.q)
          params2.set("q", query.q);
        if (query.tag)
          params2.set("tag", query.tag);
        if (query.sort)
          params2.set("sort", query.sort);
        let qs = params2.toString();
        return this.get(`/project/items${qs ? "?" + qs : ""}`);
      }
      /**
       * Get a single item by ID (JSON-LD).
       */
      async getItem(id2) {
        return this.get(`/project/items/${id2}`);
      }
      /**
       * Get photos for an item.
       */
      async getPhotos(itemId) {
        return this.get(`/project/items/${itemId}/photos`);
      }
      /**
       * Get tags for an item.
       */
      async getItemTags(itemId) {
        return this.get(`/project/items/${itemId}/tags`);
      }
      /**
       * Get metadata for a subject (item, photo, or selection).
       */
      async getMetadata(subjectId) {
        return this.get(`/project/data/${subjectId}`);
      }
      /**
       * Save metadata for a subject.
       * @param {number} subjectId
       * @param {Object} data - metadata object { [propertyUri]: { text, type } }
       */
      async saveMetadata(subjectId, data) {
        return this.postJson(`/project/data/${subjectId}`, data);
      }
      /**
       * Get all tags in the project.
       */
      async getTags() {
        return this.get("/project/tags");
      }
      /**
       * Create a new tag.
       */
      async createTag(name, color = null, items = null) {
        return this.post("/project/tags", { name, color, item: items });
      }
      /**
       * Delete tags from the project entirely.
       * @param {number[]} tagIds
       */
      async deleteTags(tagIds) {
        let params2 = new URLSearchParams();
        for (let id2 of tagIds)
          params2.append("id", id2);
        return this.request("DELETE", `/project/tags?${params2.toString()}`);
      }
      /**
       * Add tags to an item.
       * @param {number} itemId
       * @param {number[]} tagIds
       */
      async addTagsToItem(itemId, tagIds) {
        return this.post(`/project/items/${itemId}/tags`, { tag: tagIds });
      }
      /**
       * Remove tags from an item.
       * @param {number} itemId
       * @param {number[]} tagIds
       */
      async removeTagsFromItem(itemId, tagIds) {
        let params2 = new URLSearchParams();
        for (let id2 of tagIds)
          params2.append("tag", id2);
        return this.request("DELETE", `/project/items/${itemId}/tags?${params2.toString()}`);
      }
      /**
       * Get a note by ID.
       * @param {number} noteId
       * @param {string} format - 'json', 'html', 'plain', 'md'
       */
      async getNote(noteId, format = "html") {
        return this.get(`/project/notes/${noteId}?format=${format}`);
      }
      /**
       * Create a new note.
       * @param {Object} params - { html, language, photo, selection }
       */
      async createNote(params2) {
        return this.postJson("/project/notes", params2);
      }
      /**
       * Update an existing note.
       * @param {number} noteId
       * @param {Object} params - { html, language }
       */
      async updateNote(noteId, params2) {
        return this.putJson(`/project/notes/${noteId}`, params2);
      }
      /**
       * Delete a note.
       */
      async deleteNote(noteId) {
        return this.request("DELETE", `/project/notes/${noteId}`);
      }
      /**
       * Get a photo by ID.
       */
      async getPhoto(photoId) {
        return this.get(`/project/photos/${photoId}`);
      }
      /**
       * Get a selection by ID.
       */
      async getSelection(selectionId) {
        return this.get(`/project/selections/${selectionId}`);
      }
      /**
       * Create a selection on a photo.
       * @param {Object} params - { photo, x, y, width, height, angle }
       */
      async createSelection(params2) {
        return this.postJson("/project/selections", params2);
      }
      /**
       * Update a selection's coordinates.
       * @param {number} selectionId
       * @param {Object} params - { x, y, width, height, angle }
       */
      async updateSelection(selectionId, params2) {
        return this.putJson(`/project/selections/${selectionId}`, params2);
      }
      /**
       * Delete a selection.
       */
      async deleteSelection(selectionId) {
        return this.request("DELETE", `/project/selections/${selectionId}`);
      }
      /**
       * Get a transcription by ID.
       * @param {number} id
       * @param {string} format - 'json' or 'html'
       */
      async getTranscription(id2, format = "json") {
        return this.get(`/project/transcriptions/${id2}?format=${format}`);
      }
      /**
       * Get transcriptions for an item.
       */
      async getItemTranscriptions(itemId) {
        return this.get(`/project/items/${itemId}/transcriptions`);
      }
      /**
       * Create a new transcription.
       * @param {Object} params - { text, data, photo, selection }
       */
      async createTranscription(params2) {
        return this.postJson("/project/transcriptions", params2);
      }
      /**
       * Update a transcription.
       * @param {number} id
       * @param {Object} params - { text, data }
       */
      async updateTranscription(id2, params2) {
        return this.putJson(`/project/transcriptions/${id2}`, params2);
      }
      /**
       * Delete a transcription.
       */
      async deleteTranscription(id2) {
        return this.request("DELETE", `/project/transcriptions/${id2}`);
      }
      /**
       * Get all lists in the project.
       */
      async getLists() {
        return this.get("/project/lists");
      }
      /**
       * Get a specific list.
       * @param {number} id
       */
      async getList(id2) {
        return this.get(`/project/lists/${id2}`);
      }
      /**
       * Get items in a list.
       * @param {number} listId
       */
      async getListItems(listId) {
        return this.get(`/project/lists/${listId}/items`);
      }
      /**
       * Add items to a list.
       * @param {number} listId
       * @param {number[]} itemIds
       */
      async addItemsToList(listId, itemIds) {
        return this.post(`/project/lists/${listId}/items`, { item: itemIds });
      }
      /**
       * Remove items from a list.
       * @param {number} listId
       * @param {number[]} itemIds
       */
      async removeItemsFromList(listId, itemIds) {
        let params2 = new URLSearchParams();
        for (let id2 of itemIds)
          params2.append("item", id2);
        return this.request("DELETE", `/project/lists/${listId}/items?${params2.toString()}`);
      }
      /**
       * Import items into Tropy.
       * Only accepts JSON-LD data — file paths are intentionally not supported
       * to prevent path traversal from remote sources (#10 in audit).
       * @param {Object} params - { data: JSON-LD items, list: list id }
       */
      async importItems(params2) {
        if (params2.file) {
          throw new Error("File path import is blocked for security \u2014 use data parameter with JSON-LD");
        }
        let body = new URLSearchParams();
        if (params2.data)
          body.set("data", JSON.stringify(params2.data));
        if (params2.list)
          body.set("list", params2.list);
        return this.request("POST", "/project/import", body.toString(), {
          "Content-Type": "application/x-www-form-urlencoded"
        });
      }
      /**
       * Get project version info.
       */
      async getVersion() {
        return this.get("/version");
      }
      // --- HTTP primitives ---
      async get(path) {
        return this.request("GET", path);
      }
      async post(path, data) {
        let body = new URLSearchParams();
        for (let [key, value] of Object.entries(data)) {
          if (value != null) {
            if (Array.isArray(value)) {
              for (let v of value)
                body.append(key, v);
            } else {
              body.set(key, value);
            }
          }
        }
        return this.request("POST", path, body.toString(), {
          "Content-Type": "application/x-www-form-urlencoded"
        });
      }
      async postJson(path, data) {
        return this.request("POST", path, JSON.stringify(data), {
          "Content-Type": "application/json"
        });
      }
      async putJson(path, data) {
        return this.request("PUT", path, JSON.stringify(data), {
          "Content-Type": "application/json"
        });
      }
      request(method, path, body = null, headers = {}, retries = 3) {
        return this._doRequest(method, path, body, headers, retries, 0);
      }
      _doRequest(method, path, body, headers, retriesLeft, attempt) {
        return new Promise((resolve, reject) => {
          let options = {
            hostname: this.host,
            port: this.port,
            path,
            method,
            headers: {
              "Accept": "application/json",
              ...headers
            }
          };
          if (body) {
            options.headers["Content-Length"] = Buffer.byteLength(body);
          }
          let req = http.request(options, (res) => {
            let chunks = [];
            res.on("data", (chunk) => chunks.push(chunk));
            res.on("end", () => {
              let raw = Buffer.concat(chunks).toString();
              if (res.statusCode >= 400) {
                let err = new Error(`API ${method} ${path}: ${res.statusCode}`);
                err.status = res.statusCode;
                err.body = raw;
                err.sqliteBusy = raw.includes("SQLITE_BUSY");
                if (err.sqliteBusy && retriesLeft > 0) {
                  let delay = Math.min(1e3 * Math.pow(2, attempt), 8e3);
                  if (this.logger) {
                    this.logger.debug(
                      `SQLITE_BUSY on ${method} ${path}, retry ${attempt + 1} in ${delay}ms`
                    );
                  }
                  setTimeout(() => {
                    this._doRequest(method, path, body, headers, retriesLeft - 1, attempt + 1).then(resolve, reject);
                  }, delay);
                  return;
                }
                reject(err);
                return;
              }
              if (!raw || raw.length === 0) {
                resolve(null);
                return;
              }
              try {
                resolve(JSON.parse(raw));
              } catch {
                resolve(raw);
              }
            });
          });
          req.on("error", (err) => {
            if (this.logger) {
              this.logger.debug(`API request failed: ${method} ${path}`, {
                error: err.message
              });
            }
            reject(err);
          });
          req.setTimeout(1e4, () => {
            req.destroy(new Error(`API timeout: ${method} ${path}`));
          });
          if (body)
            req.write(body);
          req.end();
        });
      }
    };
    module2.exports = { ApiClient };
  }
});

// src/store-adapter.js
var require_store_adapter = __commonJS({
  "src/store-adapter.js"(exports2, module2) {
    "use strict";
    var StoreAdapter = class {
      constructor(store, logger) {
        this.store = store;
        this.logger = logger;
        this._suppressChangeDetection = false;
      }
      _getState() {
        return this.store.getState();
      }
      // ------------------------------------------------------------------ Reads
      /**
       * Return all items as summaries (mirrors ApiClient.getItems format).
       */
      getAllItems() {
        let { items, photos } = this._getState();
        let result = [];
        for (let id2 of Object.keys(items)) {
          let item = items[id2];
          result.push({
            id: Number(id2),
            template: item.template,
            photos: item.photos || [],
            lists: item.lists || [],
            tags: item.tags || []
          });
        }
        return result;
      }
      /**
       * Assemble a fully-enriched item from the normalised Redux state.
       * Returns the same nested shape that SyncEngine.enrichItem() produced.
       */
      getItemFull(itemId) {
        let state = this._getState();
        let item = state.items[itemId];
        if (!item)
          return null;
        let enriched = {
          "@id": itemId,
          template: item.template,
          lists: item.lists || []
        };
        let meta = state.metadata[itemId];
        if (meta) {
          for (let [key, value] of Object.entries(meta)) {
            if (key === "id")
              continue;
            if (typeof value === "object" && value !== null) {
              enriched[key] = {
                "@value": value.text || "",
                "@type": value.type || ""
              };
            } else if (value != null) {
              enriched[key] = value;
            }
          }
        }
        let tagIds = item.tags || [];
        enriched.tag = [];
        for (let tid of tagIds) {
          let tag = state.tags[tid];
          if (tag) {
            enriched.tag.push({
              id: tid,
              name: tag.name,
              color: tag.color || null
            });
          }
        }
        enriched.photo = [];
        let photoIds = item.photos || [];
        for (let pid of photoIds) {
          let photo = state.photos[pid];
          if (!photo)
            continue;
          let ep = {
            "@id": pid,
            checksum: photo.checksum,
            note: [],
            selection: [],
            transcription: [],
            metadata: null
          };
          let photoMeta = state.metadata[pid];
          if (photoMeta) {
            ep.metadata = {};
            for (let [key, value] of Object.entries(photoMeta)) {
              if (key === "id")
                continue;
              ep.metadata[key] = value;
            }
          }
          for (let nid of photo.notes || []) {
            let note = state.notes[nid];
            if (!note)
              continue;
            let html = this._noteStateToHtml(note);
            ep.note.push({
              "@id": nid,
              text: note.text || "",
              html,
              language: note.language || null,
              photo: pid
            });
          }
          if (state.transcriptions) {
            for (let txid of photo.transcriptions || []) {
              let tx = state.transcriptions[txid];
              if (tx)
                ep.transcription.push(tx);
            }
          }
          for (let sid of photo.selections || []) {
            let sel = state.selections[sid];
            if (!sel)
              continue;
            let es = {
              "@id": sid,
              x: sel.x,
              y: sel.y,
              width: sel.width,
              height: sel.height,
              angle: sel.angle || 0,
              note: [],
              metadata: null,
              transcription: []
            };
            let selMeta = state.metadata[sid];
            if (selMeta) {
              es.metadata = {};
              for (let [key, value] of Object.entries(selMeta)) {
                if (key === "id")
                  continue;
                es.metadata[key] = value;
              }
            }
            for (let nid of sel.notes || []) {
              let note = state.notes[nid];
              if (!note)
                continue;
              let html = this._noteStateToHtml(note);
              es.note.push({
                "@id": nid,
                text: note.text || "",
                html,
                language: note.language || null,
                selection: sid
              });
            }
            if (state.transcriptions) {
              for (let txid of sel.transcriptions || []) {
                let tx = state.transcriptions[txid];
                if (tx)
                  es.transcription.push(tx);
              }
            }
            ep.selection.push(es);
          }
          enriched.photo.push(ep);
        }
        return enriched;
      }
      /**
       * Return all tags as an array of { id, name, color }.
       */
      getAllTags() {
        let { tags } = this._getState();
        return Object.values(tags || {}).map((t) => ({
          id: t.id,
          name: t.name,
          color: t.color || null
        }));
      }
      /**
       * Return all lists as an array of { id, name, parent }.
       */
      getAllLists() {
        let { lists } = this._getState();
        return Object.values(lists || {}).map((l) => ({
          id: l.id,
          name: l.name,
          parent: l.parent || null
        }));
      }
      /**
       * Check if the store is still usable (always true when we have a store ref).
       */
      ping() {
        return !!this.store;
      }
      // ----------------------------------------------------------- Writes (dispatch)
      /**
       * Create a selection on a photo.
       * Returns { id } of the created selection.
       */
      async createSelection({ photo, x, y, width, height, angle }) {
        let idsBefore = new Set(Object.keys(this._getState().selections));
        let action = this.store.dispatch({
          type: "selection.create",
          payload: { photo, x, y, width, height, angle: angle || 0 },
          meta: { cmd: "project" }
        });
        await this._waitForAction(action);
        let idsAfter = Object.keys(this._getState().selections);
        for (let id2 of idsAfter) {
          if (!idsBefore.has(id2)) {
            return { id: Number(id2), "@id": Number(id2) };
          }
        }
        return null;
      }
      /**
       * Create a note attached to a photo or selection.
       * The note.create command calls fromHTML() internally when state is null.
       * Returns { id } of the created note.
       */
      async createNote({ photo, selection, html, language }) {
        let idsBefore = new Set(Object.keys(this._getState().notes));
        let payload = { text: html || "" };
        if (photo)
          payload.photo = photo;
        if (selection)
          payload.selection = selection;
        if (language)
          payload.language = language;
        let action = this.store.dispatch({
          type: "note.create",
          payload,
          meta: { cmd: "project" }
        });
        await this._waitForAction(action);
        let idsAfter = Object.keys(this._getState().notes);
        for (let id2 of idsAfter) {
          if (!idsBefore.has(id2)) {
            return { id: Number(id2), "@id": Number(id2) };
          }
        }
        return null;
      }
      /**
       * Update a note's content.
       * Since ProseMirror state is needed for note.update and we only have HTML,
       * we delete the old note and recreate with new content.
       * Returns { id } of the new note.
       */
      async updateNote(id2, { html, language }) {
        let state = this._getState();
        let existing = state.notes[id2];
        if (!existing) {
          throw new Error(`Note ${id2} not found in store`);
        }
        let photo = existing.photo || void 0;
        let selection = existing.selection || void 0;
        await this.deleteNote(id2);
        return this.createNote({
          photo,
          selection,
          html,
          language: language || existing.language || null
        });
      }
      /**
       * Delete a note by ID.
       */
      async deleteNote(id2) {
        let action = this.store.dispatch({
          type: "note.delete",
          payload: { id: id2 },
          meta: { cmd: "project" }
        });
        await this._waitForAction(action);
      }
      /**
       * Add items to a list.
       */
      async addItemsToList(listId, itemIds) {
        let action = this.store.dispatch({
          type: "list.item.add",
          payload: { id: listId, items: Array.isArray(itemIds) ? itemIds : [itemIds] },
          meta: { cmd: "project", history: "add", search: true }
        });
        await this._waitForAction(action);
      }
      /**
       * Remove items from a list.
       */
      async removeItemsFromList(listId, itemIds) {
        let action = this.store.dispatch({
          type: "list.item.remove",
          payload: { id: listId, items: Array.isArray(itemIds) ? itemIds : [itemIds] },
          meta: { cmd: "project", history: "add", search: true }
        });
        await this._waitForAction(action);
      }
      // ------------------------------------------------------- Change detection
      /**
       * Subscribe to Redux state changes that are relevant to sync.
       * Calls `callback()` when any tracked slice changes, unless suppressed.
       * Returns an unsubscribe function.
       */
      subscribe(callback) {
        let prevState = this._getState();
        let slices = [
          "items",
          "photos",
          "selections",
          "notes",
          "metadata",
          "tags",
          "lists"
        ];
        return this.store.subscribe(() => {
          if (this._suppressChangeDetection)
            return;
          let state = this._getState();
          let changed = false;
          for (let slice of slices) {
            if (state[slice] !== prevState[slice]) {
              changed = true;
              break;
            }
          }
          prevState = state;
          if (changed) {
            callback();
          }
        });
      }
      /**
       * Suppress change detection (call before applying remote changes).
       */
      suppressChanges() {
        this._suppressChangeDetection = true;
      }
      /**
       * Resume change detection (call after applying remote changes).
       */
      resumeChanges() {
        this._suppressChangeDetection = false;
      }
      // -------------------------------------------------------- Action completion
      /**
       * Wait for a dispatched command to complete.
       * Watches the `activities` slice for the action's seq to be cleared.
       */
      _waitForAction(action, timeout = 15e3) {
        if (!action || !action.meta || !action.meta.seq) {
          return Promise.resolve();
        }
        let seq = action.meta.seq;
        return new Promise((resolve, reject) => {
          let timer = setTimeout(() => {
            unsub();
            this.logger.debug(`waitForAction: ${action.type} seq=${seq} timed out`);
            resolve();
          }, timeout);
          let unsub = this.store.subscribe(() => {
            let state2 = this._getState();
            if (!state2.activities || !state2.activities[seq]) {
              clearTimeout(timer);
              unsub();
              resolve();
            }
          });
          let state = this._getState();
          if (!state.activities || !state.activities[seq]) {
            clearTimeout(timer);
            unsub();
            resolve();
          }
        });
      }
      // --------------------------------------------------------- Note HTML helpers
      /**
       * Convert a Redux note (ProseMirror state JSON + text) to HTML.
       */
      _noteStateToHtml(note) {
        if (note.html)
          return note.html;
        if (note.state && note.state.doc) {
          return this._renderDoc(note.state.doc);
        }
        if (note.text) {
          return `<p>${this._esc(note.text)}</p>`;
        }
        return "";
      }
      _renderDoc(doc) {
        if (!doc || !doc.content)
          return "";
        return doc.content.map((n) => this._renderNode(n)).join("");
      }
      _renderNode(node) {
        if (!node)
          return "";
        let children = node.content ? node.content.map((n) => this._renderNode(n)).join("") : "";
        switch (node.type) {
          case "paragraph":
            return `<p>${children}</p>`;
          case "blockquote":
            return `<blockquote>${children}</blockquote>`;
          case "ordered_list":
            return `<ol>${children}</ol>`;
          case "bullet_list":
            return `<ul>${children}</ul>`;
          case "list_item":
            return `<li>${children}</li>`;
          case "heading": {
            let l = node.attrs && node.attrs.level || 1;
            return `<h${l}>${children}</h${l}>`;
          }
          case "hard_break":
            return "<br>";
          case "text": {
            let t = this._esc(node.text || "");
            if (node.marks) {
              for (let m of node.marks) {
                switch (m.type) {
                  case "bold":
                  case "strong":
                    t = `<strong>${t}</strong>`;
                    break;
                  case "italic":
                  case "em":
                    t = `<em>${t}</em>`;
                    break;
                  case "link":
                    t = `<a href="${this._esc(m.attrs && m.attrs.href || "")}">${t}</a>`;
                    break;
                  case "superscript":
                  case "sup":
                    t = `<sup>${t}</sup>`;
                    break;
                  case "subscript":
                  case "sub":
                    t = `<sub>${t}</sub>`;
                    break;
                  case "strikethrough":
                    t = `<s>${t}</s>`;
                    break;
                  case "underline":
                    t = `<u>${t}</u>`;
                    break;
                }
              }
            }
            return t;
          }
          default:
            return children;
        }
      }
      _esc(str) {
        return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
    };
    module2.exports = { StoreAdapter };
  }
});

// src/identity.js
var require_identity = __commonJS({
  "src/identity.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    function computeIdentity(item) {
      let checksums = extractChecksums(item);
      if (checksums.length > 0) {
        return hashChecksums(checksums);
      }
      return hashFallback(item);
    }
    function extractChecksums(item) {
      let checksums = [];
      let photos = item.photo || item["https://tropy.org/v1/tropy#photo"] || [];
      if (!Array.isArray(photos))
        photos = [photos];
      for (let photo of photos) {
        let checksum = photo.checksum || photo["https://tropy.org/v1/tropy#checksum"];
        if (checksum) {
          checksums.push(typeof checksum === "object" ? checksum["@value"] || String(checksum) : String(checksum));
        }
        let selections = photo.selection || photo["https://tropy.org/v1/tropy#selection"] || [];
        if (!Array.isArray(selections))
          selections = [selections];
        for (let sel of selections) {
          let sc = sel.checksum || sel["https://tropy.org/v1/tropy#checksum"];
          if (sc) {
            checksums.push(typeof sc === "object" ? sc["@value"] || String(sc) : String(sc));
          }
        }
      }
      return checksums;
    }
    function hashChecksums(checksums) {
      let sorted = checksums.slice().sort();
      return crypto.createHash("sha256").update(sorted.join(":")).digest("hex").slice(0, 32);
    }
    function hashFallback(item) {
      let template = item.template || item["https://tropy.org/v1/tropy#template"] || "";
      if (typeof template === "object")
        template = template["@id"] || "";
      let title = item["http://purl.org/dc/elements/1.1/title"] || item["http://purl.org/dc/terms/title"] || item["title"] || "";
      if (typeof title === "object")
        title = title["@value"] || "";
      let date = item["http://purl.org/dc/elements/1.1/date"] || item["http://purl.org/dc/terms/date"] || item["date"] || "";
      if (typeof date === "object")
        date = date["@value"] || "";
      let input = `${template}|${title}|${date}`;
      if (input === "||")
        return null;
      return crypto.createHash("sha256").update(input).digest("hex").slice(0, 32);
    }
    function computeSelectionKey(photoChecksum, sel) {
      let x = Math.round(sel.x || 0);
      let y = Math.round(sel.y || 0);
      let w = Math.round(sel.width || sel.w || 0);
      let h = Math.round(sel.height || sel.h || 0);
      return crypto.createHash("sha256").update(`sel:${photoChecksum}:${x}:${y}:${w}:${h}`).digest("hex").slice(0, 24);
    }
    function computeNoteKey(note, photoChecksum) {
      let text = note.text || "";
      let html = note.html || "";
      let parent = photoChecksum || note.photo || note.selection || "orphan";
      let content = (html || text).slice(0, 200);
      return crypto.createHash("sha256").update(`note:${parent}:${content}`).digest("hex").slice(0, 24);
    }
    function computeTranscriptionKey(photoChecksum, idx, selKey) {
      let parent = selKey ? `${photoChecksum}:${selKey}` : photoChecksum;
      return crypto.createHash("sha256").update(`tx:${parent}:${idx}`).digest("hex").slice(0, 24);
    }
    function buildIdentityIndex(items) {
      let index = /* @__PURE__ */ new Map();
      for (let item of items) {
        let id2 = computeIdentity(item);
        if (id2) {
          index.set(id2, {
            localId: item["@id"] || item.id,
            item
          });
        }
      }
      return index;
    }
    function findLocalMatch(identity2, localIndex) {
      return localIndex.get(identity2) || null;
    }
    function buildPhotoChecksumMap(item) {
      let map2 = /* @__PURE__ */ new Map();
      let photos = item.photo || item["https://tropy.org/v1/tropy#photo"] || [];
      if (!Array.isArray(photos))
        photos = [photos];
      for (let photo of photos) {
        let id2 = photo["@id"] || photo.id;
        let checksum = photo.checksum || photo["https://tropy.org/v1/tropy#checksum"];
        if (id2 && checksum) {
          if (typeof checksum === "object")
            checksum = checksum["@value"] || String(checksum);
          map2.set(id2, String(checksum));
        }
      }
      return map2;
    }
    module2.exports = {
      computeIdentity,
      extractChecksums,
      buildIdentityIndex,
      findLocalMatch,
      computeSelectionKey,
      computeNoteKey,
      computeTranscriptionKey,
      buildPhotoChecksumMap
    };
  }
});

// src/crdt-schema.js
var require_crdt_schema = __commonJS({
  "src/crdt-schema.js"(exports2, module2) {
    "use strict";
    var Y = (init_yjs(), __toCommonJS(yjs_exports));
    var ITEM_SECTIONS = [
      "metadata",
      "tags",
      "notes",
      "photos",
      "selections",
      "selectionMeta",
      "selectionNotes",
      "transcriptions",
      "lists"
    ];
    function getItemAnnotations(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap) {
        itemMap = new Y.Map();
        for (let section of ITEM_SECTIONS) {
          itemMap.set(section, new Y.Map());
        }
        annotations.set(identity2, itemMap);
      } else {
        for (let section of ITEM_SECTIONS) {
          if (!itemMap.get(section)) {
            itemMap.set(section, new Y.Map());
          }
        }
      }
      let result = {};
      for (let section of ITEM_SECTIONS) {
        result[section] = itemMap.get(section);
      }
      return result;
    }
    function setMetadata(doc, identity2, propertyUri, value, author) {
      let { metadata } = getItemAnnotations(doc, identity2);
      metadata.set(propertyUri, {
        text: value.text || "",
        type: value.type || "http://www.w3.org/2001/XMLSchema#string",
        language: value.language || null,
        author,
        ts: Date.now()
      });
    }
    function getMetadata(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let metadata = itemMap.get("metadata");
      if (!metadata)
        return {};
      let result = {};
      metadata.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function setTag(doc, identity2, tag, author) {
      let { tags } = getItemAnnotations(doc, identity2);
      let existing = tags.get(tag.name);
      if (!existing || existing.deleted || tag.color !== existing.color) {
        tags.set(tag.name, {
          name: tag.name,
          color: tag.color || null,
          author,
          ts: Date.now()
        });
      }
    }
    function removeTag(doc, identity2, tagName, author) {
      let { tags } = getItemAnnotations(doc, identity2);
      let existing = tags.get(tagName);
      if (existing && !existing.deleted) {
        tags.set(tagName, {
          ...existing,
          deleted: true,
          author,
          ts: Date.now()
        });
      }
    }
    function getTags(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return [];
      let tags = itemMap.get("tags");
      if (!tags)
        return [];
      let result = [];
      tags.forEach((value, key) => {
        result.push(value);
      });
      return result;
    }
    function getActiveTags(doc, identity2) {
      return getTags(doc, identity2).filter((t) => !t.deleted);
    }
    function getDeletedTags(doc, identity2) {
      return getTags(doc, identity2).filter((t) => t.deleted);
    }
    function setNote(doc, identity2, noteKey, note, author) {
      let { notes } = getItemAnnotations(doc, identity2);
      notes.set(noteKey, {
        noteKey,
        text: note.text || "",
        html: note.html || "",
        language: note.language || null,
        photo: note.photo || null,
        selection: note.selection || null,
        author,
        ts: Date.now()
      });
    }
    function removeNote(doc, identity2, noteKey, author) {
      let { notes } = getItemAnnotations(doc, identity2);
      let existing = notes.get(noteKey);
      if (existing && !existing.deleted) {
        notes.set(noteKey, {
          ...existing,
          deleted: true,
          author,
          ts: Date.now()
        });
      }
    }
    function getNotes(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let notes = itemMap.get("notes");
      if (!notes)
        return {};
      let result = {};
      notes.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function getActiveNotes(doc, identity2) {
      let all2 = getNotes(doc, identity2);
      let result = {};
      for (let [key, val] of Object.entries(all2)) {
        if (!val.deleted)
          result[key] = val;
      }
      return result;
    }
    function setPhotoMetadata(doc, identity2, checksum, propertyUri, value, author) {
      let { photos } = getItemAnnotations(doc, identity2);
      let photoMap = photos.get(checksum);
      if (!photoMap) {
        photoMap = new Y.Map();
        photoMap.set("metadata", new Y.Map());
        photos.set(checksum, photoMap);
      }
      let metadata = photoMap.get("metadata");
      if (!metadata) {
        metadata = new Y.Map();
        photoMap.set("metadata", metadata);
      }
      metadata.set(propertyUri, {
        text: value.text || "",
        type: value.type || "http://www.w3.org/2001/XMLSchema#string",
        language: value.language || null,
        author,
        ts: Date.now()
      });
    }
    function getPhotoMetadata(doc, identity2, checksum) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let photos = itemMap.get("photos");
      if (!photos)
        return {};
      let photoMap = photos.get(checksum);
      if (!photoMap)
        return {};
      let metadata = photoMap.get("metadata");
      if (!metadata)
        return {};
      let result = {};
      metadata.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function getAllPhotoChecksums(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return [];
      let photos = itemMap.get("photos");
      if (!photos)
        return [];
      let result = [];
      photos.forEach((_, checksum) => {
        result.push(checksum);
      });
      return result;
    }
    function setSelection(doc, identity2, selKey, selection, author) {
      let { selections } = getItemAnnotations(doc, identity2);
      let w = selection.width ?? selection.w;
      let h = selection.height ?? selection.h;
      if (w == null || h == null || w <= 0 || h <= 0)
        return;
      selections.set(selKey, {
        selKey,
        x: selection.x ?? 0,
        y: selection.y ?? 0,
        w,
        h,
        angle: selection.angle ?? 0,
        photo: selection.photo || null,
        author,
        ts: Date.now()
      });
    }
    function removeSelection(doc, identity2, selKey, author) {
      let { selections } = getItemAnnotations(doc, identity2);
      let existing = selections.get(selKey);
      if (existing && !existing.deleted) {
        selections.set(selKey, {
          ...existing,
          deleted: true,
          author,
          ts: Date.now()
        });
      }
    }
    function getSelections(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let selections = itemMap.get("selections");
      if (!selections)
        return {};
      let result = {};
      selections.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function getActiveSelections(doc, identity2) {
      let all2 = getSelections(doc, identity2);
      let result = {};
      for (let [key, val] of Object.entries(all2)) {
        if (!val.deleted)
          result[key] = val;
      }
      return result;
    }
    function setSelectionMeta(doc, identity2, selKey, propertyUri, value, author) {
      let { selectionMeta } = getItemAnnotations(doc, identity2);
      let key = `${selKey}:${propertyUri}`;
      selectionMeta.set(key, {
        text: value.text || "",
        type: value.type || "http://www.w3.org/2001/XMLSchema#string",
        language: value.language || null,
        author,
        ts: Date.now()
      });
    }
    function getSelectionMeta(doc, identity2, selKey) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let selectionMeta = itemMap.get("selectionMeta");
      if (!selectionMeta)
        return {};
      let prefix = `${selKey}:`;
      let result = {};
      selectionMeta.forEach((value, key) => {
        if (key.startsWith(prefix)) {
          let propUri = key.slice(prefix.length);
          result[propUri] = value;
        }
      });
      return result;
    }
    function setSelectionNote(doc, identity2, selKey, noteKey, note, author) {
      let { selectionNotes } = getItemAnnotations(doc, identity2);
      let key = `${selKey}:${noteKey}`;
      selectionNotes.set(key, {
        noteKey,
        selKey,
        text: note.text || "",
        html: note.html || "",
        language: note.language || null,
        author,
        ts: Date.now()
      });
    }
    function removeSelectionNote(doc, identity2, selKey, noteKey, author) {
      let { selectionNotes } = getItemAnnotations(doc, identity2);
      let key = `${selKey}:${noteKey}`;
      let existing = selectionNotes.get(key);
      if (existing && !existing.deleted) {
        selectionNotes.set(key, {
          ...existing,
          deleted: true,
          author,
          ts: Date.now()
        });
      }
    }
    function getSelectionNotes(doc, identity2, selKey) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let selectionNotes = itemMap.get("selectionNotes");
      if (!selectionNotes)
        return {};
      let prefix = `${selKey}:`;
      let result = {};
      selectionNotes.forEach((value, key) => {
        if (key.startsWith(prefix)) {
          if (!value.deleted)
            result[key] = value;
        }
      });
      return result;
    }
    function setTranscription(doc, identity2, txKey, transcription, author) {
      let { transcriptions } = getItemAnnotations(doc, identity2);
      transcriptions.set(txKey, {
        txKey,
        text: transcription.text || "",
        data: transcription.data || null,
        photo: transcription.photo || null,
        selection: transcription.selection || null,
        author,
        ts: Date.now()
      });
    }
    function removeTranscription(doc, identity2, txKey, author) {
      let { transcriptions } = getItemAnnotations(doc, identity2);
      let existing = transcriptions.get(txKey);
      if (existing && !existing.deleted) {
        transcriptions.set(txKey, {
          ...existing,
          deleted: true,
          author,
          ts: Date.now()
        });
      }
    }
    function getTranscriptions(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let transcriptions = itemMap.get("transcriptions");
      if (!transcriptions)
        return {};
      let result = {};
      transcriptions.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function getActiveTranscriptions(doc, identity2) {
      let all2 = getTranscriptions(doc, identity2);
      let result = {};
      for (let [key, val] of Object.entries(all2)) {
        if (!val.deleted)
          result[key] = val;
      }
      return result;
    }
    function setListMembership(doc, identity2, listName, author) {
      let { lists } = getItemAnnotations(doc, identity2);
      lists.set(listName, {
        name: listName,
        member: true,
        author,
        ts: Date.now()
      });
    }
    function removeListMembership(doc, identity2, listName, author) {
      let { lists } = getItemAnnotations(doc, identity2);
      let existing = lists.get(listName);
      if (existing && !existing.deleted) {
        lists.set(listName, {
          ...existing,
          member: false,
          deleted: true,
          author,
          ts: Date.now()
        });
      }
    }
    function getLists(doc, identity2) {
      let annotations = doc.getMap("annotations");
      let itemMap = annotations.get(identity2);
      if (!itemMap)
        return {};
      let lists = itemMap.get("lists");
      if (!lists)
        return {};
      let result = {};
      lists.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function getActiveLists(doc, identity2) {
      let all2 = getLists(doc, identity2);
      let result = {};
      for (let [key, val] of Object.entries(all2)) {
        if (!val.deleted && val.member)
          result[key] = val;
      }
      return result;
    }
    function getSnapshot(doc) {
      let annotations = doc.getMap("annotations");
      let result = {};
      annotations.forEach((itemMap, identity2) => {
        let item = {};
        for (let section of ITEM_SECTIONS) {
          let map2 = itemMap.get(section);
          if (!map2) {
            item[section] = {};
            continue;
          }
          if (section === "photos") {
            let photosObj = {};
            map2.forEach((photoMap, checksum) => {
              let metaMap = photoMap.get("metadata");
              let meta = {};
              if (metaMap) {
                metaMap.forEach((v, k) => {
                  if (v && typeof v === "object") {
                    let { ts, author, ...content } = v;
                    meta[k] = content;
                  } else {
                    meta[k] = v;
                  }
                });
              }
              photosObj[checksum] = { metadata: meta };
            });
            item[section] = photosObj;
          } else {
            let obj = {};
            map2.forEach((v, k) => {
              if (v && typeof v === "object") {
                let { ts, author, ...content } = v;
                obj[k] = content;
              } else {
                obj[k] = v;
              }
            });
            item[section] = obj;
          }
        }
        result[identity2] = item;
      });
      return result;
    }
    function registerUser(doc, clientId, userId) {
      let users = doc.getMap("users");
      users.set(String(clientId), {
        userId: userId || `user-${clientId}`,
        name: userId || `user-${clientId}`,
        joinedAt: Date.now(),
        lastSeen: Date.now()
      });
    }
    function deregisterUser(doc, clientId) {
      let users = doc.getMap("users");
      users.delete(String(clientId));
    }
    function heartbeat(doc, clientId) {
      let users = doc.getMap("users");
      let user = users.get(String(clientId));
      if (user) {
        users.set(String(clientId), { ...user, lastSeen: Date.now() });
      }
    }
    function getUsers(doc) {
      let users = doc.getMap("users");
      let result = [];
      users.forEach((user, clientId) => {
        result.push({ clientId, ...user });
      });
      return result;
    }
    function setRoomConfig(doc, config) {
      let room = doc.getMap("room");
      for (let [key, value] of Object.entries(config)) {
        room.set(key, value);
      }
    }
    function getRoomConfig(doc) {
      let room = doc.getMap("room");
      let result = {};
      room.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    function observeAnnotations(doc, callback) {
      let annotations = doc.getMap("annotations");
      let handler = (events) => {
        let changed = /* @__PURE__ */ new Set();
        events.forEach((event) => {
          if (event.target === annotations) {
            event.changes.keys.forEach((change, key) => {
              changed.add(key);
            });
          }
        });
        if (changed.size > 0)
          callback(Array.from(changed));
      };
      annotations.observeDeep(handler);
      return () => annotations.unobserveDeep(handler);
    }
    function observeAnnotationsDeep(doc, callback, skipOrigin) {
      let annotations = doc.getMap("annotations");
      let handler = (events, transaction) => {
        if (skipOrigin != null && transaction.origin === skipOrigin)
          return;
        let changes = [];
        for (let event of events) {
          let path = event.path;
          if (path.length >= 2) {
            let identity2 = path[0];
            let type = path[1];
            changes.push({ identity: identity2, type, event });
          } else if (event.target === annotations) {
            event.changes.keys.forEach((change, key) => {
              changes.push({ identity: key, type: "item", event });
            });
          }
        }
        if (changes.length > 0)
          callback(changes);
      };
      annotations.observeDeep(handler);
      return () => annotations.unobserveDeep(handler);
    }
    module2.exports = {
      ITEM_SECTIONS,
      getItemAnnotations,
      // Metadata
      setMetadata,
      getMetadata,
      // Tags
      setTag,
      removeTag,
      getTags,
      getActiveTags,
      getDeletedTags,
      // Notes
      setNote,
      removeNote,
      getNotes,
      getActiveNotes,
      // Photos
      setPhotoMetadata,
      getPhotoMetadata,
      getAllPhotoChecksums,
      // Selections
      setSelection,
      removeSelection,
      getSelections,
      getActiveSelections,
      // Selection metadata
      setSelectionMeta,
      getSelectionMeta,
      // Selection notes
      setSelectionNote,
      removeSelectionNote,
      getSelectionNotes,
      // Transcriptions
      setTranscription,
      removeTranscription,
      getTranscriptions,
      getActiveTranscriptions,
      // Lists
      setListMembership,
      removeListMembership,
      getLists,
      getActiveLists,
      // Snapshot
      getSnapshot,
      // Users
      registerUser,
      deregisterUser,
      heartbeat,
      getUsers,
      // Room
      setRoomConfig,
      getRoomConfig,
      // Observers
      observeAnnotations,
      observeAnnotationsDeep
    };
  }
});

// src/backup.js
var require_backup = __commonJS({
  "src/backup.js"(exports2, module2) {
    "use strict";
    var fs = require("fs");
    var path = require("path");
    var os = require("os");
    var DEFAULT_OPTIONS = {
      maxBackups: 10,
      maxNoteSize: 1 * 1024 * 1024,
      // 1 MB
      maxMetadataSize: 64 * 1024,
      // 64 KB
      tombstoneFloodThreshold: 0.5
      // 50%
    };
    var BackupManager = class {
      constructor(room, api, logger, options = {}) {
        this.room = room;
        this.api = api;
        this.logger = logger;
        this.options = { ...DEFAULT_OPTIONS, ...options };
        this.backupDir = path.join(os.homedir(), ".troparcel", "backups", this.sanitizeDir(room));
        this._fileCounter = 0;
      }
      /**
       * Sanitize a room name for use as a directory name.
       */
      sanitizeDir(name) {
        return name.replace(/[^a-zA-Z0-9_.-]/g, "_").slice(0, 128) || "default";
      }
      /**
       * Ensure the backup directory exists.
       */
      ensureDir() {
        fs.mkdirSync(this.backupDir, { recursive: true });
      }
      /**
       * Save a pre-apply snapshot of items that are about to be modified.
       * Uses millisecond timestamps + counter to prevent collisions (R8).
       *
       * @param {Object[]} itemSnapshots - array of { identity, localId, metadata, tags, notes, selections, transcriptions }
       * @returns {string} path to the backup file
       */
      saveSnapshot(itemSnapshots) {
        this.ensureDir();
        let ts = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
        this._fileCounter++;
        let filename = `${ts}-${String(this._fileCounter).padStart(4, "0")}.json`;
        let filepath = path.join(this.backupDir, filename);
        let data = {
          room: this.room,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          version: "3.1",
          items: itemSnapshots
        };
        fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
        this.logger.info(`Backup saved: ${filepath}`, { items: itemSnapshots.length });
        this.pruneOldBackups();
        return filepath;
      }
      /**
       * Remove old backups beyond the retention limit.
       */
      pruneOldBackups() {
        try {
          let files = fs.readdirSync(this.backupDir).filter((f) => f.endsWith(".json")).sort();
          while (files.length > this.options.maxBackups) {
            let oldest = files.shift();
            fs.unlinkSync(path.join(this.backupDir, oldest));
            this.logger.debug(`Pruned old backup: ${oldest}`);
          }
        } catch (err) {
          this.logger.debug("Failed to prune backups", { error: err.message });
        }
      }
      /**
       * Capture the current state of a local item for backup purposes.
       *
       * @param {number} localId
       * @param {string} identity
       * @returns {Object} snapshot
       */
      async captureItemState(localId, identity2) {
        let snapshot2 = { identity: identity2, localId };
        try {
          snapshot2.metadata = await this.api.getMetadata(localId);
        } catch {
          snapshot2.metadata = null;
        }
        try {
          snapshot2.tags = await this.api.getItemTags(localId);
        } catch {
          snapshot2.tags = [];
        }
        snapshot2.photos = [];
        try {
          let photos = await this.api.getPhotos(localId);
          if (Array.isArray(photos)) {
            for (let pid of photos) {
              let photoId = typeof pid === "object" ? pid.id : pid;
              try {
                let photo = await this.api.getPhoto(photoId);
                if (photo)
                  snapshot2.photos.push(photo);
              } catch {
              }
            }
          }
        } catch {
        }
        return snapshot2;
      }
      /**
       * Validate inbound CRDT data before applying it locally.
       * Returns { valid: boolean, warnings: string[] }
       */
      validateInbound(itemIdentity, crdtItem) {
        let warnings = [];
        if (crdtItem.notes) {
          for (let [key, note] of Object.entries(crdtItem.notes)) {
            if (note.deleted)
              continue;
            let size2 = (note.html || "").length + (note.text || "").length;
            if (size2 > this.options.maxNoteSize) {
              warnings.push(`Note ${key} exceeds max size (${size2} > ${this.options.maxNoteSize})`);
            }
          }
        }
        if (crdtItem.selectionNotes) {
          for (let [key, note] of Object.entries(crdtItem.selectionNotes)) {
            if (note.deleted)
              continue;
            let size2 = (note.html || "").length + (note.text || "").length;
            if (size2 > this.options.maxNoteSize) {
              warnings.push(`Selection note ${key} exceeds max size (${size2} > ${this.options.maxNoteSize})`);
            }
          }
        }
        if (crdtItem.transcriptions) {
          for (let [key, tx] of Object.entries(crdtItem.transcriptions)) {
            if (tx.deleted)
              continue;
            let size2 = (tx.text || "").length + JSON.stringify(tx.data || "").length;
            if (size2 > this.options.maxNoteSize) {
              warnings.push(`Transcription ${key} exceeds max size (${size2} > ${this.options.maxNoteSize})`);
            }
          }
        }
        if (crdtItem.metadata) {
          for (let [key, val] of Object.entries(crdtItem.metadata)) {
            let size2 = (val.text || "").length;
            if (size2 > this.options.maxMetadataSize) {
              warnings.push(`Metadata ${key} exceeds max size (${size2} > ${this.options.maxMetadataSize})`);
            }
          }
        }
        let totalEntries = 0;
        let tombstoned = 0;
        for (let section of ["tags", "notes", "selectionNotes", "selections", "transcriptions", "lists"]) {
          let data = crdtItem[section];
          if (data && typeof data === "object") {
            for (let val of Object.values(data)) {
              totalEntries++;
              if (val && val.deleted)
                tombstoned++;
            }
          }
        }
        if (totalEntries > 0 && tombstoned / totalEntries > this.options.tombstoneFloodThreshold) {
          warnings.push(
            `Tombstone flood: ${tombstoned}/${totalEntries} entries deleted (${Math.round(tombstoned / totalEntries * 100)}% > ${this.options.tombstoneFloodThreshold * 100}% threshold)`
          );
        }
        return {
          valid: warnings.length === 0,
          warnings
        };
      }
      /**
       * Check if a remote value should overwrite a local value.
       * Prevents empty remote from overwriting non-empty local unless tombstoned.
       */
      shouldOverwrite(localValue, remoteValue) {
        if (remoteValue && remoteValue.deleted)
          return true;
        if ((!remoteValue || !remoteValue.text) && localValue && localValue.text)
          return false;
        return true;
      }
      /**
       * Rollback: replay a backup file into Tropy via the API (R4).
       * Restores metadata, tags, and notes for all items in the backup.
       *
       * @param {string} backupPath - path to the backup JSON file
       * @returns {Object} { restored: number, errors: string[] }
       */
      async rollback(backupPath) {
        let data = JSON.parse(fs.readFileSync(backupPath, "utf8"));
        let restored = 0;
        let errors = [];
        for (let item of data.items) {
          try {
            if (item.metadata) {
              try {
                await this.api.saveMetadata(item.localId, item.metadata);
              } catch (err) {
                errors.push(`metadata for ${item.localId}: ${err.message}`);
              }
            }
            if (item.tags && Array.isArray(item.tags)) {
              try {
                let tagIds = item.tags.map((t) => t.id || t.tag_id).filter(Boolean);
                if (tagIds.length > 0) {
                  await this.api.addTagsToItem(item.localId, tagIds);
                }
              } catch (err) {
                errors.push(`tags for ${item.localId}: ${err.message}`);
              }
            }
            if (item.photos && Array.isArray(item.photos)) {
              for (let photo of item.photos) {
                let noteIds = photo.notes || [];
                for (let noteId of noteIds) {
                  try {
                    let note = await this.api.getNote(noteId, "json");
                    if (note && note.html) {
                      await this.api.updateNote(noteId, { html: note.html });
                    }
                  } catch (err) {
                    errors.push(`note ${noteId}: ${err.message}`);
                  }
                }
                let selIds = photo.selections || [];
                for (let selId of selIds) {
                  try {
                    let sel = await this.api.getSelection(selId);
                    if (sel) {
                      await this.api.updateSelection(selId, {
                        x: sel.x,
                        y: sel.y,
                        width: sel.width,
                        height: sel.height,
                        angle: sel.angle || 0
                      });
                    }
                  } catch (err) {
                    errors.push(`selection ${selId}: ${err.message}`);
                  }
                }
              }
            }
            restored++;
          } catch (err) {
            errors.push(`Failed to restore item ${item.localId}: ${err.message}`);
          }
        }
        this.logger.info(`Rollback complete: ${restored} items restored`, {
          backup: backupPath,
          errors: errors.length
        });
        return { restored, errors };
      }
      /**
       * List available backups for this room.
       * @returns {string[]} backup file paths, newest first
       */
      listBackups() {
        try {
          return fs.readdirSync(this.backupDir).filter((f) => f.endsWith(".json")).sort().reverse().map((f) => path.join(this.backupDir, f));
        } catch {
          return [];
        }
      }
    };
    module2.exports = { BackupManager };
  }
});

// src/vault.js
var require_vault = __commonJS({
  "src/vault.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var MAX_PUSHED_ITEMS = 5e3;
    var MAX_APPLIED_KEYS = 5e4;
    var MAX_ID_MAPPINGS = 5e4;
    var SyncVault = class {
      constructor() {
        this.lastCRDTHash = null;
        this.lastBackupHash = null;
        this.pushedHashes = /* @__PURE__ */ new Map();
        this.appliedNoteKeys = /* @__PURE__ */ new Set();
        this.appliedSelectionKeys = /* @__PURE__ */ new Set();
        this.appliedTranscriptionKeys = /* @__PURE__ */ new Set();
        this.noteIdToCrdtKey = /* @__PURE__ */ new Map();
        this.crdtKeyToNoteId = /* @__PURE__ */ new Map();
        this.txIdToCrdtKey = /* @__PURE__ */ new Map();
        this.crdtKeyToTxId = /* @__PURE__ */ new Map();
        this._cachedAnnotationCount = 0;
      }
      /**
       * Check if the CRDT snapshot has changed since last check.
       * Returns true if changed (or first call), false if identical.
       */
      hasCRDTChanged(snapshot2) {
        let hash = this.hashObject(snapshot2);
        if (hash === this.lastCRDTHash)
          return false;
        this.lastCRDTHash = hash;
        return true;
      }
      /**
       * Check if backup content differs from the last saved backup.
       * Returns true if a new backup should be saved.
       */
      shouldBackup(itemSnapshots) {
        let hash = this.hashObject(itemSnapshots);
        if (hash === this.lastBackupHash)
          return false;
        this.lastBackupHash = hash;
        return true;
      }
      /**
       * Check if a local item has changed since it was last pushed.
       * Returns true if the item should be re-pushed.
       */
      hasItemChanged(identity2, item) {
        let hash = this.hashObject(item);
        let last2 = this.pushedHashes.get(identity2);
        return last2 !== hash;
      }
      /**
       * Record that an item was pushed to the CRDT.
       */
      markPushed(identity2, item) {
        this._evictIfNeeded(this.pushedHashes, MAX_PUSHED_ITEMS);
        this.pushedHashes.set(identity2, this.hashObject(item));
      }
      // --- Stable note identity (C1) ---
      /**
       * Get or create a stable CRDT key for a local note.
       * If the note was previously pushed, returns the same key.
       * If new, computes a content-based key and stores the mapping.
       *
       * @param {string|number} localNoteId - local DB ID of the note
       * @param {string} contentKey - content-based key for first-time matching
       * @returns {string} stable CRDT key
       */
      getNoteKey(localNoteId, contentKey) {
        let id2 = String(localNoteId);
        let existing = this.noteIdToCrdtKey.get(id2);
        if (existing)
          return existing;
        this._evictIfNeeded(this.noteIdToCrdtKey, MAX_ID_MAPPINGS);
        this.noteIdToCrdtKey.set(id2, contentKey);
        this.crdtKeyToNoteId.set(contentKey, id2);
        return contentKey;
      }
      /**
       * Record that a remote CRDT note was applied locally.
       * Stores the reverse mapping so we can update rather than re-create.
       */
      mapAppliedNote(crdtKey, localNoteId) {
        let id2 = String(localNoteId);
        this._evictIfNeeded(this.crdtKeyToNoteId, MAX_ID_MAPPINGS);
        this.crdtKeyToNoteId.set(crdtKey, id2);
        this.noteIdToCrdtKey.set(id2, crdtKey);
      }
      /**
       * Get the local note ID for a CRDT key (for updates instead of re-creates).
       */
      getLocalNoteId(crdtKey) {
        return this.crdtKeyToNoteId.get(crdtKey) || null;
      }
      // --- Stable transcription identity (C3) ---
      getTxKey(localTxId, contentKey) {
        let id2 = String(localTxId);
        let existing = this.txIdToCrdtKey.get(id2);
        if (existing)
          return existing;
        this._evictIfNeeded(this.txIdToCrdtKey, MAX_ID_MAPPINGS);
        this.txIdToCrdtKey.set(id2, contentKey);
        this.crdtKeyToTxId.set(contentKey, id2);
        return contentKey;
      }
      mapAppliedTranscription(crdtKey, localTxId) {
        let id2 = String(localTxId);
        this._evictIfNeeded(this.crdtKeyToTxId, MAX_ID_MAPPINGS);
        this.crdtKeyToTxId.set(crdtKey, id2);
        this.txIdToCrdtKey.set(id2, crdtKey);
      }
      getLocalTxId(crdtKey) {
        return this.crdtKeyToTxId.get(crdtKey) || null;
      }
      // --- Annotation count cache (P5) ---
      updateAnnotationCount(count) {
        this._cachedAnnotationCount = count;
      }
      get annotationCount() {
        return this._cachedAnnotationCount;
      }
      // --- Hashing ---
      /**
       * Fast content hash using SHA-256 (truncated).
       * Uses JSON.stringify with sorted keys for determinism.
       */
      hashObject(obj) {
        let str = this._sortedStringify(obj);
        return crypto.createHash("sha256").update(str).digest("hex").slice(0, 16);
      }
      /**
       * Deterministic JSON stringification with sorted keys.
       * Uses an iterative approach with a stack to avoid deep recursion
       * and excessive string concatenation on large objects (P7).
       */
      _sortedStringify(obj) {
        return JSON.stringify(obj, (key, value) => {
          if (value && typeof value === "object" && !Array.isArray(value)) {
            let sorted = {};
            for (let k of Object.keys(value).sort()) {
              sorted[k] = value[k];
            }
            return sorted;
          }
          return value;
        });
      }
      // --- Pruning (R7) ---
      /**
       * Evict oldest entries when a Map exceeds maxSize.
       * Uses insertion-order property of Maps (first inserted = first iterated).
       */
      _evictIfNeeded(map2, maxSize) {
        if (map2.size < maxSize)
          return;
        let toRemove = Math.floor(maxSize * 0.2);
        let iter = map2.keys();
        for (let i = 0; i < toRemove; i++) {
          let next = iter.next();
          if (next.done)
            break;
          map2.delete(next.value);
        }
      }
      /**
       * Prune applied-key Sets (R7).
       * Called periodically to prevent unbounded growth.
       */
      pruneAppliedKeys() {
        if (this.appliedNoteKeys.size > MAX_APPLIED_KEYS) {
          this.appliedNoteKeys = this._truncateSet(this.appliedNoteKeys, MAX_APPLIED_KEYS);
        }
        if (this.appliedSelectionKeys.size > MAX_APPLIED_KEYS) {
          this.appliedSelectionKeys = this._truncateSet(this.appliedSelectionKeys, MAX_APPLIED_KEYS);
        }
        if (this.appliedTranscriptionKeys.size > MAX_APPLIED_KEYS) {
          this.appliedTranscriptionKeys = this._truncateSet(this.appliedTranscriptionKeys, MAX_APPLIED_KEYS);
        }
      }
      /**
       * Keep the newest entries in a Set by discarding the oldest half.
       */
      _truncateSet(set, maxSize) {
        let arr = Array.from(set);
        let keep = arr.slice(arr.length - maxSize);
        return new Set(keep);
      }
      /**
       * Clear all tracked state. Called on engine stop.
       */
      clear() {
        this.lastCRDTHash = null;
        this.lastBackupHash = null;
        this.pushedHashes.clear();
        this.appliedNoteKeys.clear();
        this.appliedSelectionKeys.clear();
        this.appliedTranscriptionKeys.clear();
        this.noteIdToCrdtKey.clear();
        this.crdtKeyToNoteId.clear();
        this.txIdToCrdtKey.clear();
        this.crdtKeyToTxId.clear();
        this._cachedAnnotationCount = 0;
      }
    };
    module2.exports = { SyncVault };
  }
});

// src/sanitize.js
var require_sanitize = __commonJS({
  "src/sanitize.js"(exports2, module2) {
    "use strict";
    var SAFE_TAGS = /* @__PURE__ */ new Set([
      "p",
      "br",
      "em",
      "i",
      "strong",
      "b",
      "u",
      "s",
      "a",
      "ul",
      "ol",
      "li",
      "blockquote",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "code",
      "pre",
      "sup",
      "sub",
      "span",
      "div"
    ]);
    var DANGEROUS_TAGS = /* @__PURE__ */ new Set([
      "script",
      "style",
      "iframe",
      "object",
      "embed",
      "form",
      "input",
      "textarea",
      "select",
      "button",
      "link",
      "meta",
      "base",
      "applet",
      "math",
      "svg",
      "template",
      "noscript",
      "xmp",
      "listing",
      "plaintext",
      "noembed",
      "noframes"
    ]);
    var SAFE_ATTRS = {
      "a": /* @__PURE__ */ new Set(["href", "title"]),
      "*": /* @__PURE__ */ new Set(["class"])
    };
    var SAFE_PROTOCOLS = /* @__PURE__ */ new Set(["http:", "https:", "mailto:"]);
    function sanitizeHtml(html) {
      if (!html || typeof html !== "string")
        return "";
      let result = "";
      let i = 0;
      let len = html.length;
      while (i < len) {
        let tagStart = html.indexOf("<", i);
        if (tagStart === -1) {
          result += html.slice(i);
          break;
        }
        if (tagStart > i) {
          result += html.slice(i, tagStart);
        }
        if (html.slice(tagStart, tagStart + 4) === "<!--") {
          let commentEnd = html.indexOf("-->", tagStart + 4);
          i = commentEnd === -1 ? len : commentEnd + 3;
          continue;
        }
        let parsed = parseTag(html, tagStart);
        if (!parsed) {
          result += "&lt;";
          i = tagStart + 1;
          continue;
        }
        let { tagName, isClosing, isSelfClosing, attrs, end } = parsed;
        if (DANGEROUS_TAGS.has(tagName) && !isClosing) {
          let closePattern = "</" + tagName;
          let searchFrom = end;
          let closeIdx = -1;
          while (searchFrom < len) {
            let candidate = html.indexOf("</", searchFrom);
            if (candidate === -1)
              break;
            let rest = html.slice(candidate + 2, candidate + 2 + tagName.length + 1);
            if (rest.toLowerCase().startsWith(tagName) && (rest[tagName.length] === ">" || /\s/.test(rest[tagName.length]))) {
              closeIdx = candidate;
              break;
            }
            searchFrom = candidate + 2;
          }
          if (closeIdx !== -1) {
            let closeEnd = html.indexOf(">", closeIdx);
            i = closeEnd === -1 ? len : closeEnd + 1;
          } else {
            i = len;
          }
          continue;
        }
        if (!SAFE_TAGS.has(tagName)) {
          i = end;
          continue;
        }
        if (isClosing) {
          result += `</${tagName}>`;
        } else {
          let safeAttrs = sanitizeTagAttributes(attrs, tagName);
          result += `<${tagName}${safeAttrs}${isSelfClosing ? " /" : ""}>`;
        }
        i = end;
      }
      return result;
    }
    function parseTag(html, start) {
      let i = start + 1;
      let len = html.length;
      if (i >= len)
        return null;
      let isClosing = false;
      if (html[i] === "/") {
        isClosing = true;
        i++;
      }
      if (i >= len || !/[a-zA-Z]/.test(html[i]))
        return null;
      let nameStart = i;
      while (i < len && /[a-zA-Z0-9]/.test(html[i]))
        i++;
      let tagName = html.slice(nameStart, i).toLowerCase();
      if (!tagName)
        return null;
      let attrs = [];
      if (!isClosing) {
        while (i < len) {
          while (i < len && /\s/.test(html[i]))
            i++;
          if (i >= len)
            break;
          if (html[i] === ">")
            break;
          if (html[i] === "/" && i + 1 < len && html[i + 1] === ">")
            break;
          let attrNameStart = i;
          while (i < len && /[a-zA-Z0-9_\-:]/.test(html[i]))
            i++;
          let attrName = html.slice(attrNameStart, i).toLowerCase();
          if (!attrName) {
            i++;
            continue;
          }
          while (i < len && /\s/.test(html[i]))
            i++;
          let attrValue = "";
          if (i < len && html[i] === "=") {
            i++;
            while (i < len && /\s/.test(html[i]))
              i++;
            if (i < len && (html[i] === '"' || html[i] === "'")) {
              let quote = html[i];
              i++;
              let valueStart = i;
              while (i < len && html[i] !== quote)
                i++;
              attrValue = html.slice(valueStart, i);
              if (i < len)
                i++;
            } else {
              let valueStart = i;
              while (i < len && !/[\s>]/.test(html[i]))
                i++;
              attrValue = html.slice(valueStart, i);
            }
          }
          attrs.push({ name: attrName, value: attrValue });
        }
      } else {
        while (i < len && html[i] !== ">")
          i++;
      }
      let isSelfClosing = false;
      if (i < len && html[i] === "/") {
        isSelfClosing = true;
        i++;
      }
      if (i < len && html[i] === ">") {
        i++;
      } else {
        let nextClose = html.indexOf(">", i);
        i = nextClose === -1 ? len : nextClose + 1;
      }
      return { tagName, isClosing, isSelfClosing, attrs, end: i };
    }
    function sanitizeTagAttributes(attrs, tagName) {
      let allowedForTag = SAFE_ATTRS[tagName] || /* @__PURE__ */ new Set();
      let allowedGlobal = SAFE_ATTRS["*"] || /* @__PURE__ */ new Set();
      let result = "";
      for (let { name, value } of attrs) {
        if (name.startsWith("on"))
          continue;
        if (name.startsWith("data-"))
          continue;
        if (!allowedForTag.has(name) && !allowedGlobal.has(name))
          continue;
        let decodedValue = decodeEntities(value);
        if (name === "href") {
          decodedValue = sanitizeUrl(decodedValue);
          if (!decodedValue)
            continue;
        }
        result += ` ${name}="${escapeAttr(decodedValue)}"`;
      }
      return result;
    }
    function decodeEntities(str) {
      return str.replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => {
        let code = parseInt(hex, 16);
        return code > 0 && code < 1114111 ? String.fromCodePoint(code) : "";
      }).replace(/&#(\d+);/g, (_, dec) => {
        let code = parseInt(dec, 10);
        return code > 0 && code < 1114111 ? String.fromCodePoint(code) : "";
      }).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&apos;/g, "'");
    }
    function sanitizeUrl(url) {
      if (!url)
        return "";
      let trimmed = url.trim().replace(/[\x00-\x1f\x7f]/g, "");
      trimmed = trimmed.replace(/\s+/g, "");
      if (trimmed.startsWith("/") || trimmed.startsWith("#") || trimmed.startsWith("?")) {
        return trimmed;
      }
      try {
        let parsed = new URL(trimmed);
        if (!SAFE_PROTOCOLS.has(parsed.protocol))
          return "";
        return trimmed;
      } catch {
        if (/^[a-z][a-z0-9+.-]*:/i.test(trimmed))
          return "";
        return trimmed;
      }
    }
    function escapeAttr(str) {
      return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    function escapeHtml(text) {
      if (!text || typeof text !== "string")
        return "";
      return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
    }
    module2.exports = {
      sanitizeHtml,
      escapeHtml
    };
  }
});

// src/sync-engine.js
var require_sync_engine = __commonJS({
  "src/sync-engine.js"(exports2, module2) {
    "use strict";
    var fs = require("fs");
    var os = require("os");
    var Y = (init_yjs(), __toCommonJS(yjs_exports));
    var { WebsocketProvider: WebsocketProvider2 } = (init_y_websocket(), __toCommonJS(y_websocket_exports));
    var WS = require_ws();
    var { ApiClient } = require_api_client();
    var { StoreAdapter } = require_store_adapter();
    var identity2 = require_identity();
    var schema = require_crdt_schema();
    var { BackupManager } = require_backup();
    var { SyncVault } = require_vault();
    var { sanitizeHtml, escapeHtml } = require_sanitize();
    var SyncEngine2 = class {
      constructor(options, logger, store = null) {
        this.options = options;
        this.logger = logger;
        this.debug = options.debug === true;
        this.doc = null;
        this.provider = null;
        this.api = new ApiClient(options.apiPort, logger);
        this.adapter = store ? new StoreAdapter(store, logger) : null;
        this.backup = null;
        this.localIndex = /* @__PURE__ */ new Map();
        this.previousSnapshot = /* @__PURE__ */ new Map();
        this.safetyNetTimer = null;
        this.heartbeatTimer = null;
        this.unsubscribe = null;
        this._storeUnsubscribe = null;
        this.fileWatcher = null;
        this.projectPath = null;
        this.state = "idle";
        this.lastSync = null;
        this.peerCount = 0;
        this._syncing = false;
        this._paused = false;
        this._consecutiveErrors = 0;
        this._localDebounceTimer = null;
        this._remoteDebounceTimer = null;
        this._pendingRemoteIdentities = /* @__PURE__ */ new Set();
        this.vault = new SyncVault();
        this._applyingRemote = false;
        this._queuedLocalChange = false;
        this._syncLock = Promise.resolve();
        this._lastWatcherEvent = 0;
        this._watcherHealthTimer = null;
        this.LOCAL_ORIGIN = "troparcel-local";
        this._listNameCache = /* @__PURE__ */ new Map();
        this._stableUserId = options.userId || `${os.userInfo().username}@${os.hostname()}:${options.apiPort || 2019}`;
      }
      _log(msg, data) {
        this.logger.info(`[troparcel] ${msg}`, data);
      }
      /**
       * Read all items fully enriched from the store adapter.
       * Used by syncOnce and import hook when store is available.
       */
      readAllItemsFull() {
        if (!this.adapter)
          return [];
        let summaries = this.adapter.getAllItems();
        let items = [];
        for (let s of summaries) {
          let full = this.adapter.getItemFull(s.id);
          if (full)
            items.push(full);
        }
        return items;
      }
      // --- Async mutex (R2) ---
      /**
       * Acquire the sync lock. Returns a release function.
       * Prevents concurrent syncOnce/applyPendingRemote operations.
       */
      _acquireLock() {
        let release;
        let prev = this._syncLock;
        this._syncLock = new Promise((resolve) => {
          release = resolve;
        });
        return prev.then(() => release);
      }
      // --- Lifecycle ---
      async start(opts = {}) {
        if (this.state === "connected" || this.state === "connecting")
          return;
        this.state = "connecting";
        this.logger.info("Sync engine v3.1 starting", {
          server: this.options.serverUrl,
          room: this.options.room,
          syncMode: this.options.syncMode
        });
        try {
          this.doc = new Y.Doc();
          schema.registerUser(this.doc, this.doc.clientID, this._stableUserId);
          let WSImpl = WS;
          this.provider = new WebsocketProvider2(
            this.options.serverUrl,
            this.options.room,
            this.doc,
            {
              connect: true,
              params: this.options.roomToken ? { token: this.options.roomToken } : {},
              maxBackoffTime: 1e4,
              resyncInterval: 3e4,
              WebSocketPolyfill: WSImpl
            }
          );
          this.provider.on("status", (e) => {
            this.logger.info(`WS status: ${e.status}`);
          });
          this.provider.on("connection-error", (e) => {
            this.logger.warn("WS connection-error", { error: e.message || String(e) });
          });
          this.provider.on("connection-close", (e) => {
            this.logger.info("WS connection-close", { code: e.code, reason: e.reason });
          });
          await this.waitForConnection();
          this.backup = new BackupManager(
            this.options.room,
            this.api,
            this.logger,
            {
              maxBackups: this.options.maxBackups,
              maxNoteSize: this.options.maxNoteSize,
              maxMetadataSize: this.options.maxMetadataSize,
              tombstoneFloodThreshold: this.options.tombstoneFloodThreshold
            }
          );
          if (this.options.syncMode === "auto") {
            this.unsubscribe = schema.observeAnnotationsDeep(
              this.doc,
              (changes) => {
                this.handleRemoteChanges(changes);
              },
              this.LOCAL_ORIGIN
            );
          }
          this._statusHandler = (event) => {
            if (event.status === "connected") {
              this.state = "connected";
              this.logger.info("WebSocket connected");
            } else if (event.status === "disconnected") {
              this.logger.warn("WebSocket disconnected, will retry");
            }
          };
          this.provider.on("status", this._statusHandler);
          this.state = "connected";
          this.logger.info("Sync engine connected", {
            clientId: this.doc.clientID,
            room: this.options.room
          });
          if (!opts.skipStartupDelay) {
            let startupDelay = this.options.startupDelay;
            if (startupDelay > 0) {
              await new Promise((r) => setTimeout(r, startupDelay));
            }
          }
          if (!opts.skipInitialSync) {
            await this.syncOnce();
          }
          if (this.options.autoSync && !opts.skipInitialSync) {
            await this.startWatching();
          }
          let safetyInterval = this.options.safetyNetInterval * 1e3;
          if (safetyInterval > 0) {
            this.safetyNetTimer = setInterval(() => {
              this._scheduleSafetyNet();
            }, safetyInterval);
          }
          this.heartbeatTimer = setInterval(() => {
            schema.heartbeat(this.doc, this.doc.clientID);
          }, 3e4);
        } catch (err) {
          this.state = "error";
          this.logger.error("Sync engine failed to start", { error: err.message });
          throw err;
        }
      }
      /**
       * Safety-net with exponential backoff (R5).
       */
      _scheduleSafetyNet() {
        if (this._consecutiveErrors > 0) {
          let backoffFactor = Math.min(Math.pow(2, this._consecutiveErrors), 16);
          let skipChance = 1 - 1 / backoffFactor;
          if (Math.random() < skipChance) {
            this._log(`Safety-net skipped (backoff: ${this._consecutiveErrors} errors)`);
            return;
          }
        }
        this.syncOnce();
      }
      stop() {
        this.logger.info("Sync engine stopping");
        if (this._storeUnsubscribe) {
          this._storeUnsubscribe();
          this._storeUnsubscribe = null;
        }
        this.stopWatching();
        if (this.safetyNetTimer) {
          clearInterval(this.safetyNetTimer);
          this.safetyNetTimer = null;
        }
        if (this.heartbeatTimer) {
          clearInterval(this.heartbeatTimer);
          this.heartbeatTimer = null;
        }
        if (this._watcherHealthTimer) {
          clearInterval(this._watcherHealthTimer);
          this._watcherHealthTimer = null;
        }
        if (this._localDebounceTimer) {
          clearTimeout(this._localDebounceTimer);
          this._localDebounceTimer = null;
        }
        if (this._remoteDebounceTimer) {
          clearTimeout(this._remoteDebounceTimer);
          this._remoteDebounceTimer = null;
        }
        if (this.unsubscribe) {
          this.unsubscribe();
          this.unsubscribe = null;
        }
        if (this.doc) {
          try {
            schema.deregisterUser(this.doc, this.doc.clientID);
          } catch (err) {
            this.logger.debug("Failed to deregister user", { error: err.message });
          }
        }
        if (this.provider) {
          if (this._statusHandler) {
            this.provider.off("status", this._statusHandler);
            this._statusHandler = null;
          }
          this.provider.destroy();
          this.provider = null;
        }
        if (this.doc) {
          this.doc.destroy();
          this.doc = null;
        }
        this.localIndex.clear();
        this.previousSnapshot.clear();
        this._pendingRemoteIdentities.clear();
        this._listNameCache.clear();
        this.vault.clear();
        this._applyingRemote = false;
        this._queuedLocalChange = false;
        this.state = "idle";
      }
      // R3: Clean up listener on timeout
      waitForConnection() {
        return new Promise((resolve, reject) => {
          if (this.provider.wsconnected) {
            resolve();
            return;
          }
          let handler = (event) => {
            if (event.status === "connected") {
              clearTimeout(timeout);
              this.provider.off("status", handler);
              resolve();
            }
          };
          let timeout = setTimeout(() => {
            this.provider.off("status", handler);
            reject(new Error("Connection timeout (15s)"));
          }, 15e3);
          this.provider.on("status", handler);
        });
      }
      pause() {
        this._paused = true;
        this._log("Sync paused");
      }
      resume() {
        this._paused = false;
        this._log("Sync resumed");
      }
      // --- Change detection ---
      async startWatching() {
        if (this.adapter) {
          if (this._storeUnsubscribe)
            return;
          this._log("Using store.subscribe for change detection");
          this._storeUnsubscribe = this.adapter.subscribe(() => {
            this.handleLocalChange();
          });
          return;
        }
        if (this.fileWatcher)
          return;
        try {
          let info = await this.api.getProjectInfo();
          if (info && info.project) {
            this.projectPath = info.project;
            this._log(`Watching project file: ${this.projectPath}`);
          }
        } catch (err) {
          this._log("Could not get project path, file watching disabled", {
            error: err.message
          });
          return;
        }
        if (!this.projectPath)
          return;
        this._startFileWatcher();
        this._lastWatcherEvent = Date.now();
        this._watcherHealthTimer = setInterval(() => {
          this._checkWatcherHealth();
        }, 6e4);
      }
      _startFileWatcher() {
        try {
          this.fileWatcher = fs.watch(this.projectPath, { persistent: false }, (eventType) => {
            if (eventType === "change") {
              this._lastWatcherEvent = Date.now();
              this.handleLocalChange();
            }
          });
          this.fileWatcher.on("error", (err) => {
            this.logger.debug("File watcher error", { error: err.message });
            this._restartFileWatcher();
          });
        } catch (err) {
          this.logger.debug("Could not start file watcher", { error: err.message });
        }
      }
      // R9: Restart dead watcher
      _restartFileWatcher() {
        if (this.fileWatcher) {
          try {
            this.fileWatcher.close();
          } catch {
          }
          this.fileWatcher = null;
        }
        if (this.projectPath) {
          this._log("Restarting file watcher");
          this._startFileWatcher();
        }
      }
      // R9: If watcher hasn't fired in 5 minutes and safety-net has seen changes, restart
      _checkWatcherHealth() {
        if (!this.fileWatcher)
          return;
        let silenceMs = Date.now() - this._lastWatcherEvent;
        if (silenceMs > 5 * 60 * 1e3) {
          this.logger.info("File watcher silent for >5min, restarting");
          this._restartFileWatcher();
        }
      }
      stopWatching() {
        if (this.fileWatcher) {
          this.fileWatcher.close();
          this.fileWatcher = null;
        }
        if (this._watcherHealthTimer) {
          clearInterval(this._watcherHealthTimer);
          this._watcherHealthTimer = null;
        }
      }
      /**
       * Debounced handler for local file changes.
       */
      handleLocalChange() {
        if (this._paused)
          return;
        if (this._applyingRemote) {
          this._queuedLocalChange = true;
          this._log("handleLocalChange: queued (applying remote)");
          return;
        }
        this._log("handleLocalChange: store change detected, debouncing");
        if (this._localDebounceTimer) {
          clearTimeout(this._localDebounceTimer);
        }
        this._localDebounceTimer = setTimeout(() => {
          this._localDebounceTimer = null;
          this._log("handleLocalChange: debounce fired, triggering syncOnce");
          this.syncOnce();
        }, this.options.localDebounce);
      }
      /**
       * Handle remote CRDT changes — debounce and apply.
       */
      handleRemoteChanges(changes) {
        for (let change of changes) {
          this._pendingRemoteIdentities.add(change.identity);
        }
        if (this._remoteDebounceTimer) {
          clearTimeout(this._remoteDebounceTimer);
        }
        this._remoteDebounceTimer = setTimeout(() => {
          this._remoteDebounceTimer = null;
          this.applyPendingRemote();
        }, this.options.remoteDebounce);
      }
      async applyPendingRemote() {
        if (this._paused)
          return;
        if (this._pendingRemoteIdentities.size === 0)
          return;
        if (this.localIndex.size === 0) {
          this._log("applyPendingRemote: localIndex empty, deferring");
          return;
        }
        let release = await this._acquireLock();
        try {
          let identities = Array.from(this._pendingRemoteIdentities);
          this._pendingRemoteIdentities.clear();
          let allTags = null;
          try {
            allTags = this.adapter ? this.adapter.getAllTags() : await this.api.getTags();
          } catch {
          }
          let tagMap = /* @__PURE__ */ new Map();
          if (allTags && Array.isArray(allTags)) {
            for (let t of allTags)
              tagMap.set(t.name, t);
          }
          let listMap = /* @__PURE__ */ new Map();
          if (this.options.syncLists) {
            try {
              let allLists = this.adapter ? this.adapter.getAllLists() : await this.api.getLists();
              if (Array.isArray(allLists)) {
                for (let l of allLists)
                  listMap.set(l.name, l);
              }
            } catch {
            }
          }
          this._applyingRemote = true;
          if (this.adapter)
            this.adapter.suppressChanges();
          try {
            for (let itemIdentity of identities) {
              let local = identity2.findLocalMatch(itemIdentity, this.localIndex);
              if (!local)
                continue;
              try {
                await this.applyRemoteAnnotations(itemIdentity, local, tagMap, listMap);
              } catch (err) {
                this.logger.debug(`Failed to apply remote for ${itemIdentity}`, {
                  error: err.message
                });
              }
            }
          } finally {
            this._applyingRemote = false;
            if (this.adapter)
              this.adapter.resumeChanges();
            if (this._queuedLocalChange) {
              this._queuedLocalChange = false;
              this._log("applyPendingRemote: replaying queued local change");
              this.handleLocalChange();
            }
          }
        } finally {
          release();
        }
      }
      // --- Core sync cycle ---
      async syncOnce() {
        if (this.state !== "connected")
          return;
        if (!this.doc)
          return;
        if (this._syncing)
          return;
        if (this._paused)
          return;
        this._syncing = true;
        let release = await this._acquireLock();
        let prev = this.state;
        this.state = "syncing";
        try {
          this._log("syncOnce: starting cycle");
          let items;
          if (this.adapter) {
            items = this.readAllItemsFull();
            if (items.length === 0) {
              this._log("syncOnce: no items in store");
              this.state = prev;
              return;
            }
            this._log(`syncOnce: got ${items.length} items from store`);
          } else {
            let alive = await this.api.ping();
            if (!alive) {
              this._log("syncOnce: API not reachable, skipping");
              this.state = prev;
              return;
            }
            let summaries = await this.api.getItems();
            if (!summaries || !Array.isArray(summaries)) {
              this._log("syncOnce: no items from API");
              this.state = prev;
              return;
            }
            this._log(`syncOnce: got ${summaries.length} item summaries`);
            items = await this._enrichAll(summaries);
          }
          this.localIndex = identity2.buildIdentityIndex(items);
          this._log(`syncOnce: identity index built`, {
            items: items.length,
            identities: this.localIndex.size
          });
          await this._refreshListNameCache();
          let appliedIdentities = /* @__PURE__ */ new Set();
          if (this.options.syncMode === "auto") {
            let snapshot2 = schema.getSnapshot(this.doc);
            this.vault.updateAnnotationCount(Object.keys(snapshot2).length);
            if (this.vault.hasCRDTChanged(snapshot2)) {
              this._log("syncOnce: CRDT changed, applying remote");
              appliedIdentities = await this.applyRemoteFromCRDT();
              if (appliedIdentities.size > 0) {
                if (this.adapter) {
                  items = this.readAllItemsFull();
                } else {
                  let summaries = await this.api.getItems();
                  if (summaries && Array.isArray(summaries)) {
                    let modifiedSummaries = summaries.filter((s) => {
                      let id2 = identity2.computeIdentity({ "@id": s.id, template: s.template, photo: [] });
                      return id2 && appliedIdentities.has(id2);
                    });
                    if (modifiedSummaries.length === 0 && appliedIdentities.size > 0) {
                      items = await this._enrichAll(summaries);
                    } else if (modifiedSummaries.length > 0) {
                      let reEnriched = await this._enrichAll(modifiedSummaries);
                      let reEnrichedMap = /* @__PURE__ */ new Map();
                      for (let item of reEnriched) {
                        let id2 = identity2.computeIdentity(item);
                        if (id2)
                          reEnrichedMap.set(id2, item);
                      }
                      items = items.map((item) => {
                        let id2 = identity2.computeIdentity(item);
                        return id2 && reEnrichedMap.has(id2) ? reEnrichedMap.get(id2) : item;
                      });
                    }
                  }
                }
                this.localIndex = identity2.buildIdentityIndex(items);
              }
            } else {
              this._log("syncOnce: CRDT unchanged, skipping apply phase");
            }
          }
          await this.pushLocal(items);
          if (this.options.syncMode === "auto") {
            let postPushSnapshot = schema.getSnapshot(this.doc);
            this.vault.hasCRDTChanged(postPushSnapshot);
          }
          this.vault.pruneAppliedKeys();
          if (this.previousSnapshot.size > 5e3) {
            let keys2 = Array.from(this.previousSnapshot.keys());
            let toRemove = keys2.slice(0, keys2.length - 5e3);
            for (let k of toRemove)
              this.previousSnapshot.delete(k);
          }
          this.lastSync = /* @__PURE__ */ new Date();
          this._consecutiveErrors = 0;
          this.state = "connected";
          this._log("syncOnce: cycle complete");
        } catch (err) {
          this._consecutiveErrors++;
          let isBusy = err.sqliteBusy || err.message && err.message.includes("SQLITE_BUSY");
          if (isBusy) {
            this.logger.warn("Database busy, will back off", {
              consecutiveErrors: this._consecutiveErrors
            });
          } else {
            this.logger.warn("Sync cycle failed", {
              error: err.message || String(err),
              stack: err.stack
            });
          }
          this.state = prev === "connected" ? "connected" : "error";
        } finally {
          this._syncing = false;
          release();
          if (this._queuedLocalChange) {
            this._queuedLocalChange = false;
            this._log("syncOnce: replaying queued local change");
            this.handleLocalChange();
          }
        }
      }
      // --- Enrichment ---
      /**
       * Enrich all summaries with bounded parallelism (P1).
       */
      async _enrichAll(summaries) {
        let items = [];
        let batchSize = 5;
        for (let i = 0; i < summaries.length; i += batchSize) {
          let batch = summaries.slice(i, i + batchSize);
          let results = await Promise.all(
            batch.map((s) => this.enrichItem(s).catch((err) => {
              this.logger.debug(`Failed to enrich item ${s.id}`, { error: err.message });
              return null;
            }))
          );
          for (let r of results) {
            if (r)
              items.push(r);
          }
        }
        return items;
      }
      /**
       * P1: Parallel sub-resource fetching within an item.
       * P3: Notes fetched as HTML only (not json+html separately).
       */
      async enrichItem(summary) {
        let enriched = {
          "@id": summary.id,
          template: summary.template,
          lists: summary.lists || []
        };
        let [meta, tags] = await Promise.all([
          this.api.getMetadata(summary.id).catch(() => null),
          this.api.getItemTags(summary.id).catch(() => null)
        ]);
        if (meta) {
          for (let [key, value] of Object.entries(meta)) {
            if (key === "id")
              continue;
            if (typeof value === "object" && value !== null) {
              enriched[key] = {
                "@value": value.text || "",
                "@type": value.type || ""
              };
            } else if (value != null) {
              enriched[key] = value;
            }
          }
        }
        if (tags && Array.isArray(tags)) {
          enriched.tag = tags.map((t) => ({
            id: t.id || t.tag_id,
            name: t.name,
            color: t.color || null
          }));
        }
        enriched.photo = [];
        let photoIds = summary.photos || [];
        let photoResults = await Promise.all(
          photoIds.map((pid) => this.api.getPhoto(pid).catch(() => null))
        );
        for (let photo of photoResults) {
          if (!photo)
            continue;
          let enrichedPhoto = {
            "@id": photo.id,
            checksum: photo.checksum,
            note: [],
            selection: [],
            transcription: [],
            metadata: null
          };
          let subFetches = [];
          if (this.options.syncPhotoAdjustments) {
            subFetches.push(
              this.api.getMetadata(photo.id).catch(() => null).then((m) => {
                enrichedPhoto.metadata = m;
              })
            );
          }
          let noteIds = photo.notes || [];
          for (let noteId of noteIds) {
            subFetches.push(
              this.api.getNote(noteId, "html").catch(() => null).then((html) => {
                if (html != null) {
                  enrichedPhoto.note.push({
                    "@id": noteId,
                    text: typeof html === "string" ? html.replace(/<[^>]*>/g, "") : "",
                    html: typeof html === "string" ? html : "",
                    language: null,
                    photo: photo.id
                  });
                }
              })
            );
          }
          let selectionIds = photo.selections || [];
          for (let selId of selectionIds) {
            subFetches.push(
              this._enrichSelection(selId, photo.checksum).then((sel) => {
                if (sel)
                  enrichedPhoto.selection.push(sel);
              })
            );
          }
          let txIds = photo.transcriptions || [];
          for (let txId of txIds) {
            subFetches.push(
              this.api.getTranscription(txId, "json").catch(() => null).then((tx) => {
                if (tx)
                  enrichedPhoto.transcription.push(tx);
              })
            );
          }
          await Promise.all(subFetches);
          enriched.photo.push(enrichedPhoto);
        }
        return enriched;
      }
      async _enrichSelection(selId, photoChecksum) {
        try {
          let sel = await this.api.getSelection(selId);
          if (!sel)
            return null;
          let enrichedSel = {
            "@id": sel.id,
            x: sel.x,
            y: sel.y,
            width: sel.width,
            height: sel.height,
            angle: sel.angle || 0,
            note: [],
            metadata: null,
            transcription: []
          };
          let subFetches = [];
          subFetches.push(
            this.api.getMetadata(selId).catch(() => null).then((m) => {
              enrichedSel.metadata = m;
            })
          );
          let selNoteIds = sel.notes || [];
          for (let noteId of selNoteIds) {
            subFetches.push(
              this.api.getNote(noteId, "html").catch(() => null).then((html) => {
                if (html != null) {
                  enrichedSel.note.push({
                    "@id": noteId,
                    text: typeof html === "string" ? html.replace(/<[^>]*>/g, "") : "",
                    html: typeof html === "string" ? html : "",
                    language: null,
                    selection: sel.id
                  });
                }
              })
            );
          }
          let selTxIds = sel.transcriptions || [];
          for (let txId of selTxIds) {
            subFetches.push(
              this.api.getTranscription(txId, "json").catch(() => null).then((tx) => {
                if (tx)
                  enrichedSel.transcription.push(tx);
              })
            );
          }
          await Promise.all(subFetches);
          return enrichedSel;
        } catch {
          return null;
        }
      }
      // --- Push local → CRDT ---
      async pushLocal(items) {
        let userId = this._stableUserId;
        let pushed = 0;
        let skipped = 0;
        for (let item of items) {
          let id2 = identity2.computeIdentity(item);
          if (!id2)
            continue;
          if (!this.vault.hasItemChanged(id2, item)) {
            skipped++;
            continue;
          }
          pushed++;
          let checksumMap = identity2.buildPhotoChecksumMap(item);
          try {
            this.doc.transact(() => {
              this.pushMetadata(item, id2, userId);
              this.pushTags(item, id2, userId);
              this.pushNotes(item, id2, userId, checksumMap);
              this.pushPhotoMetadata(item, id2, userId);
              this.pushSelections(item, id2, userId, checksumMap);
              this.pushTranscriptions(item, id2, userId, checksumMap);
              if (this.options.syncLists) {
                this.pushLists(item, id2, userId);
              }
              this.pushDeletions(item, id2, userId, checksumMap);
            }, this.LOCAL_ORIGIN);
            this.saveItemSnapshot(item, id2, checksumMap);
            this.vault.markPushed(id2, item);
          } catch (err) {
            this.logger.debug(`Failed to push item ${id2}`, { error: err.message });
          }
        }
        this._log(`pushLocal: pushed ${pushed}, skipped ${skipped} (unchanged)`);
      }
      pushMetadata(item, itemIdentity, userId) {
        let existing = schema.getMetadata(this.doc, itemIdentity);
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        for (let [key, value] of Object.entries(item)) {
          if (key.startsWith("@") || key.startsWith("_"))
            continue;
          if (["photo", "template", "list", "lists", "tag"].includes(key))
            continue;
          if (!key.includes(":") && !key.includes("/"))
            continue;
          let text = "";
          let type = "http://www.w3.org/2001/XMLSchema#string";
          let language = null;
          if (typeof value === "string") {
            text = value;
          } else if (value && typeof value === "object") {
            text = value["@value"] || value.text || "";
            type = value["@type"] || value.type || type;
            language = value["@language"] || value.language || null;
          } else if (value != null) {
            text = String(value);
          }
          if (!text)
            continue;
          let current = existing[key];
          if (current) {
            if (current.text === text && current.type === type)
              continue;
            if (current.author !== userId && current.ts > lastPushTs)
              continue;
          }
          schema.setMetadata(this.doc, itemIdentity, key, { text, type, language }, userId);
        }
      }
      pushTags(item, itemIdentity, userId) {
        let tags = item.tag || item["https://tropy.org/v1/tropy#tag"] || [];
        if (!Array.isArray(tags))
          tags = [tags];
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        let existingTags = schema.getTags(this.doc, itemIdentity);
        for (let tag of tags) {
          let name = typeof tag === "string" ? tag : tag.name || tag["@value"] || "";
          let color = typeof tag === "object" ? tag.color : null;
          if (!name)
            continue;
          let existing = existingTags.find((t) => t.name === name);
          if (existing && !existing.deleted) {
            if ((existing.color || null) === (color || null))
              continue;
            if (existing.author !== userId && existing.ts > lastPushTs)
              continue;
          }
          schema.setTag(this.doc, itemIdentity, { name, color }, userId);
        }
      }
      // C1: Uses vault mapping for stable note keys
      pushNotes(item, itemIdentity, userId, checksumMap) {
        let photos = item.photo || item["https://tropy.org/v1/tropy#photo"] || [];
        if (!Array.isArray(photos))
          photos = [photos];
        let existingNotes = schema.getNotes(this.doc, itemIdentity);
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        for (let photo of photos) {
          let photoChecksum = photo.checksum || checksumMap.get(photo["@id"] || photo.id);
          let notes = photo.note || photo["https://tropy.org/v1/tropy#note"] || [];
          if (!Array.isArray(notes))
            notes = [notes];
          for (let note of notes) {
            if (!note)
              continue;
            let text = note["@value"] || note.text || note["https://schema.org/text"] || "";
            let html = note.html || note["https://tropy.org/v1/tropy#html"] || "";
            if (typeof text === "object")
              text = text["@value"] || "";
            if (typeof html === "object")
              html = html["@value"] || "";
            if (text || html) {
              let contentKey = identity2.computeNoteKey(
                { text, html, photo: photo["@id"] || photo.id },
                photoChecksum
              );
              let localNoteId = note["@id"] || note.id;
              let noteKey = localNoteId ? this.vault.getNoteKey(localNoteId, contentKey) : contentKey;
              this.vault.appliedNoteKeys.add(noteKey);
              let existingNote = existingNotes[noteKey];
              if (existingNote && !existingNote.deleted && existingNote.text === text && existingNote.html === html) {
                continue;
              }
              if (existingNote && !existingNote.deleted && existingNote.author !== userId && existingNote.ts > lastPushTs) {
                continue;
              }
              schema.setNote(this.doc, itemIdentity, noteKey, {
                text,
                html,
                language: note.language || null,
                photo: photoChecksum || null
              }, userId);
            }
          }
          let selections = photo.selection || photo["https://tropy.org/v1/tropy#selection"] || [];
          if (!Array.isArray(selections))
            selections = [selections];
          for (let sel of selections) {
            if (!sel || !photoChecksum)
              continue;
            let selKey = identity2.computeSelectionKey(photoChecksum, sel);
            let selNotes = sel.note || sel["https://tropy.org/v1/tropy#note"] || [];
            if (!Array.isArray(selNotes))
              selNotes = [selNotes];
            let existingSelNotes = schema.getSelectionNotes(this.doc, itemIdentity, selKey);
            for (let note of selNotes) {
              if (!note)
                continue;
              let text = note["@value"] || note.text || "";
              let html = note.html || "";
              if (typeof text === "object")
                text = text["@value"] || "";
              if (typeof html === "object")
                html = html["@value"] || "";
              if (text || html) {
                let contentKey = identity2.computeNoteKey(
                  { text, html, selection: sel["@id"] || sel.id },
                  photoChecksum
                );
                let localNoteId = note["@id"] || note.id;
                let noteKey = localNoteId ? this.vault.getNoteKey(localNoteId, contentKey) : contentKey;
                let compositeKey = `${selKey}:${noteKey}`;
                this.vault.appliedNoteKeys.add(compositeKey);
                let existingSelNote = existingSelNotes[compositeKey];
                if (existingSelNote && existingSelNote.text === text && existingSelNote.html === html) {
                  continue;
                }
                if (existingSelNote && !existingSelNote.deleted && existingSelNote.author !== userId && existingSelNote.ts > lastPushTs) {
                  continue;
                }
                schema.setSelectionNote(this.doc, itemIdentity, selKey, noteKey, {
                  text,
                  html,
                  language: note.language || null
                }, userId);
              }
            }
          }
        }
      }
      pushPhotoMetadata(item, itemIdentity, userId) {
        if (!this.options.syncPhotoAdjustments)
          return;
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        let photos = item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let photo of photos) {
          let checksum = photo.checksum;
          if (!checksum || !photo.metadata)
            continue;
          for (let [key, value] of Object.entries(photo.metadata)) {
            if (key === "id")
              continue;
            let text = "";
            let type = "http://www.w3.org/2001/XMLSchema#string";
            if (typeof value === "object" && value !== null) {
              text = value.text || "";
              type = value.type || type;
            } else if (value != null) {
              text = String(value);
            }
            if (!text)
              continue;
            let existing = schema.getPhotoMetadata(this.doc, itemIdentity, checksum);
            if (existing[key] && existing[key].text === text)
              continue;
            if (existing[key] && existing[key].author !== userId && existing[key].ts > lastPushTs)
              continue;
            schema.setPhotoMetadata(this.doc, itemIdentity, checksum, key, { text, type }, userId);
          }
        }
      }
      // P4: Accepts checksumMap parameter instead of recomputing
      pushSelections(item, itemIdentity, userId, checksumMap) {
        let photos = item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        let existingSelections = schema.getSelections(this.doc, itemIdentity);
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        for (let photo of photos) {
          let photoChecksum = photo.checksum || checksumMap.get(photo["@id"] || photo.id);
          if (!photoChecksum)
            continue;
          let selections = photo.selection || [];
          if (!Array.isArray(selections))
            selections = [selections];
          for (let sel of selections) {
            if (!sel)
              continue;
            let selKey = identity2.computeSelectionKey(photoChecksum, sel);
            this.vault.appliedSelectionKeys.add(selKey);
            let existingSel = existingSelections[selKey];
            let selUnchanged = existingSel && !existingSel.deleted && existingSel.x === sel.x && existingSel.y === sel.y && existingSel.w === sel.width && existingSel.h === sel.height && (existingSel.angle || 0) === (sel.angle || 0);
            let remoteNewer = existingSel && !existingSel.deleted && existingSel.author !== userId && existingSel.ts > lastPushTs;
            if (!selUnchanged && !remoteNewer) {
              schema.setSelection(this.doc, itemIdentity, selKey, {
                x: sel.x,
                y: sel.y,
                width: sel.width,
                height: sel.height,
                angle: sel.angle || 0,
                photo: photoChecksum
              }, userId);
            }
            if (sel.metadata) {
              let existingSelMeta = schema.getSelectionMeta(this.doc, itemIdentity, selKey);
              for (let [key, value] of Object.entries(sel.metadata)) {
                if (key === "id")
                  continue;
                let text = "";
                let type = "http://www.w3.org/2001/XMLSchema#string";
                if (typeof value === "object" && value !== null) {
                  text = value.text || "";
                  type = value.type || type;
                } else if (value != null) {
                  text = String(value);
                }
                if (!text)
                  continue;
                let existingSM = existingSelMeta[key];
                if (existingSM && existingSM.text === text && existingSM.type === type)
                  continue;
                if (existingSM && existingSM.author !== userId && existingSM.ts > lastPushTs)
                  continue;
                schema.setSelectionMeta(this.doc, itemIdentity, selKey, key, { text, type }, userId);
              }
            }
          }
        }
      }
      // C3: Uses vault mapping for stable transcription keys
      pushTranscriptions(item, itemIdentity, userId, checksumMap) {
        let photos = item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        let existingTranscriptions = schema.getTranscriptions(this.doc, itemIdentity);
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        for (let photo of photos) {
          let photoChecksum = photo.checksum || checksumMap.get(photo["@id"] || photo.id);
          if (!photoChecksum)
            continue;
          let txs = photo.transcription || [];
          if (!Array.isArray(txs))
            txs = [txs];
          txs.forEach((tx, idx) => {
            if (!tx)
              return;
            let contentKey = identity2.computeTranscriptionKey(photoChecksum, idx);
            let localTxId = tx["@id"] || tx.id;
            let txKey = localTxId ? this.vault.getTxKey(localTxId, contentKey) : contentKey;
            this.vault.appliedTranscriptionKeys.add(txKey);
            let existingTx = existingTranscriptions[txKey];
            if (existingTx && !existingTx.deleted && existingTx.text === (tx.text || "")) {
              return;
            }
            if (existingTx && !existingTx.deleted && existingTx.author !== userId && existingTx.ts > lastPushTs) {
              return;
            }
            schema.setTranscription(this.doc, itemIdentity, txKey, {
              text: tx.text || "",
              data: tx.data || null,
              photo: photoChecksum
            }, userId);
          });
          let selections = photo.selection || [];
          if (!Array.isArray(selections))
            selections = [selections];
          for (let sel of selections) {
            if (!sel)
              continue;
            let selKey = identity2.computeSelectionKey(photoChecksum, sel);
            let selTxs = sel.transcription || [];
            if (!Array.isArray(selTxs))
              selTxs = [selTxs];
            selTxs.forEach((tx, idx) => {
              if (!tx)
                return;
              let contentKey = identity2.computeTranscriptionKey(photoChecksum, idx, selKey);
              let localTxId = tx["@id"] || tx.id;
              let txKey = localTxId ? this.vault.getTxKey(localTxId, contentKey) : contentKey;
              this.vault.appliedTranscriptionKeys.add(txKey);
              let existingTx = existingTranscriptions[txKey];
              if (existingTx && !existingTx.deleted && existingTx.text === (tx.text || "")) {
                return;
              }
              if (existingTx && !existingTx.deleted && existingTx.author !== userId && existingTx.ts > lastPushTs) {
                return;
              }
              schema.setTranscription(this.doc, itemIdentity, txKey, {
                text: tx.text || "",
                data: tx.data || null,
                photo: photoChecksum,
                selection: selKey
              }, userId);
            });
          }
        }
      }
      // C2: Resolves list IDs to names for cross-instance matching
      pushLists(item, itemIdentity, userId) {
        let listIds = item.lists || [];
        if (!Array.isArray(listIds))
          return;
        let existingLists = schema.getLists(this.doc, itemIdentity);
        let lastPushTs = this.lastSync ? this.lastSync.getTime() : 0;
        for (let listId of listIds) {
          let listName = this._listNameCache.get(listId) || this._listNameCache.get(String(listId));
          let key = listName || String(listId);
          let existing = existingLists[key];
          if (existing && !existing.deleted && existing.member)
            continue;
          if (existing && existing.author !== userId && existing.ts > lastPushTs)
            continue;
          schema.setListMembership(this.doc, itemIdentity, key, userId);
        }
      }
      // C2: Refresh the listId -> listName cache
      async _refreshListNameCache() {
        if (!this.options.syncLists)
          return;
        try {
          let lists = this.adapter ? this.adapter.getAllLists() : await this.api.getLists();
          if (Array.isArray(lists)) {
            this._listNameCache.clear();
            for (let l of lists) {
              if (l.id && l.name) {
                this._listNameCache.set(l.id, l.name);
                this._listNameCache.set(String(l.id), l.name);
              }
            }
          }
        } catch {
        }
      }
      // --- Deletion detection ---
      // P4: Accepts checksumMap parameter
      saveItemSnapshot(item, itemIdentity, checksumMap) {
        let tags = (item.tag || []).map(
          (t) => typeof t === "string" ? t : t.name || ""
        ).filter(Boolean);
        let noteKeys = /* @__PURE__ */ new Set();
        let photos = item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let photo of photos) {
          let photoChecksum = photo.checksum || checksumMap.get(photo["@id"] || photo.id);
          let notes = photo.note || [];
          if (!Array.isArray(notes))
            notes = [notes];
          for (let note of notes) {
            if (!note)
              continue;
            let text = note["@value"] || note.text || "";
            let html = note.html || "";
            if (typeof text === "object")
              text = text["@value"] || "";
            if (typeof html === "object")
              html = html["@value"] || "";
            if (text || html) {
              let contentKey = identity2.computeNoteKey(
                { text, html, photo: photo["@id"] || photo.id },
                photoChecksum
              );
              let localNoteId = note["@id"] || note.id;
              let key = localNoteId ? this.vault.getNoteKey(localNoteId, contentKey) : contentKey;
              noteKeys.add(key);
            }
          }
        }
        this.previousSnapshot.set(itemIdentity, { tags, noteKeys });
      }
      pushDeletions(item, itemIdentity, userId, checksumMap) {
        let prev = this.previousSnapshot.get(itemIdentity);
        if (!prev)
          return;
        let currentTags = new Set(
          (item.tag || []).map(
            (t) => typeof t === "string" ? t : t.name || ""
          ).filter(Boolean)
        );
        for (let tagName of prev.tags) {
          if (!currentTags.has(tagName)) {
            schema.removeTag(this.doc, itemIdentity, tagName, userId);
          }
        }
        let currentNoteKeys = /* @__PURE__ */ new Set();
        let photos = item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let photo of photos) {
          let photoChecksum = photo.checksum || checksumMap.get(photo["@id"] || photo.id);
          let notes = photo.note || [];
          if (!Array.isArray(notes))
            notes = [notes];
          for (let note of notes) {
            if (!note)
              continue;
            let text = note["@value"] || note.text || "";
            let html = note.html || "";
            if (typeof text === "object")
              text = text["@value"] || "";
            if (typeof html === "object")
              html = html["@value"] || "";
            if (text || html) {
              let contentKey = identity2.computeNoteKey(
                { text, html, photo: photo["@id"] || photo.id },
                photoChecksum
              );
              let localNoteId = note["@id"] || note.id;
              let key = localNoteId ? this.vault.getNoteKey(localNoteId, contentKey) : contentKey;
              currentNoteKeys.add(key);
            }
          }
        }
        for (let noteKey of prev.noteKeys) {
          if (!currentNoteKeys.has(noteKey)) {
            schema.removeNote(this.doc, itemIdentity, noteKey, userId);
          }
        }
      }
      // --- Apply remote → local ---
      /**
       * S3: Validates inbound data and BLOCKS apply when validation fails.
       * Returns Set of applied item identities (P2).
       */
      async applyRemoteFromCRDT() {
        let snapshot2 = schema.getSnapshot(this.doc);
        let identities = Object.keys(snapshot2);
        let appliedIdentities = /* @__PURE__ */ new Set();
        if (identities.length === 0) {
          this._log("applyRemote: CRDT snapshot is empty");
          return appliedIdentities;
        }
        this._log(`applyRemote: scanning ${identities.length} CRDT items`);
        let allTags = this.adapter ? this.adapter.getAllTags() : await this.api.getTags();
        let tagMap = /* @__PURE__ */ new Map();
        if (allTags && Array.isArray(allTags)) {
          for (let t of allTags)
            tagMap.set(t.name, t);
        }
        let listMap = /* @__PURE__ */ new Map();
        if (this.options.syncLists) {
          try {
            let allLists = this.adapter ? this.adapter.getAllLists() : await this.api.getLists();
            if (Array.isArray(allLists)) {
              for (let l of allLists)
                listMap.set(l.name || String(l.id), l);
            }
          } catch {
          }
        }
        this._applyingRemote = true;
        if (this.adapter)
          this.adapter.suppressChanges();
        let matched = [];
        for (let itemIdentity of identities) {
          let local = identity2.findLocalMatch(itemIdentity, this.localIndex);
          if (!local)
            continue;
          let crdtItem = snapshot2[itemIdentity];
          let validation = this.backup.validateInbound(itemIdentity, crdtItem);
          if (!validation.valid) {
            for (let warn2 of validation.warnings) {
              this.logger.warn(`Validation warning for ${itemIdentity.slice(0, 8)}: ${warn2}`);
            }
            this.logger.warn(`Skipping apply for ${itemIdentity.slice(0, 8)} \u2014 validation failed`);
            continue;
          }
          matched.push({ itemIdentity, local });
        }
        if (matched.length === 0) {
          this._applyingRemote = false;
          this._log("applyRemote: no matched items");
          return appliedIdentities;
        }
        try {
          let backupItems = [];
          for (let { local, itemIdentity } of matched) {
            try {
              let state = await this.backup.captureItemState(local.localId, itemIdentity);
              backupItems.push(state);
            } catch {
            }
          }
          if (backupItems.length > 0 && this.vault.shouldBackup(backupItems)) {
            this.backup.saveSnapshot(backupItems);
          }
        } catch (err) {
          this.logger.debug("Batch backup failed", { error: err.message });
        }
        try {
          for (let { itemIdentity, local } of matched) {
            try {
              await this.applyRemoteAnnotations(itemIdentity, local, tagMap, listMap);
              appliedIdentities.add(itemIdentity);
            } catch (err) {
              this.logger.debug(`Failed to apply remote for ${itemIdentity}`, {
                error: err.message
              });
            }
          }
        } finally {
          this._applyingRemote = false;
          if (this.adapter)
            this.adapter.resumeChanges();
          if (this._queuedLocalChange) {
            this._queuedLocalChange = false;
            this._log("applyRemote: replaying queued local change");
            this.handleLocalChange();
          }
        }
        this._log(`applyRemote: processed ${appliedIdentities.size} matched items`);
        return appliedIdentities;
      }
      // P6: Write delay only between items, not between individual fields
      _writeDelay() {
        return new Promise((r) => setTimeout(r, this.options.writeDelay));
      }
      async applyRemoteAnnotations(itemIdentity, local, tagMap, listMap) {
        let localId = local.localId;
        let userId = this._stableUserId;
        this._log(`applyAnnotations: item ${localId}, identity ${itemIdentity.slice(0, 8)}...`);
        await this.applyMetadata(itemIdentity, localId, userId);
        await this._writeDelay();
        await this.applyTags(itemIdentity, localId, userId, tagMap);
        await this._writeDelay();
        await this.applyNotes(itemIdentity, local, userId);
        await this._writeDelay();
        if (this.options.syncPhotoAdjustments) {
          await this.applyPhotoMetadata(itemIdentity, local, userId);
          await this._writeDelay();
        }
        await this.applySelections(itemIdentity, local, userId);
        await this._writeDelay();
        await this.applySelectionNotes(itemIdentity, local, userId);
        await this._writeDelay();
        await this.applySelectionMetadata(itemIdentity, local, userId);
        await this._writeDelay();
        await this.applyTranscriptions(itemIdentity, local, userId);
        if (this.options.syncLists) {
          await this._writeDelay();
          await this.applyLists(itemIdentity, local, userId, listMap);
        }
      }
      // P6: No per-field delay within metadata apply
      async applyMetadata(itemIdentity, localId, userId) {
        let remoteMeta = schema.getMetadata(this.doc, itemIdentity);
        let batch = {};
        for (let [prop, value] of Object.entries(remoteMeta)) {
          if (value.author === userId)
            continue;
          batch[prop] = { text: value.text, type: value.type };
        }
        if (Object.keys(batch).length > 0) {
          try {
            await this.api.saveMetadata(localId, batch);
          } catch (err) {
            this.logger.debug(`Failed to save metadata batch on ${localId}`, {
              error: err.message
            });
          }
        }
      }
      async applyTags(itemIdentity, localId, userId, tagMap) {
        let activeTags = schema.getActiveTags(this.doc, itemIdentity);
        for (let tag of activeTags) {
          if (tag.author === userId)
            continue;
          let existing = tagMap.get(tag.name);
          if (!existing) {
            try {
              await this.api.createTag(tag.name, tag.color, [localId]);
              continue;
            } catch (err) {
              this.logger.debug(`Failed to create tag "${tag.name}"`, { error: err.message });
              continue;
            }
          }
          try {
            await this.api.addTagsToItem(localId, [existing.id || existing.tag_id]);
          } catch {
          }
        }
        let deletedTags = schema.getDeletedTags(this.doc, itemIdentity);
        for (let tag of deletedTags) {
          if (tag.author === userId)
            continue;
          let existing = tagMap.get(tag.name);
          if (existing) {
            try {
              await this.api.removeTagsFromItem(localId, [existing.id || existing.tag_id]);
            } catch {
            }
          }
        }
      }
      // C1: Stores vault mapping when applying remote notes
      async applyNotes(itemIdentity, local, userId) {
        let remoteNotes = schema.getActiveNotes(this.doc, itemIdentity);
        let localId = local.localId;
        let photos = local.item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        let firstPhotoId = photos[0] && (photos[0]["@id"] || photos[0].id);
        for (let [noteKey, note] of Object.entries(remoteNotes)) {
          if (note.author === userId)
            continue;
          if (!note.html && !note.text)
            continue;
          if (this.vault.appliedNoteKeys.has(noteKey))
            continue;
          let photoId = firstPhotoId;
          if (note.photo) {
            for (let p of photos) {
              if (p.checksum === note.photo) {
                photoId = p["@id"] || p.id;
                break;
              }
            }
          }
          if (!photoId)
            continue;
          let safeHtml = note.html ? sanitizeHtml(note.html) : `<p>${escapeHtml(note.text)}</p>`;
          let authorLabel = escapeHtml(note.author || "unknown");
          safeHtml = `<p><strong>[${authorLabel}]</strong></p>${safeHtml}`;
          let existingLocalId = this.vault.getLocalNoteId(noteKey);
          if (existingLocalId) {
            try {
              if (this.adapter) {
                let result = await this.adapter.updateNote(existingLocalId, { html: safeHtml });
                this.vault.appliedNoteKeys.add(noteKey);
                if (result && (result.id || result["@id"])) {
                  this.vault.mapAppliedNote(noteKey, result.id || result["@id"]);
                }
              } else {
                await this.api.updateNote(existingLocalId, { html: safeHtml });
                this.vault.appliedNoteKeys.add(noteKey);
              }
              continue;
            } catch {
            }
          }
          try {
            let created;
            if (this.adapter) {
              created = await this.adapter.createNote({
                html: safeHtml,
                language: note.language,
                photo: Number(photoId) || null,
                selection: null
              });
            } else {
              created = await this.api.createNote({
                html: safeHtml,
                language: note.language,
                photo: Number(photoId) || null,
                selection: null
              });
            }
            this.vault.appliedNoteKeys.add(noteKey);
            if (created && (created.id || created["@id"])) {
              this.vault.mapAppliedNote(noteKey, created.id || created["@id"]);
            }
          } catch (err) {
            this.logger.debug(`Failed to create note on ${localId}`, {
              error: err.message
            });
          }
        }
      }
      async applyPhotoMetadata(itemIdentity, local, userId) {
        let photos = local.item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let photo of photos) {
          let checksum = photo.checksum;
          let localPhotoId = photo["@id"] || photo.id;
          if (!checksum || !localPhotoId)
            continue;
          let remoteMeta = schema.getPhotoMetadata(this.doc, itemIdentity, checksum);
          let batch = {};
          for (let [prop, value] of Object.entries(remoteMeta)) {
            if (value.author === userId)
              continue;
            batch[prop] = { text: value.text, type: value.type };
          }
          if (Object.keys(batch).length > 0) {
            try {
              await this.api.saveMetadata(localPhotoId, batch);
            } catch (err) {
              this.logger.debug(`Failed to save photo metadata batch`, { error: err.message });
            }
          }
        }
      }
      async applySelections(itemIdentity, local, userId) {
        let remoteSelections = schema.getActiveSelections(this.doc, itemIdentity);
        let photos = local.item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let [selKey, sel] of Object.entries(remoteSelections)) {
          if (sel.author === userId)
            continue;
          if (this.vault.appliedSelectionKeys.has(selKey))
            continue;
          let x = Number(sel.x);
          let y = Number(sel.y);
          let w = Number(sel.w);
          let h = Number(sel.h);
          if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) {
            this._log(`Skipping selection ${selKey}: invalid coordinates`, { x, y, w, h });
            continue;
          }
          let localPhotoId = null;
          for (let p of photos) {
            if (p.checksum === sel.photo) {
              localPhotoId = p["@id"] || p.id;
              break;
            }
          }
          if (!localPhotoId)
            continue;
          let alreadyExists = false;
          for (let p of photos) {
            if (p.checksum !== sel.photo)
              continue;
            let localSels = p.selection || [];
            if (!Array.isArray(localSels))
              localSels = [localSels];
            for (let ls of localSels) {
              if (!ls)
                continue;
              let localSelKey = identity2.computeSelectionKey(p.checksum, ls);
              if (localSelKey === selKey) {
                alreadyExists = true;
                break;
              }
            }
          }
          if (!alreadyExists) {
            try {
              if (this.adapter) {
                await this.adapter.createSelection({
                  photo: Number(localPhotoId),
                  x,
                  y,
                  width: w,
                  height: h,
                  angle: sel.angle || 0
                });
              } else {
                await this.api.createSelection({
                  photo: Number(localPhotoId),
                  x,
                  y,
                  width: w,
                  height: h,
                  angle: sel.angle || 0
                });
              }
              this.vault.appliedSelectionKeys.add(selKey);
            } catch (err) {
              this.logger.debug(`Failed to create selection on photo ${localPhotoId}`, {
                error: err.message
              });
              this.vault.appliedSelectionKeys.add(selKey);
            }
          } else {
            this.vault.appliedSelectionKeys.add(selKey);
          }
        }
      }
      async applySelectionNotes(itemIdentity, local, userId) {
        let photos = local.item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let photo of photos) {
          let checksum = photo.checksum;
          if (!checksum)
            continue;
          let localSels = photo.selection || [];
          if (!Array.isArray(localSels))
            localSels = [localSels];
          for (let sel of localSels) {
            if (!sel)
              continue;
            let selKey = identity2.computeSelectionKey(checksum, sel);
            let remoteNotes = schema.getSelectionNotes(this.doc, itemIdentity, selKey);
            for (let [compositeKey, note] of Object.entries(remoteNotes)) {
              if (note.author === userId)
                continue;
              if (!note.html && !note.text)
                continue;
              if (this.vault.appliedNoteKeys.has(compositeKey))
                continue;
              let safeHtml = note.html ? sanitizeHtml(note.html) : `<p>${escapeHtml(note.text)}</p>`;
              let authorLabel = escapeHtml(note.author || "unknown");
              safeHtml = `<p><strong>[${authorLabel}]</strong></p>${safeHtml}`;
              let localSelId = sel["@id"] || sel.id;
              if (!localSelId)
                continue;
              let existingLocalId = this.vault.getLocalNoteId(compositeKey);
              if (existingLocalId) {
                try {
                  if (this.adapter) {
                    let result = await this.adapter.updateNote(existingLocalId, { html: safeHtml });
                    this.vault.appliedNoteKeys.add(compositeKey);
                    if (result && (result.id || result["@id"])) {
                      this.vault.mapAppliedNote(compositeKey, result.id || result["@id"]);
                    }
                  } else {
                    await this.api.updateNote(existingLocalId, { html: safeHtml });
                    this.vault.appliedNoteKeys.add(compositeKey);
                  }
                  continue;
                } catch {
                }
              }
              try {
                let created;
                if (this.adapter) {
                  created = await this.adapter.createNote({
                    html: safeHtml,
                    language: note.language,
                    selection: Number(localSelId) || null
                  });
                } else {
                  created = await this.api.createNote({
                    html: safeHtml,
                    language: note.language,
                    selection: Number(localSelId) || null
                  });
                }
                this.vault.appliedNoteKeys.add(compositeKey);
                if (created && (created.id || created["@id"])) {
                  this.vault.mapAppliedNote(compositeKey, created.id || created["@id"]);
                }
              } catch (err) {
                this.logger.debug(`Failed to create selection note`, {
                  error: err.message
                });
              }
            }
          }
        }
      }
      async applySelectionMetadata(itemIdentity, local, userId) {
        let photos = local.item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let photo of photos) {
          let checksum = photo.checksum;
          if (!checksum)
            continue;
          let localSels = photo.selection || [];
          if (!Array.isArray(localSels))
            localSels = [localSels];
          for (let sel of localSels) {
            if (!sel)
              continue;
            let selKey = identity2.computeSelectionKey(checksum, sel);
            let localSelId = sel["@id"] || sel.id;
            if (!localSelId)
              continue;
            let remoteMeta = schema.getSelectionMeta(this.doc, itemIdentity, selKey);
            let batch = {};
            for (let [prop, value] of Object.entries(remoteMeta)) {
              if (value.author === userId)
                continue;
              batch[prop] = { text: value.text, type: value.type };
            }
            if (Object.keys(batch).length > 0) {
              try {
                await this.api.saveMetadata(localSelId, batch);
              } catch (err) {
                this.logger.debug(`Failed to save selection metadata`, { error: err.message });
              }
            }
          }
        }
      }
      // C3: Stores vault mapping when applying remote transcriptions
      async applyTranscriptions(itemIdentity, local, userId) {
        let remoteTranscriptions = schema.getActiveTranscriptions(this.doc, itemIdentity);
        let photos = local.item.photo || [];
        if (!Array.isArray(photos))
          photos = [photos];
        for (let [txKey, tx] of Object.entries(remoteTranscriptions)) {
          if (tx.author === userId)
            continue;
          if (!tx.text && !tx.data)
            continue;
          if (this.vault.appliedTranscriptionKeys.has(txKey))
            continue;
          let localPhotoId = null;
          for (let p of photos) {
            if (p.checksum === tx.photo) {
              localPhotoId = p["@id"] || p.id;
              break;
            }
          }
          if (!localPhotoId)
            continue;
          let localSelId = null;
          if (tx.selection) {
            for (let p of photos) {
              if (p.checksum !== tx.photo)
                continue;
              let sels = p.selection || [];
              if (!Array.isArray(sels))
                sels = [sels];
              for (let s of sels) {
                if (!s)
                  continue;
                let sk = identity2.computeSelectionKey(p.checksum, s);
                if (sk === tx.selection) {
                  localSelId = s["@id"] || s.id;
                  break;
                }
              }
            }
          }
          let existingLocalId = this.vault.getLocalTxId(txKey);
          if (existingLocalId) {
            try {
              try {
                await this.api.deleteTranscription(existingLocalId);
              } catch {
              }
              let created = await this.api.createTranscription({
                text: tx.text,
                data: tx.data,
                photo: Number(localPhotoId) || null,
                selection: localSelId ? Number(localSelId) : null
              });
              this.vault.appliedTranscriptionKeys.add(txKey);
              if (created && (created.id || created["@id"])) {
                this.vault.mapAppliedTranscription(txKey, created.id || created["@id"]);
              }
              continue;
            } catch {
            }
          }
          try {
            let created = await this.api.createTranscription({
              text: tx.text,
              data: tx.data,
              photo: Number(localPhotoId) || null,
              selection: localSelId ? Number(localSelId) : null
            });
            this.vault.appliedTranscriptionKeys.add(txKey);
            if (created && (created.id || created["@id"])) {
              this.vault.mapAppliedTranscription(txKey, created.id || created["@id"]);
            }
          } catch (err) {
            this.logger.debug(`Failed to create transcription`, {
              error: err.message
            });
            this.vault.appliedTranscriptionKeys.add(txKey);
          }
        }
      }
      // C2: Matches lists by name for cross-instance compatibility
      async applyLists(itemIdentity, local, userId, listMap) {
        let remoteLists = schema.getActiveLists(this.doc, itemIdentity);
        let localId = local.localId;
        for (let [listKey, list] of Object.entries(remoteLists)) {
          if (list.author === userId)
            continue;
          let localList = listMap.get(listKey);
          if (localList) {
            try {
              if (this.adapter) {
                await this.adapter.addItemsToList(localList.id, [localId]);
              } else {
                await this.api.addItemsToList(localList.id, [localId]);
              }
            } catch {
            }
          }
        }
        let allLists = schema.getLists(this.doc, itemIdentity);
        for (let [listKey, list] of Object.entries(allLists)) {
          if (!list.deleted)
            continue;
          if (list.author === userId)
            continue;
          let localList = listMap.get(listKey);
          if (localList) {
            try {
              if (this.adapter) {
                await this.adapter.removeItemsFromList(localList.id, [localId]);
              } else {
                await this.api.removeItemsFromList(localList.id, [localId]);
              }
            } catch {
            }
          }
        }
      }
      // --- Import (review mode) ---
      async applyOnDemand() {
        if (!this.doc)
          return null;
        let snapshot2 = schema.getSnapshot(this.doc);
        let userId = this._stableUserId;
        let summary = {};
        let allTags = this.adapter ? this.adapter.getAllTags() : await this.api.getTags();
        let tagMap = /* @__PURE__ */ new Map();
        if (allTags && Array.isArray(allTags)) {
          for (let t of allTags)
            tagMap.set(t.name, t);
        }
        let listMap = /* @__PURE__ */ new Map();
        if (this.options.syncLists) {
          try {
            let allLists = this.adapter ? this.adapter.getAllLists() : await this.api.getLists();
            if (Array.isArray(allLists)) {
              for (let l of allLists)
                listMap.set(l.name || String(l.id), l);
            }
          } catch {
          }
        }
        for (let [itemIdentity, item] of Object.entries(snapshot2)) {
          for (let section of ["metadata", "tags", "notes", "selections", "transcriptions", "lists"]) {
            let data = item[section];
            if (!data || typeof data !== "object")
              continue;
            for (let val of Object.values(data)) {
              if (val && val.author && val.author !== userId && !val.deleted) {
                if (!summary[val.author]) {
                  summary[val.author] = { metadata: 0, tags: 0, notes: 0, selections: 0, transcriptions: 0, lists: 0 };
                }
                summary[val.author][section]++;
              }
            }
          }
        }
        for (let [author, counts] of Object.entries(summary)) {
          let parts = Object.entries(counts).filter(([, n]) => n > 0).map(([type, n]) => `${n} ${type}`);
          if (parts.length > 0) {
            this.logger.info(`${author}: ${parts.join(", ")}`);
          }
        }
        let backupItems = [];
        let validIdentities = [];
        for (let [itemIdentity] of Object.entries(snapshot2)) {
          let local = identity2.findLocalMatch(itemIdentity, this.localIndex);
          if (!local)
            continue;
          let validation = this.backup.validateInbound(itemIdentity, snapshot2[itemIdentity]);
          if (!validation.valid) {
            for (let warn2 of validation.warnings) {
              this.logger.warn(`Validation warning: ${warn2}`);
            }
            continue;
          }
          validIdentities.push(itemIdentity);
          try {
            let state = await this.backup.captureItemState(local.localId, itemIdentity);
            backupItems.push(state);
          } catch {
          }
        }
        if (backupItems.length > 0 && this.vault.shouldBackup(backupItems)) {
          this.backup.saveSnapshot(backupItems);
        }
        this._applyingRemote = true;
        if (this.adapter)
          this.adapter.suppressChanges();
        let applied = 0;
        try {
          for (let itemIdentity of validIdentities) {
            let local = identity2.findLocalMatch(itemIdentity, this.localIndex);
            if (!local)
              continue;
            try {
              await this.applyRemoteAnnotations(itemIdentity, local, tagMap, listMap);
              applied++;
            } catch (err) {
              this.logger.debug(`Import: failed to apply ${itemIdentity}`, {
                error: err.message
              });
            }
          }
        } finally {
          this._applyingRemote = false;
          if (this.adapter)
            this.adapter.resumeChanges();
        }
        return { applied, summary };
      }
      // --- Manual push (export hook) ---
      pushItems(items) {
        if (!this.doc)
          return;
        let userId = this._stableUserId;
        this.doc.transact(() => {
          for (let item of items) {
            let id2 = identity2.computeIdentity(item);
            if (!id2)
              continue;
            let checksumMap = identity2.buildPhotoChecksumMap(item);
            this.pushMetadata(item, id2, userId);
            this.pushTags(item, id2, userId);
            this.pushNotes(item, id2, userId, checksumMap);
          }
        }, this.LOCAL_ORIGIN);
      }
      // --- Rollback ---
      async rollback(backupPath) {
        return this.backup.rollback(backupPath);
      }
      // --- Status ---
      // P5: Uses cached annotation count instead of serializing whole doc
      getStatus() {
        return {
          state: this.state,
          lastSync: this.lastSync,
          room: this.options.room,
          server: this.options.serverUrl,
          syncMode: this.options.syncMode,
          clientId: this.doc ? this.doc.clientID : null,
          localItems: this.localIndex.size,
          crdtItems: this.vault.annotationCount,
          users: this.doc ? schema.getUsers(this.doc) : [],
          watching: this.fileWatcher != null || this._storeUnsubscribe != null,
          storeAvailable: this.adapter != null,
          projectPath: this.projectPath,
          consecutiveErrors: this._consecutiveErrors
        };
      }
    };
    module2.exports = { SyncEngine: SyncEngine2 };
  }
});

// src/plugin.js
var { SyncEngine } = require_sync_engine();
var identity = require_identity();
var VALID_SYNC_MODES = /* @__PURE__ */ new Set(["auto", "review", "push", "pull"]);
var TroparcelPlugin = class {
  constructor(options, context) {
    this.context = context;
    this.options = this.mergeOptions(options);
    this.engine = null;
    if (this._isPrefsWindow()) {
      this.context.logger.info("Troparcel: skipping sync in prefs window");
      return;
    }
    this.context.logger.info("Troparcel v4.0 initialized", {
      room: this.options.room,
      server: this.options.serverUrl,
      autoSync: this.options.autoSync,
      syncMode: this.options.syncMode,
      userId: this.options.userId,
      hasToken: !!this.options.roomToken
    });
    if (this.options.autoSync) {
      this._waitForProjectAndStart();
    }
  }
  /**
   * Detect if we're running in Tropy's preferences window.
   * The prefs window can reach the localhost API but should never sync.
   */
  _isPrefsWindow() {
    try {
      let logger = this.context.logger;
      if (logger.chindings && logger.chindings.includes('"name":"prefs"')) {
        return true;
      }
      if (typeof logger.bindings === "function") {
        let b = logger.bindings();
        if (b && b.name === "prefs")
          return true;
      }
    } catch {
    }
    return false;
  }
  /**
   * Wait for the Redux store and project state before starting sync.
   *
   * context.window.store is set after window.load() completes.
   * Project data lives at store.getState().project (set when PROJECT.OPENED
   * action fires — there is NO context.window.project property).
   *
   * We poll every 500ms up to startupDelay for the store to appear,
   * then check the store state for project info.
   */
  async _waitForProjectAndStart() {
    let startTime = Date.now();
    let maxWait = this.options.startupDelay;
    let interval = 500;
    while (Date.now() - startTime < maxWait) {
      try {
        let store2 = this.context.window && this.context.window.store;
        if (store2) {
          let state = store2.getState();
          let project = state && state.project;
          if (project && project.path) {
            let elapsed2 = Date.now() - startTime;
            this.context.logger.info(
              `Troparcel: store + project available after ${elapsed2}ms`
            );
            if (!this.options._roomExplicit && project.name) {
              this.options.room = project.name;
            }
            this.options.projectPath = project.path;
            break;
          }
          let elapsed = Date.now() - startTime;
          if (elapsed > 2e3 && elapsed % 2e3 < interval) {
            this.context.logger.info(
              `Troparcel: store ready, waiting for project state (${elapsed}ms)`
            );
          }
        }
      } catch {
      }
      await new Promise((r) => setTimeout(r, interval));
    }
    let store = null;
    try {
      store = this.context.window && this.context.window.store;
    } catch {
    }
    if (!store) {
      this.context.logger.info(
        `Troparcel: store not available after ${this.options.startupDelay}ms \u2014 starting sync with API fallback`
      );
    }
    await this.startBackgroundSync();
  }
  mergeOptions(options) {
    let projectName = "";
    let syncMode = options.syncMode || "auto";
    if (!VALID_SYNC_MODES.has(syncMode)) {
      syncMode = "auto";
    }
    let roomExplicit = !!options.room;
    return {
      // Connection
      serverUrl: options.serverUrl || "ws://localhost:2468",
      room: options.room || projectName || "troparcel-default",
      userId: options.userId || "",
      roomToken: options.roomToken || "",
      apiPort: Number(options.apiPort) || 2019,
      // Sync behavior
      autoSync: options.autoSync !== false,
      syncMode,
      syncMetadata: options.syncMetadata !== false,
      syncTags: options.syncTags !== false,
      syncNotes: options.syncNotes !== false,
      syncSelections: options.syncSelections !== false,
      syncTranscriptions: options.syncTranscriptions !== false,
      syncPhotoAdjustments: options.syncPhotoAdjustments === true || options.syncPhotoAdjustments === "true",
      syncLists: options.syncLists === true || options.syncLists === "true",
      // Timing
      startupDelay: Number(options.startupDelay) || 8e3,
      localDebounce: Number(options.localDebounce) || 2e3,
      remoteDebounce: Number(options.remoteDebounce) || 500,
      safetyNetInterval: Number(options.safetyNetInterval) || 120,
      writeDelay: Number(options.writeDelay) || 100,
      // Safety limits
      maxBackups: Number(options.maxBackups) || 10,
      maxNoteSize: Number(options.maxNoteSize) || 1048576,
      maxMetadataSize: Number(options.maxMetadataSize) || 65536,
      tombstoneFloodThreshold: Number(options.tombstoneFloodThreshold) || 0.5,
      // Debug
      debug: options.debug === true || options.debug === "true",
      // Internal
      _roomExplicit: roomExplicit
    };
  }
  async startBackgroundSync() {
    if (this.engine)
      return;
    let store = null;
    try {
      store = this.context.window && this.context.window.store;
    } catch {
    }
    this.engine = new SyncEngine(this.options, this.context.logger, store);
    try {
      await this.engine.start();
      this.context.logger.info("Background sync active", {
        room: this.options.room,
        syncMode: this.options.syncMode,
        storeAvailable: !!store
      });
    } catch (err) {
      this.context.logger.warn("Background sync failed to start \u2014 falling back to manual export/import", {
        error: err.message
      });
      this.engine.stop();
      this.engine = null;
    }
  }
  /**
   * Export hook — share selected items to the collaboration room.
   */
  async export(data) {
    if (this._isPrefsWindow())
      return;
    if (!data || data.length === 0) {
      this.context.logger.warn("Export: no items selected");
      return;
    }
    if (this.options.syncMode === "pull") {
      this.context.logger.warn('Export: sync mode is "pull" \u2014 local changes not shared');
      return;
    }
    this.context.logger.info(`Export: sharing ${data.length} item(s)`, {
      room: this.options.room
    });
    try {
      if (this.engine && this.engine.state === "connected") {
        this.engine.pushItems(data);
        this.context.logger.info(
          `Shared ${data.length} item(s) to room "${this.options.room}" (background sync active)`
        );
        return;
      }
      let tempEngine = new SyncEngine(this.options, this.context.logger);
      await tempEngine.start();
      tempEngine.pushItems(data);
      this.context.logger.info(
        `Shared ${data.length} item(s) to room "${this.options.room}"`
      );
      setTimeout(() => tempEngine.stop(), 5e3);
    } catch (err) {
      this.context.logger.error("Export failed", {
        error: err.message,
        room: this.options.room
      });
    }
  }
  /**
   * Import hook — apply annotations from the collaboration room.
   *
   * In review mode, shows a summary of pending changes before applying.
   * In auto mode, forces a full re-sync from the CRDT.
   */
  async import(payload) {
    if (this._isPrefsWindow())
      return;
    if (this.options.syncMode === "push") {
      this.context.logger.warn('Import: sync mode is "push" \u2014 remote changes not applied');
      return;
    }
    this.context.logger.info("Import: pulling from room", {
      room: this.options.room,
      syncMode: this.options.syncMode
    });
    if (this.engine)
      this.engine.pause();
    try {
      let engine;
      let tempEngine = false;
      if (this.engine && this.engine.state === "connected") {
        engine = this.engine;
      } else {
        engine = new SyncEngine(this.options, this.context.logger);
        await engine.start();
        await new Promise((r) => setTimeout(r, 3e3));
        tempEngine = true;
      }
      if (!engine.adapter) {
        let alive = await engine.api.ping();
        if (!alive) {
          this.context.logger.warn("Import: Tropy API not reachable");
          if (tempEngine)
            engine.stop();
          return;
        }
      }
      if (engine.localIndex.size === 0) {
        if (engine.adapter) {
          let items = engine.readAllItemsFull();
          engine.localIndex = identity.buildIdentityIndex(items);
        } else {
          let localItems = await engine.api.getItems();
          if (localItems && Array.isArray(localItems)) {
            let items = [];
            for (let s of localItems) {
              try {
                items.push(await engine.enrichItem(s));
              } catch {
              }
            }
            engine.localIndex = identity.buildIdentityIndex(items);
          }
        }
      }
      let result = await engine.applyOnDemand();
      if (result) {
        this.context.logger.info(
          `Import: applied annotations to ${result.applied} item(s) from room "${this.options.room}"`
        );
      }
      if (tempEngine)
        engine.stop();
    } catch (err) {
      this.context.logger.error("Import failed", {
        error: err.message,
        room: this.options.room
      });
    } finally {
      if (this.engine)
        this.engine.resume();
    }
  }
  getStatus() {
    let safeOptions = { ...this.options };
    if (safeOptions.roomToken)
      safeOptions.roomToken = "***";
    delete safeOptions._roomExplicit;
    return {
      version: "4.0.0",
      options: safeOptions,
      engine: this.engine ? this.engine.getStatus() : null,
      backgroundSync: this.engine != null
    };
  }
  unload() {
    this.context.logger.info("Troparcel unloading");
    if (this.engine) {
      this.engine.stop();
      this.engine = null;
    }
  }
};
module.exports = TroparcelPlugin;
//# sourceMappingURL=index.js.map
